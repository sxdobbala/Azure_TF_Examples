'use strict';

exports.getHealth = (callback) => {
  callback(null, 'Health Check');
};
