'use strict';

const express = require('express');
const router = express.Router();


router.post('/login', (req, res, next) => {
  // do something
});

module.exports = router;
