#!/bin/bash

echo " Building Connector image "
docker build -t docker.optum.com/hwoheel/ose-cm-connector:latest ./ -f connector-dockerfile -q

echo " Connector image build successfully "
echo " Building JBoss image "
docker build -t docker.optum.com/hwoheel/ose-cm-jboss:latest ./ -f jboss-dockerfile -q

echo " JBoss image build successfully "
echo " Building BiFrost image "
docker build -t docker.optum.com/hwoheel/ose-cm-bifrost:latest ./ -f bifrost-dockerfile -q

echo " BiFrost image build successfully "
echo " Deploying images "
docker push docker.optum.com/hwoheel/ose-cm-connector:latest
docker push docker.optum.com/hwoheel/ose-cm-jboss:latest
docker push docker.optum.com/hwoheel/ose-cm-bifrost:latest
echo " Deployment successful"
