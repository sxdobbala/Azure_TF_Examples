#!/bin/bash

oc import-image docker.optum.com/scarlso8/ose-cm-connector:latest
oc import-image docker.optum.com/scarlso8/ose-cm-jboss:latest
oc import-image docker.optum.com/scarlso8/ose-cm-bifrost:latest