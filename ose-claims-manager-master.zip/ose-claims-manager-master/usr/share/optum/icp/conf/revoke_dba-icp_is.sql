--
--  Connect as SYS or SYSTEM
--
--
--  05/08/2013     Jeff Evans
--  06/16/2016     Gary Franklin  - added grant on dba_data_files to icp_is
--  07/06/2016     Mark Johnson   - addded grant on dba_tablespaces to icp_is
--
--  This is for version 5.0 and above.
--    It revokes the DBA role from ICP_IS.
--

REVOKE dba FROM icp_is;

GRANT select on dba_data_files TO icp_is;
GRANT select on dba_tablespaces TO icp_is;
