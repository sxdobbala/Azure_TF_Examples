--
--  Connect as SYSDBA, using SYS or another user with the sysdba role, to execute this script
--
--
--  06/16/2016     Gary Franklin
--
--  This script is for versions 5.4
--    This script deletes two roles and grants all the necessary
--    privileges to the ICP_P user, and the ICP_IS user directly.
--    It also adds the DBA role back to the ICP_IS user.
--    Some of the icp_p permissions must be granted as SYSDBA
-- 
  -- 2 Roles for ICP_P 
  GRANT CONNECT TO ICP_P;
  GRANT RESOURCE TO ICP_P;
  ALTER USER ICP_P DEFAULT ROLE RESOURCE;
  
  -- 11 System Privileges for ICP_P 
  GRANT ALTER SESSION TO ICP_P;
  GRANT CREATE ANY SYNONYM TO ICP_P;
  GRANT CREATE JOB TO ICP_P;
  GRANT CREATE PROCEDURE TO ICP_P;
  GRANT CREATE SEQUENCE TO ICP_P;
  GRANT CREATE SESSION TO ICP_P;
  GRANT CREATE TABLE TO ICP_P;
  GRANT CREATE TRIGGER TO ICP_P;
  GRANT CREATE VIEW TO ICP_P;
  GRANT DROP ANY SYNONYM TO ICP_P;
  GRANT UNLIMITED TABLESPACE TO ICP_P;
  
-- 4 Object Privileges for ICP_P 
    GRANT SELECT ON SYS.DBA_2PC_PENDING TO ICP_P;
    GRANT SELECT ON SYS.DBA_PENDING_TRANSACTIONS TO ICP_P;
    GRANT EXECUTE ON SYS.DBMS_XA TO ICP_P;
    GRANT SELECT ON SYS.PENDING_TRANS$ TO ICP_P;
  
  
  -- 1 Role for ICP_IS 
  GRANT DBA TO ICP_IS;
  ALTER USER ICP_IS DEFAULT ROLE ALL;
  -- 8 System Privileges for ICP_IS 
  GRANT CREATE SEQUENCE TO ICP_IS;
  GRANT CREATE SESSION TO ICP_IS;
  GRANT CREATE TABLE TO ICP_IS;
  GRANT CREATE TRIGGER TO ICP_IS;
  GRANT CREATE USER TO ICP_IS;
  GRANT CREATE VIEW TO ICP_IS;
  GRANT DROP USER TO ICP_IS;
  GRANT UNLIMITED TABLESPACE TO ICP_IS;  
  

-- Drop the ICP_P_ROLE if it exists
DECLARE
 v_role number;
begin
  BEGIN
  select count(0) into v_role from dba_roles where ROLE = 'ICP_P_ROLE';
  EXCEPTION WHEN NO_DATA_FOUND THEN v_role := 0;
  END;
  
  IF v_role = 1 THEN
     execute immediate 'drop role ICP_P_ROLE';    
  END IF;  
end;    
/

-- Drop the ICP_IS_ROLE if it exists
DECLARE
 v_role number;
begin
  BEGIN
     select count(0) into v_role from dba_roles where ROLE = 'ICP_IS_ROLE';
  EXCEPTION WHEN NO_DATA_FOUND THEN v_role := 0;
  END;

  IF v_role = 1 THEN
     execute immediate 'drop role ICP_IS_ROLE';    
  END IF;  
end;    
/
  
