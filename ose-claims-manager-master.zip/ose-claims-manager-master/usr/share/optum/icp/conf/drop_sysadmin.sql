--
--  Connect as sa
--
--
--  05/08/2013     Jeff Evans
--
--  This is for version 5.0 and above.
--    It revokes the sysadmin role from ICP_IS.
--

EXEC sp_dropsrvrolemember 'icp_is', 'sysadmin'

