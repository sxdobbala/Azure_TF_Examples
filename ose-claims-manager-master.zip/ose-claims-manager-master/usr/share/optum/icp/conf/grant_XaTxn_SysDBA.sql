--
--  Connect as SYSDBA to run this script
--  This script grants the required XA Transaction permissions for the 
--    applicaion database user.
-- DO NOT REMOVE THIS LINE;

GRANT SELECT ON sys.dba_pending_transactions TO icp_p;
GRANT SELECT ON sys.pending_trans$ TO icp_p;
GRANT SELECT ON sys.dba_2pc_pending TO icp_p;
GRANT EXECUTE ON sys.dbms_xa TO icp_p;
