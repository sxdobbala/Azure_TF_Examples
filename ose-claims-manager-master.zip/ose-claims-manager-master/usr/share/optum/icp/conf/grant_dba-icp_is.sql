--
--  Connect as SYS or SYSTEM
--
--
--  05/08/2013     Jeff Evans
--
--  This is for version 5.0 and above.
--    It grants the DBA role to ICP_IS.
--

GRANT dba TO icp_is;

