---
title: CONCEPT SUCH AS Web Services in Azure Machine Learning in 59 chars or less. Include the name Azure Machine Learning. Test title here https://moz.com/learn/seo/title-tag 
description: This string describes the article in 115 to 145 characters. Use SEO kind of action verbs here. such as - Learn how to do this and that using customer words. This info is displayed on the search page inline with the article date stamp. If your intro para describes your article's intent, you can use it here edited for length.
services: machine-learning
ms.service: machine-learning
ms.subservice: core
ms.topic: conceptual
ms.reviewers: comma-seperated-list-of-reviewer-usernames
ms.author: your-ms-username
author: your-github-account-name
ms.date: 04/10/2018
---
# This is the H1 and the article title that shows on the web

## Section here H2 
Paragraph here. 
**This phrase is bold**
*This phrase is italics*

This is a [hyperlink to an article](template-concepts.md)

This is an image:

![This is an image description](media/overview-what-is-azure-ml/aml-concepts.png)

## Section here H2
This table has headings:

|Column1  |Column2  |Column3  |
|---------|---------|---------|
|Row1|Value 1|Value A|
|Row2|Value 2|Value B|
|Row3|Value 3|Value C|

## Section here H2
This is a numbered list:

1. First item

   This paragraph is indented to be the same spacing as the first numbered item.

2. Second item
   - this sentence is a bullet
   - this sentence is another bullet

3. Third item

4. Forth item

5. Fifth item

## This list is bulleted list:
- Item 1
- Item 2
- Item 3
  - Subitem 1
  - Subitem 2


## Next steps
For information about machine learning, see [Another article](template-concepts.md)