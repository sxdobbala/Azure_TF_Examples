(function (global) {
    //TODO: Figure out how to get typescript to load this file, so that it is able to just import "review" and it will use this to look the file up
    var config = {
        "defaultJSExtensions": true,
        map: {
            'app': 'app',
            'main': 'app/main',
            'antiforgery': 'app/antiforgery',
            'dependencies': 'app/dependencies',
            'ng-csv': 'scripts/ng-csv/ng-csv.js',
            'alerts': 'app/alerts',
            'events': 'app/events',
            'examplehospital': 'app/examplehospital/listhospital',
            'edithospital': 'app/examplehospital/edithospital',
            'examplehospitalcontainer': 'app/examplehospital',
            'userBanner': 'app/user-banner',
            'logoBanner': 'app/logo-banner',
            'assessmentContainer': 'app/assessmentContainer',
            'assessment': 'app/assessment',
            'header': 'app/header',
            'demographics': 'app/demographics',
            'letterList': 'app/letterList',
            'summary': 'app/summary',
            'summaryDate': 'app/summaryDate',
            'timeline': 'app/timeline',
            'assessmentList': 'app/assessmentList',
            'ocg': 'app/ocg',
            'errorAccess': 'app/errorAccess',
            'riskfactor': 'app/riskfactor',
            'recommendation': 'app/recommendation',
            'recommendation.details': 'app/recommendation/details',
            'completeAssessment': 'app/completeAssessment',
            'editdemographics': 'app/demographics/edit',
            'displaydemographics': 'app/demographics/display',
            'pageFooter': 'app/footer',
            'assessmentdateFilter': 'app/assessmentdateFilter',
            'byOcgByDay': 'app/shared/byOcgByDay',
            'routeHelper': 'app/shared/routeHelper',
            'ocgDay': 'app/ocg/ocgDay',
            'requiresDaysMessage': 'app/shared/requiresDaysMessage',
            'multidatepicker': 'app/controls/multidatepicker',
            'assessmentCompleteness': 'app/assessmentCompleteness',
            'ocgDetails': 'app/ocg/ocgDetails',
            'ocgSearch': 'app/ocg/ocgSearch',
            'serviceDayRiskFactors': 'app/serviceDayRiskFactors',
            'ocgKeywordFilter': 'app/ocg/ocgKeywordFilter',
            'uiselect': 'Scripts/ui-select',
            'helper': 'app/shared/helper',            
        },
        packages: {
            'dependencies': { main: 'dependencies.init.js' },
            'main': { main: 'main.init.js' },
            'antiforgery': { main: 'antiforgery.init.js' },
            'alerts': { main: 'alerts.init.js' },
            'events': { main: 'events.init.js' },
            'examplehospital': {
                main: 'examplehospital.init.js'
            },
            'edithospital': {
                main: 'edithospital.init.js'
            },
            'examplehospitalcontainer': {
                main: 'examplehospitalcontainer.init.js'
            },
            'userBanner': { main: 'userBanner.init.js' },
            'logoBanner': { main: 'logoBanner.init.js' },
            'assessmentContainer': {
                main: 'assessmentContainer.init.js'
            },
            'assessment': {
                main: 'assessment.init.js'
            },
            'header': {
                main: 'header.init.js'
            },
            'demographics': {
                main: 'demographics.init.js'
            },
            'letterList': {
                main: 'letter-list.init.js'
            },
            'summary': {
                main: 'summary.init.js'
            },
            'summaryDate': {
                main: 'summaryDate.init.js'
            },
            'timeline': {
                main: 'timeline.init.js'
            },
            'assessmentList': {
                main: 'assessmentList.init.js'
            },
            'ocg': {
                main: 'ocg.init.js'
            },
            'errorAccess': {
                main: 'errorAccess.init.js'
            },
            'riskfactor': {
                main: 'riskfactor.init.js'
            },
            'recommendation': {
                main: 'recommendation.init.js'
            },
            'recommendation.details': {
                main: 'recommendation.details.init.js'
            },
            'completeAssessment': {
                main: 'completeAssessment.init.js'
            },
            'editdemographics': {
                main: 'edit.init.js'
            },
            'displaydemographics': {
                main: 'display.init.js'
            },
            'pageFooter': { main: 'pageFooter.init.js' },
            'assessmentdateFilter': {
                main: 'assessmentdateFilter.init.js'
            },
            'byOcgByDay': { main: 'byOcgByDay.init.js' },
            'routeHelper': { main: 'routeHelper.init.js' },
            'ocgDay': { main: 'ocgDay.init.js' },
            'requiresDaysMessage': { main: 'requiresDaysMessage.init.js' },
            'multidatepicker': { main: 'multidatepicker.init.js' },
            'assessmentCompleteness': { main: 'assessmentCompleteness.init.js' },
            'ocgDetails': { main: 'ocgDetails.init.js' },
            'ocgSearch': { main: 'ocgSearch.init.js' },
            'serviceDayRiskFactors': { main: 'serviceDayRiskFactors.init.js' },
            'ocgKeywordFilter': { main: 'ocgKeywordFilter.init.js' },
            'uiselect': { main: 'select.js' },
            'helper': { main: 'helper.init.js' }
        }
    };

    System.config(config);
})(this);