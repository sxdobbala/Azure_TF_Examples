// Whenever possible, use Component bindings ("&", "<", "=") instead of events.
System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var EventService;
    return {
        setters:[],
        execute: function() {
            EventService = (function () {
                function EventService($q) {
                    this.$q = $q;
                    this.$inject = ['$q'];
                    // Event listeners have both a callback and id
                    this.listeners = {};
                    this.lastUniqueId = 0;
                }
                // Add a callback so that when the event is raised, the callback will be called.
                EventService.prototype.subscribe = function (actionName, callback, override) {
                    if (override === void 0) { override = false; }
                    if (actionName && typeof (callback) === 'function') {
                        if (this.listeners[actionName] == undefined || override)
                            this.listeners[actionName] = [];
                        var newlistener = {
                            id: this.lastUniqueId++,
                            actionName: actionName,
                            callback: callback
                        };
                        this.listeners[actionName].push(newlistener);
                        return newlistener;
                    }
                    else {
                        console.error('Error subscribing to event', actionName, callback);
                        return null;
                    }
                };
                // Remove the specified callback so that it will not be called when the event is raised
                EventService.prototype.unsubscribe = function (actionName, id) {
                    if (actionName && this.listeners[actionName]) {
                        this.listeners[actionName] = this.listeners[actionName].filter(function (x) { return x.id !== id; });
                    }
                };
                //Remove all callbacks for a specified event.
                EventService.prototype.empty = function (actionName) {
                    if (actionName && this.listeners[actionName]) {
                        this.listeners[actionName] = [];
                    }
                };
                // Raise an event to call the associated callbacks.
                // Returns a promise which resolves with a single parameter: an array values returned by the callbacks.
                EventService.prototype.raise = function (actionName, data) {
                    var promises = [];
                    try {
                        if (this.listeners[actionName]) {
                            for (var i = 0; i < this.listeners[actionName].length; i++) {
                                // If a listener returns a promise (such as a $http call) that will be added. 
                                // Otherwise the code executes immediately and $q wraps the result in a promise.
                                promises.push(this.$q.resolve(this.listeners[actionName][i].callback(data)));
                            }
                        }
                    }
                    catch (e) {
                        console.error('error raising event', actionName, this.listeners[actionName]);
                        promises.push(this.$q.reject('error raising event'));
                    }
                    // Return a promise that resolves only when all the listeners have completed.
                    return this.$q.all(promises);
                };
                EventService.serviceName = 'EventService';
                return EventService;
            }());
            exports_1("default", EventService);
        }
    }
});
//# sourceMappingURL=event.service.js.map