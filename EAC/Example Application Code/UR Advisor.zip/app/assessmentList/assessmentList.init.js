System.register(['./assessmentList.component', './assessmentList.service', 'assessmentdateFilter'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentList_component_1, assessmentList_service_1;
    return {
        setters:[
            function (assessmentList_component_1_1) {
                assessmentList_component_1 = assessmentList_component_1_1;
            },
            function (assessmentList_service_1_1) {
                assessmentList_service_1 = assessmentList_service_1_1;
            },
            function (_1) {}],
        execute: function() {
            angular
                .module('compass.assessmentList', ['compass.uitk', 'compass.assessmentdateFilter'])
                .component(assessmentList_component_1.default.componentName, new assessmentList_component_1.default())
                .service(assessmentList_service_1.default.serviceName, assessmentList_service_1.default);
        }
    }
});
//# sourceMappingURL=assessmentList.init.js.map