System.register(['../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                    this.filteredRecords = [];
                    this.totalRecordCount = 0;
                }
                default_1.prototype.getList = function (filterConditions) {
                    var self = this;
                    return self.$http.get(this.appConfig.urls.assessment, { params: filterConditions }).then(function (response) {
                        self.assessmentData = angular.copy(response.data);
                        self.filteredRecords = self.assessmentData.data.slice();
                        self.totalRecordCount = self.assessmentData.totalRecordsCount ? self.assessmentData.totalRecordsCount : 0;
                        // Convert string to DateTime format.
                        for (var _i = 0, _a = self.assessmentData.data; _i < _a.length; _i++) {
                            var assessment = _a[_i];
                            if (assessment.dateAdmitted) {
                                assessment.dateAdmitted = new Date(assessment.dateAdmitted.toString());
                            }
                            if (assessment.completedOn) {
                                assessment.completedOn = new Date(assessment.completedOn.toString());
                            }
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.serviceName = 'AssessmentListService';
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentList.service.js.map