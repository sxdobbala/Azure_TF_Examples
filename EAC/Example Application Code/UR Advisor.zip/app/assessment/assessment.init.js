//Registers dependencies with angular's DI container
System.register(['./assessment.component', './assessment.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessment_component_1, assessment_service_1;
    return {
        setters:[
            function (assessment_component_1_1) {
                assessment_component_1 = assessment_component_1_1;
            },
            function (assessment_service_1_1) {
                assessment_service_1 = assessment_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.assessment', ['compass.uitk'])
                .component(assessment_component_1.default.componentName, new assessment_component_1.default())
                .service(assessment_service_1.default.serviceName, assessment_service_1.default);
        }
    }
});
//# sourceMappingURL=assessment.init.js.map