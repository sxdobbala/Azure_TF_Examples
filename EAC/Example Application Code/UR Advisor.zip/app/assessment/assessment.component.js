System.register(["./assessment.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessment_controller_1;
    var default_1;
    return {
        setters:[
            function (assessment_controller_1_1) {
                assessment_controller_1 = assessment_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/assessment/assessment.html';
                    this.controller = assessment_controller_1.default;
                }
                default_1.componentName = 'assessment';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessment.component.js.map