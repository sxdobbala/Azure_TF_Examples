System.register(['./assessment.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessment_service_1;
    var default_1;
    return {
        setters:[
            function (assessment_service_1_1) {
                assessment_service_1 = assessment_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(assessmentService) {
                    this.assessmentService = assessmentService;
                }
                default_1.prototype.$routerOnActivate = function (routeData) {
                    this.assessmentId = routeData.params['id'] || 0;
                };
                default_1.$inject = [assessment_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessment.controller.js.map