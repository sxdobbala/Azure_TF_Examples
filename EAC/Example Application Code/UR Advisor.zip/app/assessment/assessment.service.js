System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($http, config) {
                    this.$http = $http;
                    this.config = config;
                }
                default_1.serviceName = 'assessmentService';
                default_1.$inject = ['$http', 'appConfig'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessment.service.js.map