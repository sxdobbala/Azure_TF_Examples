System.register(['alerts', 'userBanner', 'logoBanner', 'events', 'examplehospitalcontainer', 'edithospital', 'assessmentContainer', 'timeline', 'assessmentList', 'assessmentdateFilter', 'ocg', 'errorAccess', 'riskfactor', 'recommendation', 'completeAssessment', './main.component', 'dependencies', 'antiforgery', 'pageFooter', '../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var main_component_1, ajaxErrorService_service_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (_6) {},
            function (_7) {},
            function (_8) {},
            function (_9) {},
            function (_10) {},
            function (_11) {},
            function (_12) {},
            function (_13) {},
            function (_14) {},
            function (_15) {},
            function (main_component_1_1) {
                main_component_1 = main_component_1_1;
            },
            function (_16) {},
            function (_17) {},
            function (_18) {},
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.main', ['compass.uitk',
                'ngSanitize',
                'ngComponentRouter',
                'compass.antiforgery',
                'compass.alerts',
                'compass.events',
                'compass.examplehospitalcontainer',
                'ngComponentRouter',
                'compass.userBanner',
                'compass.logoBanner',
                'compass.assessmentContainer',
                'compass.timeline',
                'compass.assessmentList',
                'compass.ocg',
                'compass.riskfactor',
                'compass.recommendation',
                'compass.completeAssessment',
                'compass.pageFooter',
                'compass.assessmentdateFilter',
                'compass.errorAccess'
            ])
                .value('$routerRootComponent', main_component_1.default.componentName)
                .component(main_component_1.default.componentName, new main_component_1.default())
                .service(ajaxErrorService_service_1.default.serviceName, ajaxErrorService_service_1.default);
        }
    }
});
//# sourceMappingURL=main.init.js.map