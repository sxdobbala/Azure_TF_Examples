System.register(['./filters', '../alerts/alerts.factory'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var filters_1, alerts_factory_1;
    return {
        setters:[
            function (filters_1_1) {
                filters_1 = filters_1_1;
            },
            function (alerts_factory_1_1) {
                alerts_factory_1 = alerts_factory_1_1;
            }],
        execute: function() {
            angular
                .module('compass.main')
                .filter('tel', function () { return filters_1.default.formatTelephoneNumber; })
                .value('appConfig', {
                version: '1.0.1',
                debugMode: false,
                allowedCodeForExceptionLogging: [
                    401,
                    404,
                    405,
                    408,
                    414,
                    500,
                    503 // Service Unavailable.
                ],
                urls: {
                    errorLogging: 'api/ApplicationlogAPI/insertapplicationlog',
                    saveExampleHospital: 'api/ExampleHospitalAPI/Insert',
                    updateExampleHospital: 'api/ExampleHospitalAPI/Update',
                    deleteExampleHospital: 'api/ExampleHospitalAPI/Delete',
                    getExampleHospitalById: 'api/ExampleHospitalAPI/GetSingle',
                    getExampleHospitalAll: 'api/ExampleHospitalAPI/',
                    getAssessmentById: 'api/AssessmentAPI/GetSingle',
                    getAspnetUser: 'api/UserAPI/GetCurrentUserName',
                    getHospitalList: 'api/HospitalAPI/GetList',
                    getPayorList: 'api/PayorAPI/GetList',
                    getPatientStatus: 'api/PatientStatusAPI',
                    getOrderForReviewList: 'api/PatientStatusAPI/GetList',
                    getGenderList: 'api/GenderAPI/GetList',
                    insertDemographics: 'api/AssessmentAPI/Insert',
                    updateDemographics: 'api/AssessmentAPI/Update',
                    assessment: 'api/AssessmentAPI',
                    summaryList: 'api/AssessmentSummaryAPI',
                    getRecommendations: 'api/RecommendationAPI',
                    updateRecommendations: 'api/RecommendationAPI',
                    ocgServiceDays: 'api/OcgServiceDaysAPI',
                    protocolList: 'api/ProtocolApi',
                    protocolRules: 'api/ProtocolRulesApi',
                    getIsOcgComplete: 'api/AssessmentCompletenessAPI/GetIsOcgComplete',
                    getIsRiskFactorsComplete: 'api/AssessmentCompletenessAPI/GetIsRiskFactorsComplete',
                    getIsRecommendationComplete: 'api/AssessmentCompletenessAPI/GetIsRecommendationComplete',
                    getIsAssessmentComplete: 'api/AssessmentCompletenessAPI/GetIsAssessmentComplete',
                    ocgList: 'api/OptumClinicalGroupApi/GetList',
                    recommendationLetter: 'api/AssessmentDocumentAPI',
                    document: 'api/DocumentAPI',
                    ocgusage: 'api/ocgusageApi',
                    letterPreview: 'api/LetterApi/GetPreview',
                    generateLetter: 'api/LetterApi/GenerateLetter',
                    riskFactors: 'api/ServiceDayRiskFactorApi',
                    getAllKeywords: 'api/KeywordAPI/GetAllKeywords',
                    getConfigSetting: 'api/HelperApi/GetConfigSetting',
                }
            })
                .config(['$provide', '$httpProvider', function ($provide, $httpProvider) {
                    $provide.decorator('$log', ['$delegate', 'appConfig', alerts_factory_1.default.serviceName,
                        function ($delegate, constants, logger) {
                            if (constants.debugMode)
                                return $delegate;
                            $delegate.error = function () {
                                var args = [].slice.call(arguments);
                                logger.error(args[0], true);
                            };
                            $delegate.log = function () {
                                var args = [].slice.call(arguments);
                                logger.log(args[0], true);
                            };
                            $delegate.info = function () {
                                var args = [].slice.call(arguments);
                                logger.info(args[0], true);
                            };
                            $delegate.warn = function () {
                                var args = [].slice.call(arguments);
                                logger.warn(args[0], true);
                            };
                            $delegate.clear = function () {
                                logger.closeErrorAndWarning();
                            };
                            return $delegate;
                        }
                    ]);
                    $provide.decorator('$exceptionHandler', ['$delegate', 'appConfig', '$injector',
                        function ($delegate, constants, $injector) {
                            return function (exception, cause) {
                                var errorPrefix = 'COMPASS ';
                                if (exception.message && exception.message.indexOf(errorPrefix) === 0) {
                                    return;
                                }
                                //
                                //  Special case: This exception is thrown whenever you paste text into a uitkInput
                                //  under IE (discovered under 11; Chrome & FF are unaffected). The text is
                                //  successfully pasted into the control. Ref US369609 && HubConnect post at
                                //  https://hubconnect.uhg.com/message/356295#356295. The defect will be fixed in
                                //  a future version of the UITK, but until then there is no workaround.
                                if (exception.message && exception.message.toLowerCase().indexOf('unable to get property') >= 0
                                    && exception.message.indexOf('getData') >= 0
                                    && exception.message.toLowerCase().indexOf('undefined or null reference') >= 0) {
                                    return;
                                }
                                var msg = 'COMPASS Java Script' + exception.message;
                                if (constants.debugMode) {
                                    console.error(msg);
                                }
                                else {
                                    var $http = $injector.get("$http");
                                    console.error("Javascript Error: You've encountered an error, please try again");
                                    $http.post(constants.urls.errorLogging, { 'Message': msg, 'Url': window.location.href })
                                        .then(function successCallback(response) {
                                    }, function errorCallback(response) {
                                        console.error("Javascript Error: You've encountered an error, please try again");
                                    });
                                }
                            };
                        }
                    ]);
                    $provide.factory('compassHttpInterceptor', ['$q', '$injector', 'appConfig', '$filter',
                        function ($q, $injector, constants, $filter) {
                            return {
                                'responseError': function (rejection) {
                                    // Get the Error url, exception details and http status code.
                                    var errorUrl = rejection.config ? rejection.config.url : null;
                                    var data = 'COMPASS Ajax Error: ' + rejection.data ? [rejection.data.message, ':', rejection.data.exceptionMessage].join('') : null;
                                    var status = rejection.status ? rejection.status : 0;
                                    // If the error happens while logging the error then don't log it (to stop infinite loop).
                                    if (errorUrl.indexOf(constants.urls.errorLogging) !== -1) {
                                        return $q.reject(rejection);
                                    }
                                    // Send the exception details to server for selected status code.
                                    if (constants.allowedCodeForExceptionLogging &&
                                        constants.allowedCodeForExceptionLogging.indexOf(status) !== -1) {
                                        var $http = $injector.get("$http");
                                        $http.post(constants.urls.errorLogging, { 'Message': data, 'Url': errorUrl, StatusCode: status })
                                            .then(function successCallback(response) {
                                        }, function errorCallback(response) {
                                            console.error($filter('translate')('ajax_common_error'));
                                        });
                                    }
                                    return $q.reject(rejection);
                                }
                            };
                        }]);
                    $httpProvider.interceptors.push('compassHttpInterceptor');
                }])
                .config(['$translateProvider', function ($translateProvider) {
                    $translateProvider.useStaticFilesLoader({
                        files: [
                            // Application specific locale files. Create one file per language. 
                            // The locale is prefixed and suffixed as per the path configured below. 
                            {
                                prefix: 'scripts/i18n/compass-locale-',
                                suffix: '.json'
                            },
                            {
                                prefix: 'scripts/uitk-core/i18n/uitk-components-locale-',
                                suffix: '.json'
                            }
                        ]
                    });
                    $translateProvider.preferredLanguage('en_US'); //default language
                    $translateProvider.useSanitizeValueStrategy('escaped'); //for sanitization which avoids XSS issues
                }]);
        }
    }
});
//# sourceMappingURL=configs.js.map