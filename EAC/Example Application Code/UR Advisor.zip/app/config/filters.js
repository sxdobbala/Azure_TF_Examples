System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                }
                default_1.formatTelephoneNumber = function (telephoneNumber) {
                    /*
                      @param {Number | String} number - Number that will be formatted as telephone number
                      Returns formatted telephone number
                            number.length < 4: ###
                            number.length < 7: ###-###
                            number.length > 7: (###) ###-####
                    */
                    if (!telephoneNumber) {
                        return '';
                    }
                    telephoneNumber = String(telephoneNumber);
                    var formattedNumber = telephoneNumber;
                    // if the first character is '1', then it is the country code.
                    var countryCode = (telephoneNumber[0] === '1') ? '1 ' : '';
                    telephoneNumber = telephoneNumber[0] === '1' ? telephoneNumber.slice(1) : telephoneNumber;
                    // # (###) ###-####
                    var area = telephoneNumber.substring(0, 3);
                    var front = telephoneNumber.substring(3, 6);
                    var end = telephoneNumber.substring(6, 10);
                    if (front) {
                        formattedNumber = (countryCode + "(" + area + ") " + front);
                    }
                    if (end) {
                        formattedNumber += ("-" + end);
                    }
                    return formattedNumber;
                };
                ;
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=filters.js.map