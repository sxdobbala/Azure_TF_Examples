System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    function default_1($httpProvider) {
        var antiforgeryTokenName = '__RequestVerificationToken';
        //Delay execution until element is loaded on page
        $httpProvider.defaults.headers.common[antiforgeryTokenName] = $('[name="' + antiforgeryTokenName + '"]').val();
    }
    exports_1("default", default_1);
    return {
        setters:[],
        execute: function() {
            ;
        }
    }
});
//# sourceMappingURL=antiforgery.service.js.map