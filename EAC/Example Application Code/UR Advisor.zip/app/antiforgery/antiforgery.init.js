System.register(['./antiforgery.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var antiforgery_service_1;
    return {
        setters:[
            function (antiforgery_service_1_1) {
                antiforgery_service_1 = antiforgery_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.antiforgery', [])
                .config(antiforgery_service_1.default);
        }
    }
});
//# sourceMappingURL=antiforgery.init.js.map