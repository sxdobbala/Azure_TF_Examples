System.register(["./examplehospital.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var examplehospital_controller_1;
    var default_1;
    return {
        setters:[
            function (examplehospital_controller_1_1) {
                examplehospital_controller_1 = examplehospital_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/examplehospital/listhospital/examplehospital.html';
                    this.controller = examplehospital_controller_1.default;
                    this.bindings = {
                        refreshList: "="
                    };
                }
                default_1.componentName = 'examplehospital';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=examplehospital.component.js.map