System.register(['../examplehospital/edithospital/edithospital.service', '../examplehospital/listhospital/examplehospital.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var edithospital_service_1, examplehospital_service_1;
    var default_1;
    return {
        setters:[
            function (edithospital_service_1_1) {
                edithospital_service_1 = edithospital_service_1_1;
            },
            function (examplehospital_service_1_1) {
                examplehospital_service_1 = examplehospital_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(editExampleHospitalService, hospitalService, router) {
                    this.editExampleHospitalService = editExampleHospitalService;
                    this.hospitalService = hospitalService;
                    this.router = router;
                    this.showEdit = false;
                    this.showDelete = false;
                    this.hospital = { Id: 0, doDelete: false, doAdd: false };
                }
                default_1.prototype.doDelete = function () {
                    var self = this;
                    self.hospital = {};
                    self.refreshList = false;
                    self.hospital.doAdd = false;
                    self.hospital.doDelete = true;
                };
                default_1.prototype.doAdd = function (_doAdd) {
                    var self = this;
                    self.hospital = {};
                    self.refreshList = false;
                    self.hospital.doDelete = false;
                    self.hospital.doAdd = _doAdd;
                };
                default_1.$inject = [edithospital_service_1.default.serviceName, examplehospital_service_1.default.serviceName, '$rootRouter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=examplehospitalcontainer.controller.js.map