System.register(["./examplehospitalcontainer.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var examplehospitalcontainer_controller_1;
    var default_1;
    return {
        setters:[
            function (examplehospitalcontainer_controller_1_1) {
                examplehospitalcontainer_controller_1 = examplehospitalcontainer_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/examplehospital/examplehospitalcontainer.html';
                    this.controller = examplehospitalcontainer_controller_1.default;
                    this.bindings = {
                        refreshList: "="
                    };
                }
                default_1.componentName = 'examplehospitalcontainer';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=examplehospitalcontainer.component.js.map