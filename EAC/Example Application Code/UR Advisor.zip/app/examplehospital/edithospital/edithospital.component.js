System.register(["./edithospital.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var edithospital_controller_1;
    var default_1;
    return {
        setters:[
            function (edithospital_controller_1_1) {
                edithospital_controller_1 = edithospital_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/examplehospital/edithospital/edithospital.html';
                    this.controller = edithospital_controller_1.default;
                    this.bindings = {
                        hospital: "=",
                        refreshList: "="
                    };
                }
                default_1.componentName = 'edithospital';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=edithospital.component.js.map