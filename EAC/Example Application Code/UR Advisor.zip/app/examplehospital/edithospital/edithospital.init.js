//Registers dependencies with angular's DI container
System.register(['./edithospital.component', './edithospital.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var edithospital_component_1, edithospital_service_1;
    return {
        setters:[
            function (edithospital_component_1_1) {
                edithospital_component_1 = edithospital_component_1_1;
            },
            function (edithospital_service_1_1) {
                edithospital_service_1 = edithospital_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.edithospital', ['compass.uitk'])
                .component(edithospital_component_1.default.componentName, new edithospital_component_1.default())
                .service(edithospital_service_1.default.serviceName, edithospital_service_1.default);
        }
    }
});
//# sourceMappingURL=edithospital.init.js.map