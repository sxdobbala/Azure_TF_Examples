System.register(['./edithospital.service', '../listhospital/examplehospital.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var edithospital_service_1, examplehospital_service_1;
    var default_1;
    return {
        setters:[
            function (edithospital_service_1_1) {
                edithospital_service_1 = edithospital_service_1_1;
            },
            function (examplehospital_service_1_1) {
                examplehospital_service_1 = examplehospital_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(hospitalService, mainService, $scope) {
                    this.hospitalService = hospitalService;
                    this.mainService = mainService;
                    this.$scope = $scope;
                    var self = this;
                    $scope.$watch(function (s) { return self.hospital.Id; }, function (newValue, oldValue) {
                        if (newValue > 0) {
                            self.hospitalService.getHospital(newValue).then(function (response) {
                                if (response) {
                                    var _hospital = self.hospital;
                                    self.hospital = response;
                                    self.hospital.doAdd = _hospital.doAdd;
                                    self.hospital.doDelete = _hospital.doDelete;
                                }
                            });
                        }
                    });
                }
                default_1.prototype.updateHospital = function () {
                    var self = this;
                    this.hospitalService.saveHospital(self.hospital).then(function (response) {
                        if (true) {
                            var _hosptial = self.hospital;
                            self.hospital = {};
                            self.hospital.doAdd = _hosptial.doAdd;
                            self.hospital.doDelete = _hosptial.doDelete;
                            self.refreshList = true;
                        }
                    });
                };
                default_1.$inject = [edithospital_service_1.default.serviceName, examplehospital_service_1.default.serviceName, '$scope'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=edithospital.controller.js.map