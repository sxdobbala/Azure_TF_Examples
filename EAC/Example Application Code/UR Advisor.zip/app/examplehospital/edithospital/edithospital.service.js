System.register(['../../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                }
                default_1.prototype.saveHospital = function (hospital) {
                    var self = this;
                    var data = { "id": hospital.Id };
                    return hospital.doAdd ?
                        self.$http.put(this.appConfig.urls.saveExampleHospital, hospital).then(function (response) {
                            return response.data || false;
                        }, function (error) {
                            return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                        }) : !hospital.doDelete ?
                        self.$http.post(this.appConfig.urls.updateExampleHospital, hospital).then(function (response) {
                            return response.data || false;
                        }, function (error) {
                            return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                        }) :
                        self.$http.delete(this.appConfig.urls.deleteExampleHospital, { params: data }).then(function (response) {
                            return response.data || false;
                        }, function (error) {
                            return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                        });
                };
                default_1.prototype.getHospital = function (hospitalId) {
                    var self = this;
                    var data = { id: hospitalId };
                    return self.$http.get(this.appConfig.urls.getExampleHospitalById, { params: data }).then(function (response) {
                        if (response.data != null) {
                            response.data.Id = hospitalId;
                        }
                        return response.data || false;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                default_1.serviceName = 'EditHospitalService';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=edithospital.service.js.map