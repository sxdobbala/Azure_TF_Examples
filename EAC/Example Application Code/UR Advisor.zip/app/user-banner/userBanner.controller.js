System.register(['./userBanner.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var userBanner_service_1;
    var UserBannerController;
    return {
        setters:[
            function (userBanner_service_1_1) {
                userBanner_service_1 = userBanner_service_1_1;
            }],
        execute: function() {
            UserBannerController = (function () {
                function UserBannerController(window, Service) {
                    var _this = this;
                    this.window = window;
                    this.Service = Service;
                    this.globalNavigationModel = {
                        id: 'GlobalNavigation',
                        links: [
                            {}
                        ] };
                    Service.getUserData().then(function (data) {
                        var firstName = (data.data != null && data.data.firstName != null) ? data.data.firstName : "";
                        _this.globalNavigationModel.links = [
                            { profileName: firstName.length > 0 ? firstName : "" }
                        ];
                    });
                }
                UserBannerController.$inject = ['$window', userBanner_service_1.default.serviceName];
                return UserBannerController;
            }());
            exports_1("default", UserBannerController);
        }
    }
});
//# sourceMappingURL=userBanner.controller.js.map