//Registers dependencies with angular's DI container
System.register(['demographics', 'letterList', './header.component', './header.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var header_component_1, header_service_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (header_component_1_1) {
                header_component_1 = header_component_1_1;
            },
            function (header_service_1_1) {
                header_service_1 = header_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.header', ['compass.demographics', 'compass.letterList'])
                .service(header_service_1.default.serviceName, header_service_1.default)
                .component(header_component_1.default.componentName, new header_component_1.default());
        }
    }
});
//# sourceMappingURL=header.init.js.map