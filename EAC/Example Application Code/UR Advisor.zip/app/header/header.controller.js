System.register(['../letterList/letter-list.service', '../events/event.service', '../events/common.events', '../demographics/demographics.events', '../demographics/demographics.service', "../timeline/timeline.event", '../timeline/timeline.service', './header.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var letter_list_service_1, event_service_1, common_events_1, demographics_events_1, demographics_service_1, timelineEvents, timeline_service_1, header_service_1;
    var default_1;
    return {
        setters:[
            function (letter_list_service_1_1) {
                letter_list_service_1 = letter_list_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (common_events_1_1) {
                common_events_1 = common_events_1_1;
            },
            function (demographics_events_1_1) {
                demographics_events_1 = demographics_events_1_1;
            },
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            },
            function (timelineEvents_1) {
                timelineEvents = timelineEvents_1;
            },
            function (timeline_service_1_1) {
                timeline_service_1 = timeline_service_1_1;
            },
            function (header_service_1_1) {
                header_service_1 = header_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(letterService, eventService, $router, demographicsService, timelineService, service) {
                    this.letterService = letterService;
                    this.eventService = eventService;
                    this.$router = $router;
                    this.demographicsService = demographicsService;
                    this.timelineService = timelineService;
                    this.service = service;
                    /* END - 1 way bindings from Parent component*/
                    this.editMode = false;
                    this.showLetter = false;
                    this.data = [];
                    this.showExitConfirmation = false;
                    this.showDeleteConfirmationDialog = false;
                    this.deleteConfirmationDialogId = "deleteConfirmationDialogId";
                    this.eventList = [];
                    this.letterService.letterList = [];
                    this.subscribeToEvents();
                }
                default_1.prototype.$onChanges = function () {
                    this.editMode = this.assessmentId === 0;
                    if (this.assessmentId) {
                        this.getLetterList(false);
                    }
                };
                default_1.prototype.$onDestroy = function () {
                    this.unsubscribeEvents();
                };
                default_1.prototype.getLetterList = function (expandAfterLoad) {
                    var _this = this;
                    if (expandAfterLoad === void 0) { expandAfterLoad = true; }
                    this.data = this.letterService.letterList;
                    this.showLetter = false;
                    if (this.assessmentId > 0) {
                        this.letterService.getLetters(this.assessmentId).then(function () {
                            if (_this.data.length > 0 && expandAfterLoad) {
                                _this.showLetter = true;
                            }
                        });
                    }
                };
                default_1.prototype.subscribeToEvents = function () {
                    var _this = this;
                    var subscription = this.eventService.subscribe(common_events_1.RefreshLetterList, function (data) {
                        _this.getLetterList();
                    });
                    this.eventList.push(subscription);
                };
                default_1.prototype.unsubscribeEvents = function () {
                    var self = this;
                    for (var _i = 0, _a = self.eventList; _i < _a.length; _i++) {
                        var subscription = _a[_i];
                        self.eventService.unsubscribe(subscription.actionName, subscription.id);
                    }
                };
                default_1.prototype.onExit = function () {
                    var _this = this;
                    if (this.editMode) {
                        this.eventService.raise(demographics_events_1.demograhicsPageIsdirty).then(function () {
                            _this.checkForUnsavedChanges();
                        });
                    }
                    else {
                        this.checkForUnsavedChanges();
                    }
                };
                default_1.prototype.checkForUnsavedChanges = function () {
                    var _this = this;
                    this.eventService.raise(timelineEvents.isPageDirty).then(function () {
                        if (_this.demographicsService.isPageDirty() || _this.timelineService.isPageDirty()) {
                            _this.showExitConfirmation = true;
                        }
                        else {
                            _this.navigateToHome();
                        }
                    });
                };
                default_1.prototype.onExitConfirmation = function (exit) {
                    this.showExitConfirmation = false;
                    if (exit) {
                        this.navigateToHome();
                    }
                };
                default_1.prototype.navigateToHome = function () {
                    this.$router.navigate(['AssessmentList']);
                };
                default_1.prototype.onDelete = function () {
                    this.showDeleteConfirmationDialog = true;
                };
                default_1.prototype.onDeleteConfirmation = function (confirm) {
                    var _this = this;
                    this.showDeleteConfirmationDialog = false;
                    if (!confirm) {
                        return;
                    }
                    this.service.deleteAssessment(this.assessmentId).then(function (response) {
                        if (response) {
                            _this.navigateToHome();
                        }
                    });
                };
                default_1.prototype.hideDeleteConfirmationCloseLink = function () {
                    angular.element('#' + this.deleteConfirmationDialogId + '_closeLink').hide();
                };
                default_1.$inject = [letter_list_service_1.default.serviceName, event_service_1.default.serviceName, '$rootRouter', demographics_service_1.default.serviceName, timeline_service_1.TimelineService.serviceName, header_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=header.controller.js.map