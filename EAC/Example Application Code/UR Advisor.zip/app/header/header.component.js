System.register(["./header.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var header_controller_1;
    var default_1;
    return {
        setters:[
            function (header_controller_1_1) {
                header_controller_1 = header_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/header/header.html';
                    this.controller = header_controller_1.default;
                    this.bindings = {
                        assessmentId: '<'
                    };
                }
                default_1.componentName = 'headerContainer';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=header.component.js.map