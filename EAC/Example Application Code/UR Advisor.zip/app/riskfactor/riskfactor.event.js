System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var riskFactorOnPageError, riskFactorOnPageIncomplete, riskFactorOnPageComplete, riskFactorOnNavigationSave, riskFactorOnNavigationDiscard, riskFactorOnDateTabChangeSave, riskFactorPageIsdirty, riskFactorOnPageCheckRiskFactorCompleteness, riskFactorOnPageResetRiskFactorCompleteness;
    return {
        setters:[],
        execute: function() {
            exports_1("riskFactorOnPageError", riskFactorOnPageError = 'riskFactor.onPage.Error');
            exports_1("riskFactorOnPageIncomplete", riskFactorOnPageIncomplete = 'riskFactor.onPage.Incomplete');
            exports_1("riskFactorOnPageComplete", riskFactorOnPageComplete = 'riskFactor.onPage.Complete');
            exports_1("riskFactorOnNavigationSave", riskFactorOnNavigationSave = 'riskFactor.onNavigation.Save');
            exports_1("riskFactorOnNavigationDiscard", riskFactorOnNavigationDiscard = 'riskFactor.onNavigation.Discard');
            exports_1("riskFactorOnDateTabChangeSave", riskFactorOnDateTabChangeSave = 'riskFactor.onDateTabChange.Save');
            exports_1("riskFactorPageIsdirty", riskFactorPageIsdirty = 'riskFactor.Page.Isdirty');
            exports_1("riskFactorOnPageCheckRiskFactorCompleteness", riskFactorOnPageCheckRiskFactorCompleteness = 'riskFactor.onPage.Check.RiskFactor.Completeness');
            exports_1("riskFactorOnPageResetRiskFactorCompleteness", riskFactorOnPageResetRiskFactorCompleteness = 'riskFactor.onPage.Reset.RiskFactor.Completeness');
        }
    }
});
//# sourceMappingURL=riskfactor.event.js.map