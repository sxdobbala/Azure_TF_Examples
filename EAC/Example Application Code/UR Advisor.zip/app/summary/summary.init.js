System.register(['summaryDate', './summary.component', './summary.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summary_component_1, summary_service_1;
    return {
        setters:[
            function (_1) {},
            function (summary_component_1_1) {
                summary_component_1 = summary_component_1_1;
            },
            function (summary_service_1_1) {
                summary_service_1 = summary_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.summary', ['compass.uitk', 'compass.summaryDate'])
                .component(summary_component_1.default.componentName, new summary_component_1.default())
                .service(summary_service_1.default.serviceName, summary_service_1.default);
        }
    }
});
//# sourceMappingURL=summary.init.js.map