System.register(['./alerts.component', './alerts.factory'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var alerts_component_1, alerts_factory_1;
    return {
        setters:[
            function (alerts_component_1_1) {
                alerts_component_1 = alerts_component_1_1;
            },
            function (alerts_factory_1_1) {
                alerts_factory_1 = alerts_factory_1_1;
            }],
        execute: function() {
            //Dependencies will generally be determined by looking at the html file
            angular
                .module('compass.alerts', [])
                .factory(alerts_factory_1.default.serviceName, function () { return new alerts_factory_1.default(); })
                .component(alerts_component_1.default.componentName, new alerts_component_1.default());
        }
    }
});
//# sourceMappingURL=alerts.init.js.map