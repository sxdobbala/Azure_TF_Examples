System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.logger = {
                        success: { id: 'success-message', messageType: 'success', content: '<span></span>', visible: false, messageVisibleTime: 3000 },
                        error: { id: 'Error', messageType: 'error', content: '<span></span>', visible: false, animationTime: 1 },
                        warning: { id: 'Warning', messageType: 'warning', content: '<span></span>', visible: false },
                        info: { id: 'Information', messageType: 'information', content: '<span></span>', visible: false }
                    };
                }
                default_1.prototype.log = function (message, show) {
                    this.logger.success.content = ['<span>', message, '</span>'].join('');
                    this.logger.success.visible = show || true;
                };
                default_1.prototype.error = function (message, show) {
                    this.logger.error.content = ['<span>', message, '</span>'].join('');
                    this.logger.error.visible = show || true;
                };
                default_1.prototype.info = function (message, show) {
                    this.logger.info.content = ['<span>', message, '</span>'].join('');
                    this.logger.info.visible = show || true;
                };
                default_1.prototype.warn = function (message, show) {
                    this.logger.warning.content = ['<span>', message, '</span>'].join('');
                    this.logger.warning.visible = show || true;
                };
                default_1.prototype.closeError = function () {
                    this.logger.error.visible = false;
                };
                default_1.prototype.closeErrorAndWarning = function () {
                    this.closeError();
                    this.logger.warning.visible = false;
                };
                default_1.serviceName = 'alertsFactory';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=alerts.factory.js.map