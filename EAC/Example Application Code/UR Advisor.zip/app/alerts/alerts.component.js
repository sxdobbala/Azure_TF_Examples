System.register(["./alerts.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var alerts_controller_1;
    var default_1;
    return {
        setters:[
            function (alerts_controller_1_1) {
                alerts_controller_1 = alerts_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.controller = alerts_controller_1.default;
                    this.templateUrl = 'app/alerts/alerts.html';
                }
                default_1.componentName = 'alerts';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=alerts.component.js.map