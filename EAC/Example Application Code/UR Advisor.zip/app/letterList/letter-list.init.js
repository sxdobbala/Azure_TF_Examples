//Registers dependencies with angular's DI container
System.register(['./letter-list.component', './letter-list.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var letter_list_component_1, letter_list_service_1;
    return {
        setters:[
            function (letter_list_component_1_1) {
                letter_list_component_1 = letter_list_component_1_1;
            },
            function (letter_list_service_1_1) {
                letter_list_service_1 = letter_list_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.letterList', [])
                .service(letter_list_service_1.default.serviceName, letter_list_service_1.default)
                .component(letter_list_component_1.default.componentName, new letter_list_component_1.default());
        }
    }
});
//# sourceMappingURL=letter-list.init.js.map