System.register(["./errorAccess.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var errorAccess_controller_1;
    var default_1;
    return {
        setters:[
            function (errorAccess_controller_1_1) {
                errorAccess_controller_1 = errorAccess_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/errorAccess/error.html';
                    this.controller = errorAccess_controller_1.default;
                }
                default_1.componentName = 'errorAccess';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=errorAccess.component.js.map