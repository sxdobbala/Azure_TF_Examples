//Registers dependencies with angular's DI container
System.register(['./errorAccess.component', './errorAccess.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var errorAccess_component_1, errorAccess_service_1;
    return {
        setters:[
            function (errorAccess_component_1_1) {
                errorAccess_component_1 = errorAccess_component_1_1;
            },
            function (errorAccess_service_1_1) {
                errorAccess_service_1 = errorAccess_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.errorAccess', [])
                .component(errorAccess_component_1.default.componentName, new errorAccess_component_1.default())
                .service(errorAccess_service_1.default.serviceName, errorAccess_service_1.default);
        }
    }
});
//# sourceMappingURL=errorAccess.init.js.map