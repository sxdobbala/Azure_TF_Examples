System.register(['./serviceDayRiskFactors.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var serviceDayRiskFactors_controller_1;
    var default_1;
    return {
        setters:[
            function (serviceDayRiskFactors_controller_1_1) {
                serviceDayRiskFactors_controller_1 = serviceDayRiskFactors_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/serviceDayRiskFactors/serviceDayRiskFactors.html';
                    this.controller = serviceDayRiskFactors_controller_1.default;
                    this.bindings = {
                        /* One-way binding */
                        assessmentId: '<',
                        dayOfServiceId: '<',
                        protocol: '<'
                    };
                }
                default_1.componentName = 'serviceDayRiskFactors';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=serviceDayRiskFactors.component.js.map