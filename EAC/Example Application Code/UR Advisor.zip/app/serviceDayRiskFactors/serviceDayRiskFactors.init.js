System.register(['./serviceDayRiskFactors.component', './serviceDayRiskFactors.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var serviceDayRiskFactors_component_1, serviceDayRiskFactors_service_1;
    return {
        setters:[
            function (serviceDayRiskFactors_component_1_1) {
                serviceDayRiskFactors_component_1 = serviceDayRiskFactors_component_1_1;
            },
            function (serviceDayRiskFactors_service_1_1) {
                serviceDayRiskFactors_service_1 = serviceDayRiskFactors_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.serviceDayRiskFactors', [])
                .service(serviceDayRiskFactors_service_1.default.serviceName, serviceDayRiskFactors_service_1.default)
                .component(serviceDayRiskFactors_component_1.default.componentName, new serviceDayRiskFactors_component_1.default());
        }
    }
});
//# sourceMappingURL=serviceDayRiskFactors.init.js.map