System.register(['./logoBanner.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var logoBanner_component_1;
    return {
        setters:[
            function (logoBanner_component_1_1) {
                logoBanner_component_1 = logoBanner_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.logoBanner', ['compass.uitk'])
                .component(logoBanner_component_1.default.componentName, new logoBanner_component_1.default());
        }
    }
});
//# sourceMappingURL=logoBanner.init.js.map