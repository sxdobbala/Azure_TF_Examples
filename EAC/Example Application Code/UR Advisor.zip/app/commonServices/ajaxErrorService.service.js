System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($filter) {
                    this.$filter = $filter;
                }
                default_1.prototype.ShowCommonAjaxError = function (errorString) {
                    if (errorString.length > 0) {
                        if (this.CheckIfAccessError(errorString)) {
                            return;
                        }
                        console.error(errorString);
                        return false;
                    }
                    console.error(this.$filter('translate')('ajax_common_error'));
                    return false;
                };
                default_1.prototype.CheckIfAccessError = function (error) {
                    if (error == this.$filter('translate')('no_access_error')
                        || error == this.$filter('translate')('no_access_application_error')) {
                        location.href = "#!/errorAccess/"; //Need to set URL.  If you use the router i.e. router.navigate(), won't work.
                        location.reload(); // If you don't reload, all the angular promises will fire along with error messages.
                        return true;
                    }
                    return false;
                };
                default_1.serviceName = 'ajaxErrorService.service';
                default_1.$inject = ['$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ajaxErrorService.service.js.map