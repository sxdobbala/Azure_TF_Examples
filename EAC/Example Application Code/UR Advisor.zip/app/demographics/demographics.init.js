//Registers dependencies with angular's DI container
System.register(['editdemographics', 'displaydemographics', './demographics.component', './demographics.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var demographics_component_1, demographics_service_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (demographics_component_1_1) {
                demographics_component_1 = demographics_component_1_1;
            },
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.demographics', ['compass.editdemographics', 'compass.displaydemographics'])
                .component(demographics_component_1.default.componentName, new demographics_component_1.default())
                .service(demographics_service_1.default.serviceName, demographics_service_1.default);
        }
    }
});
//# sourceMappingURL=demographics.init.js.map