System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var demograhicsPageIsdirty;
    return {
        setters:[],
        execute: function() {
            exports_1("demograhicsPageIsdirty", demograhicsPageIsdirty = 'demographics.page.Isdirty');
        }
    }
});
//# sourceMappingURL=demographics.events.js.map