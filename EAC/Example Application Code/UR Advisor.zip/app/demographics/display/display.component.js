System.register(['./display.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var display_controller_1;
    var default_1;
    return {
        setters:[
            function (display_controller_1_1) {
                display_controller_1 = display_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.controller = display_controller_1.default;
                    this.templateUrl = "app/demographics/display/display.html";
                    this.bindings = {
                        assessment: '<',
                        editMode: '='
                    };
                }
                default_1.componentName = "displayDemographics";
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=display.component.js.map