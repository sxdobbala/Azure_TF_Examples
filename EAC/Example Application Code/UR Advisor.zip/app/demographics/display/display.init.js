System.register(['./display.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var display_component_1;
    return {
        setters:[
            function (display_component_1_1) {
                display_component_1 = display_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.displaydemographics', [])
                .component(display_component_1.default.componentName, new display_component_1.default());
        }
    }
});
//# sourceMappingURL=display.init.js.map