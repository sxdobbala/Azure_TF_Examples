System.register(['../demographics.service', '../../events/event.service', '../../completeAssessment/completeAssessment.event', '../demographics.events', '../../ocg/ocg.service', './edit.constant', '../../ocg/ocg.event', "../../timeline/timeline.event", '../../timeline/timeline.service', '../../recommendation/recommendation.event'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var demographics_service_1, event_service_1, completeAssessment_event_1, event_service_2, demographics_events_1, ocg_service_1, EditAssessmentConstant, ocg_event_1, timelineEvents, timeline_service_1, recommendation_event_1;
    var default_1;
    return {
        setters:[
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
                event_service_2 = event_service_1_1;
            },
            function (completeAssessment_event_1_1) {
                completeAssessment_event_1 = completeAssessment_event_1_1;
            },
            function (demographics_events_1_1) {
                demographics_events_1 = demographics_events_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (EditAssessmentConstant_1) {
                EditAssessmentConstant = EditAssessmentConstant_1;
            },
            function (ocg_event_1_1) {
                ocg_event_1 = ocg_event_1_1;
            },
            function (timelineEvents_1) {
                timelineEvents = timelineEvents_1;
            },
            function (timeline_service_1_1) {
                timeline_service_1 = timeline_service_1_1;
            },
            function (recommendation_event_1_1) {
                recommendation_event_1 = recommendation_event_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(demographicsService, event, $filter, $router, eventService, $scope, ocgService, timelineService) {
                    this.demographicsService = demographicsService;
                    this.event = event;
                    this.$filter = $filter;
                    this.$router = $router;
                    this.eventService = eventService;
                    this.$scope = $scope;
                    this.ocgService = ocgService;
                    this.timelineService = timelineService;
                    /* END - 2 way bindings from Parent component*/
                    this.assessmentEditModel = {};
                    this.hospitalList = [];
                    this.payorList = [];
                    this.orderForReviewList = [];
                    this.genderList = [];
                    this.showPayorChangeConfirmationDialog = false;
                    this.datesForProtocolChange = new Array();
                    this.showTimelineChangesDiscardConfirmationDialog = false;
                    this.timelineChangesDiscardConfirmationMessage = '';
                    this.firstNameError = false;
                    this.lastNameError = false;
                    this.emptyHospitalError = false;
                    this.emptyAccNumberError = false;
                    this.emptyPayorError = false;
                    this.emptyOrderForReviewError = false;
                    this.emptyGenderError = false;
                    this.emptySosError = false;
                    this.emptyAdminDateError = false;
                    this.emptyBirthDateError = false;
                    this.sosGreaterThanAdmindateError = false;
                    this.showCacNlpErrorDialog = false;
                    this.caclNlpErrorMessage = '';
                    this.messages = {};
                    this.payorChanged = false;
                    this.eventList = [];
                    this.createdAssessmentId = null;
                    this.setTranslation();
                    this.initalize();
                    this.formName = this.demographicsService.formName;
                    this.registerEvents();
                }
                default_1.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                default_1.prototype.$onChanges = function () {
                    this.demographicsService.setDirtyFlag(false);
                    this.setUpAssessment();
                    this.loadDropdowns();
                };
                default_1.prototype.initalize = function () {
                    var self = this;
                    self.hospitalList.push({ value: 0, label: '' });
                    self.payorList.push({ value: 0, label: '' });
                    self.orderForReviewList.push({ value: 0, label: '' });
                    self.genderList.push({ value: 0, label: '' });
                    self.inputFieldNameMaxLength = EditAssessmentConstant.inputFieldNameMaxLength;
                    self.inputFieldAccountMaxLength = EditAssessmentConstant.inputFieldAccountMaxLength;
                };
                default_1.prototype.setUpAssessment = function () {
                    var self = this;
                    angular.copy(self.assessment, self.assessmentEditModel);
                    if (self.assessmentEditModel.assessmentId > 0) {
                        self.assessmentEditModel.admitDate = new Date(self.assessmentEditModel.admitDate.toString());
                        self.assessmentEditModel.startOfServiceDate = new Date(self.assessmentEditModel.startOfServiceDate.toString());
                        self.assessmentEditModel.birthDate = new Date(self.assessmentEditModel.birthDate.toString());
                    }
                    else {
                        self.assessmentEditModel.admitDate = new Date('');
                        self.assessmentEditModel.startOfServiceDate = new Date('');
                        self.assessmentEditModel.birthDate = new Date('');
                        self.assessmentEditModel.hospital = { value: 0, label: '' };
                        self.assessmentEditModel.payor = { value: 0, label: '' };
                        self.assessmentEditModel.orderForReview = { value: 0, label: '' };
                        self.assessmentEditModel.gender = { value: 0, label: '' };
                    }
                    self.assessmentEditModel.admitDateViewModel = self.getDateViewModel();
                    self.assessmentEditModel.startOfServiceDateViewModel = self.getDateViewModel();
                    self.assessmentEditModel.birthDateViewModel = self.getDateViewModel();
                };
                default_1.prototype.getDateViewModel = function () {
                    return {
                        maxYear: new Date().getFullYear(),
                        renderHintText: true,
                        iconCalendar: true,
                    };
                };
                default_1.prototype.loadDropdowns = function () {
                    var self = this;
                    self.loadHospitalDropdown();
                    self.loadPayorDropdown();
                    self.loadOrderForReviewDropdown();
                    self.loadGenderDropdown();
                };
                default_1.prototype.loadHospitalDropdown = function () {
                    var self = this;
                    if (self.assessmentEditModel.hospital && angular.isDefined(self.assessmentEditModel.hospital.value)) {
                        if (self.demographicsService.hospitalList && self.demographicsService.hospitalList.length > 0) {
                            self.setupHospitalValue();
                        }
                        else {
                            self.demographicsService.getHospitalList().then(function (response) {
                                if (response) {
                                    self.setupHospitalValue();
                                }
                            });
                        }
                    }
                };
                default_1.prototype.setupHospitalValue = function () {
                    var self = this;
                    angular.copy(self.demographicsService.hospitalList, self.hospitalList);
                    if (self.assessmentEditModel.assessmentId === 0 && self.hospitalList.length === 1) {
                        self.assessmentEditModel.hospital = self.hospitalList[0];
                        return;
                    }
                    for (var _i = 0, _a = self.hospitalList; _i < _a.length; _i++) {
                        var hospital = _a[_i];
                        if (self.assessmentEditModel.hospital.value === hospital.value) {
                            self.assessmentEditModel.hospital = hospital;
                        }
                    }
                };
                default_1.prototype.loadPayorDropdown = function () {
                    var self = this;
                    if (self.assessmentEditModel.payor && angular.isDefined(self.assessmentEditModel.payor.value)) {
                        if (self.demographicsService.payorList && self.demographicsService.payorList.length > 0) {
                            self.setupPayorValue();
                        }
                        else {
                            self.demographicsService.getPayorList().then(function (response) {
                                if (response) {
                                    self.setupPayorValue();
                                }
                            });
                        }
                    }
                };
                default_1.prototype.setupPayorValue = function () {
                    var self = this;
                    angular.copy(self.demographicsService.payorList, self.payorList);
                    for (var _i = 0, _a = self.payorList; _i < _a.length; _i++) {
                        var payor = _a[_i];
                        if (self.assessmentEditModel.payor.value === payor.value) {
                            self.assessmentEditModel.payor = payor;
                        }
                    }
                };
                default_1.prototype.loadOrderForReviewDropdown = function () {
                    var self = this;
                    if (self.assessmentEditModel.orderForReview && angular.isDefined(self.assessmentEditModel.orderForReview.value)) {
                        if (self.demographicsService.orderForReviewList && self.demographicsService.orderForReviewList.length > 0) {
                            self.setupOrderForReviewValue();
                        }
                        else {
                            self.demographicsService.getOrderForReviewList().then(function (response) {
                                if (response) {
                                    self.setupOrderForReviewValue();
                                }
                            });
                        }
                    }
                };
                default_1.prototype.loadGenderDropdown = function () {
                    var self = this;
                    if (self.assessmentEditModel.gender && angular.isDefined(self.assessmentEditModel.gender.value)) {
                        if (self.demographicsService.genderList && self.demographicsService.genderList.length > 0) {
                            self.setupGenderValue();
                        }
                        else {
                            self.demographicsService.getGenderList().then(function (response) {
                                if (response) {
                                    self.setupGenderValue();
                                }
                            });
                        }
                    }
                };
                default_1.prototype.setupOrderForReviewValue = function () {
                    var self = this;
                    angular.copy(self.demographicsService.orderForReviewList, self.orderForReviewList);
                    for (var _i = 0, _a = self.orderForReviewList; _i < _a.length; _i++) {
                        var orderForReview = _a[_i];
                        if (self.assessmentEditModel.orderForReview.value === orderForReview.value) {
                            self.assessmentEditModel.orderForReview = orderForReview;
                        }
                    }
                };
                default_1.prototype.setupGenderValue = function () {
                    var self = this;
                    angular.copy(self.demographicsService.genderList, self.genderList);
                    for (var _i = 0, _a = self.genderList; _i < _a.length; _i++) {
                        var gender = _a[_i];
                        if (self.assessmentEditModel.gender.value === gender.value) {
                            self.assessmentEditModel.gender = gender;
                        }
                    }
                };
                default_1.prototype.saveAssessment = function () {
                    var self = this;
                    console.clear();
                    self.scrubData();
                    if (!self.validateAssessmentDemographics()) {
                        return;
                    }
                    self.payorChanged = self.hasPayorChanged();
                    if (self.payorChanged) {
                        self.setDatesForProtocolChange();
                        self.checkToShowPayorChangeDialog();
                        return;
                    }
                    document.body.style.cursor = 'wait';
                    self.save();
                };
                default_1.prototype.hasPayorChanged = function () {
                    var self = this;
                    if (self.assessmentEditModel.assessmentId === 0 || self.assessmentEditModel.payor.value === self.demographicsService.assessment.payor.value) {
                        return false;
                    }
                    return true;
                };
                default_1.prototype.setDatesForProtocolChange = function () {
                    var _this = this;
                    var self = this;
                    self.datesForProtocolChange = [];
                    self.datesForProtocolChange = self.ocgService.ocgServiceDays.filter(function (sd) {
                        return sd.protocol.label === EditAssessmentConstant.twoMidnightProtocol || sd.protocol.label === EditAssessmentConstant.progressiveStayProtocol;
                    }).map(function (sd) {
                        return _this.$filter('date')(sd.serviceDayDate, self.messages.dateFormat);
                    });
                };
                default_1.prototype.checkToShowPayorChangeDialog = function () {
                    if (this.datesForProtocolChange.length > 0) {
                        this.showPayorChangeConfirmationDialog = true;
                    }
                    else {
                        this.checkForTimelineUnsavedChanges();
                    }
                };
                default_1.prototype.onPayorChangeConfirmation = function (confirm) {
                    this.showPayorChangeConfirmationDialog = false;
                    if (confirm) {
                        this.checkForTimelineUnsavedChanges();
                    }
                };
                default_1.prototype.checkForTimelineUnsavedChanges = function () {
                    var _this = this;
                    this.currentTimelinePage = null;
                    this.eventService.raise(timelineEvents.isPageDirty).then(function (response) {
                        if (response && response[0]) {
                            _this.currentTimelinePage = response[0];
                            if ((_this.datesForProtocolChange.length > 0 || _this.currentTimelinePage.name === _this.timelineService.ocgPage.name) &&
                                _this.timelineService.isPageDirty()) {
                                _this.timelineChangesDiscardConfirmationMessage = _this.messages.demograpicsTimelineUnsavedChangesConfirmation.replace('{0}', _this.currentTimelinePage.displayText);
                                _this.showTimelineChangesDiscardConfirmationDialog = true;
                            }
                            else {
                                _this.save();
                            }
                        }
                    });
                };
                default_1.prototype.onTimelineChangesDiscardConfirmation = function (confirm) {
                    this.showTimelineChangesDiscardConfirmationDialog = false;
                    if (confirm) {
                        this.save();
                    }
                };
                default_1.prototype.save = function () {
                    var _this = this;
                    var self = this;
                    self.assessmentEditModel.formattedAdmitDate = this.$filter('date')(self.assessmentEditModel.admitDate, this.messages.dateFormat);
                    self.assessmentEditModel.formattedStartOfServiceDate = this.$filter('date')(self.assessmentEditModel.startOfServiceDate, this.messages.dateFormat);
                    self.assessmentEditModel.formattedBirthDate = this.$filter('date')(self.assessmentEditModel.birthDate, this.messages.dateFormat);
                    var assessmentModel = self.assessmentEditModel;
                    if (this.createdAssessmentId !== null) {
                        //The user hit "Go Back" is is now trying to save changes. Set the assessment ID so that the changes are reflected on the correct assessment.
                        //Copy the assessment first so that we don't actually change the model
                        assessmentModel = angular.copy(self.assessmentEditModel);
                        assessmentModel.assessmentId = this.createdAssessmentId;
                    }
                    self.demographicsService.saveAssessment(assessmentModel).then(function (response) {
                        if (response) {
                            if (response.assessmentSaveOutput && response.assessmentSaveOutput.assessmentId) {
                                //Record the ID so that we can update it if users need to go back and modify it
                                self.createdAssessmentId = response.assessmentSaveOutput.assessmentId;
                            }
                            if (response.nlpResponse && !response.nlpResponse.success) {
                                _this.caclNlpErrorMessage = response.nlpResponse.message;
                                _this.showCacNlpErrorDialog = true;
                            }
                            else {
                                self.continueToAssessmentDetail();
                            }
                        }
                    }).finally(function () {
                        document.body.style.cursor = 'default';
                    });
                };
                default_1.prototype.onSaveShowNlpErrorPopup = function (confirm) {
                    this.showCacNlpErrorDialog = false;
                    if (confirm) {
                        this.continueToAssessmentDetail();
                    }
                };
                default_1.prototype.continueToAssessmentDetail = function () {
                    var self = this;
                    self.handleNavigationPostSave();
                    self.refreshLetterPreview();
                    self.eventService.raise(recommendation_event_1.recommendationOnPageCheckCompleteness);
                    console.log(self.messages.saveAssessmentSuccess);
                };
                default_1.prototype.validateAssessmentDemographics = function () {
                    this.firstNameError = false;
                    this.lastNameError = false;
                    this.emptyHospitalError = false;
                    this.emptyAccNumberError = false;
                    this.emptyPayorError = false;
                    this.emptyOrderForReviewError = false;
                    this.emptyGenderError = false;
                    this.emptySosError = false;
                    this.emptyAdminDateError = false;
                    this.emptyBirthDateError = false;
                    this.sosGreaterThanAdmindateError = false;
                    var errorFields = this.validateMandatoryFields();
                    var errorMessages = new Array();
                    if (errorFields.length == 0) {
                        errorMessages = this.validateSosDate();
                    }
                    if (errorMessages.length > 0 || errorFields.length > 0) {
                        this.ShowValidationMessages(errorMessages, errorFields);
                        return false;
                    }
                    return true;
                };
                default_1.prototype.validateSosDate = function () {
                    var _this = this;
                    var errorMessages = new Array();
                    if (!this.assessmentEditModel.startOfServiceDate || this.assessmentEditModel.startOfServiceDate == null) {
                        return errorMessages;
                    }
                    if (this.assessmentEditModel.admitDate && this.assessmentEditModel.admitDate != null
                        && (this.assessmentEditModel.admitDate < this.assessmentEditModel.startOfServiceDate)) {
                        errorMessages.push(this.messages.admitDateIsBeforeSOS);
                    }
                    if (this.assessmentEditModel.assessmentId != 0 && this.ocgService.ocgServiceDays.some(function (sd) {
                        return sd.serviceDayDate && sd.serviceDayDate != null
                            && sd.serviceDayDate < _this.assessmentEditModel.startOfServiceDate;
                    })) {
                        errorMessages.push(this.messages.dayOfServiceIsBeforeSOS);
                    }
                    return errorMessages;
                };
                default_1.prototype.validateMandatoryFields = function () {
                    var errorFields = new Array();
                    if (!this.assessmentEditModel.firstName || this.assessmentEditModel.firstName === "" || this.assessmentEditModel.firstName === null) {
                        this.firstNameError = true;
                        errorFields.push(this.messages.emptyFirstNameValidation);
                    }
                    if (!this.assessmentEditModel.lastName || this.assessmentEditModel.lastName === "" || this.assessmentEditModel.lastName === null) {
                        this.lastNameError = true;
                        errorFields.push(this.messages.emptyLastNameValidation);
                    }
                    if (!this.assessmentEditModel.hospital.value || this.assessmentEditModel.hospital.value === 0 || this.assessmentEditModel.hospital.value === null) {
                        this.emptyHospitalError = true;
                        errorFields.push(this.messages.emptyHospitalValidation);
                    }
                    if (!this.assessmentEditModel.accountNumber || this.assessmentEditModel.accountNumber === "" || this.assessmentEditModel.accountNumber === null) {
                        this.emptyAccNumberError = true;
                        errorFields.push(this.messages.emptyAccNumValidation);
                    }
                    if (!this.assessmentEditModel.payor.value || this.assessmentEditModel.payor.value === 0 || this.assessmentEditModel.payor.value === null) {
                        this.emptyPayorError = true;
                        errorFields.push(this.messages.emptyPayorValidation);
                    }
                    if (!this.assessmentEditModel.startOfServiceDate || this.assessmentEditModel.startOfServiceDate == null || this.assessmentEditModel.startOfServiceDateViewModel.invalid || this.assessmentEditModel.startOfServiceDate.toString() === 'Invalid Date') {
                        this.emptySosError = true;
                        errorFields.push(this.messages.emptySOSValidation);
                    }
                    if (!this.assessmentEditModel.admitDate || this.assessmentEditModel.admitDate == null || this.assessmentEditModel.admitDateViewModel.invalid || this.assessmentEditModel.admitDate.toString() === 'Invalid Date') {
                        this.emptyAdminDateError = true;
                        errorFields.push(this.messages.emptyAdminDateValidation);
                    }
                    if (!this.assessmentEditModel.birthDate || this.assessmentEditModel.birthDate == null || this.assessmentEditModel.birthDateViewModel.invalid || this.assessmentEditModel.birthDate.toString() === 'Invalid Date') {
                        this.emptyBirthDateError = true;
                        errorFields.push(this.messages.emptyBirthDateValidation);
                    }
                    if (!this.assessmentEditModel.orderForReview.value || this.assessmentEditModel.orderForReview.value === 0 || this.assessmentEditModel.orderForReview.value === null) {
                        this.emptyOrderForReviewError = true;
                        errorFields.push(this.messages.emptyOrderForReviewValidation);
                    }
                    if (!this.assessmentEditModel.gender.value || this.assessmentEditModel.gender.value === null) {
                        this.emptyGenderError = true;
                        errorFields.push(this.messages.emptyGenderValidation);
                    }
                    return errorFields;
                };
                default_1.prototype.handleNavigationPostSave = function () {
                    var self = this;
                    if (self.assessmentEditModel.assessmentId === 0) {
                        self.$router.navigate(['EditAssessment', { id: self.demographicsService.insertedAssessmentId }]);
                    }
                    else if (self.datesForProtocolChange.length > 0) {
                        //Assessment modification-Payor change-HAS dates with ProgressiveStay/2Midnight protocol
                        this.pageRefresh();
                    }
                    else if (self.payorChanged && this.currentTimelinePage.name === this.timelineService.ocgPage.name) {
                        //Assessment modification-Payor change-NO dates with ProgressiveStay/2Midnight protocol
                        //Refresh the page only if the current view is OCG - to refresh the protocol dropdowns          
                        this.pageRefresh();
                    }
                    else {
                        var previousSos = self.demographicsService.assessment.startOfServiceDate;
                        angular.copy(self.assessmentEditModel, self.demographicsService.assessment);
                        if (previousSos.getTime() !== self.assessmentEditModel.startOfServiceDate.getTime()) {
                            this.event.raise(ocg_event_1.ocgSetupDefaultProtocol);
                            this.event.raise(ocg_event_1.ocgReCalculateDefaultProtocols);
                        }
                        self.editMode = false;
                    }
                };
                default_1.prototype.pageRefresh = function () {
                    if (this.demographicsService.assessment.startOfServiceDate.getTime() !== this.assessmentEditModel.startOfServiceDate.getTime()) {
                        this.demographicsService.recalculateDefaultProtocols = true;
                    }
                    this.$router.navigate(['EditAssessment', { id: 0 }]); //force-refresh
                    this.$router.navigate(['EditAssessment', { id: this.assessmentEditModel.assessmentId }]);
                };
                default_1.prototype.refreshLetterPreview = function () {
                    // Refresh letter preview only if it is modified (not created).
                    if (this.assessmentEditModel.assessmentId !== 0) {
                        this.event.raise(completeAssessment_event_1.refreshPreview);
                    }
                };
                default_1.prototype.ShowValidationMessages = function (errorMessages, errorFields) {
                    var error = "";
                    if (errorFields.length > 0) {
                        error = ['<li class="tk-padding-bottom-min">',
                            '<div class="tk-display-inline-block">' + this.messages.demographicsValidation + errorFields.join(', ') + '</div></li>',
                        ].join('');
                    }
                    if (errorMessages.length > 0) {
                        error += [
                            '<li class="tk-padding-bottom-min">',
                            errorMessages.join('</li><li class="tk-padding-bottom-min">') + '</li>'
                        ].join('');
                    }
                    console.error('<ul>' + error + '</ul>');
                };
                default_1.prototype.setTranslation = function () {
                    this.messages.saveAssessmentSuccess = this.$filter('translate')('demographics_save_success');
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                    this.messages.emptyFirstNameValidation = this.$filter('translate')('demographics_label_first_name');
                    this.messages.emptyLastNameValidation = this.$filter('translate')('demographics_label_last_name');
                    this.messages.emptyHospitalValidation = this.$filter('translate')('demographics_label_hospital');
                    this.messages.emptyAccNumValidation = this.$filter('translate')('demographics_label_account_number');
                    this.messages.emptyPayorValidation = this.$filter('translate')('demographics_label_payor');
                    this.messages.emptySOSValidation = this.$filter('translate')('demographics_label_start_of_service_date');
                    this.messages.emptyAdminDateValidation = this.$filter('translate')('demographics_label_admit_date');
                    this.messages.emptyBirthDateValidation = this.$filter('translate')('demographics_label_birth_date');
                    this.messages.emptyOrderForReviewValidation = this.$filter('translate')('demographics_label_order_for_review');
                    this.messages.emptyGenderValidation = this.$filter('translate')('demographics_label_gender');
                    this.messages.demographicsValidation = this.$filter('translate')('demographics_validation');
                    this.messages.admitDateIsBeforeSOS = this.$filter('translate')('demographics_admitDate_is_before_SOS_date');
                    this.messages.dayOfServiceIsBeforeSOS = this.$filter('translate')('demographics_serviceDay_is_before_SOS_date');
                    this.messages.demograpicsTimelineUnsavedChangesConfirmation = this.$filter('translate')('demographics_timeline_unsaved_changes_confirmation');
                };
                default_1.prototype.onCancel = function () {
                    this.demographicsService.setDirtyFlag(false);
                    this.editMode = false;
                };
                default_1.prototype.scrubData = function () {
                    var self = this;
                    self.assessmentEditModel.accountNumber = self.assessmentEditModel.accountNumber.trim();
                    self.assessmentEditModel.firstName = self.formatTitleCase(self.assessmentEditModel.firstName.trim());
                    self.assessmentEditModel.lastName = self.formatTitleCase(self.assessmentEditModel.lastName.trim());
                    self.assessmentEditModel.middleName = self.formatTitleCase(self.assessmentEditModel.middleName.trim());
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    var subscription = this.eventService.subscribe(demographics_events_1.demograhicsPageIsdirty, function () {
                        _this.demographicsService.setDirtyFlag(_this.$scope[_this.formName].$dirty);
                    });
                    this.eventList.push(subscription);
                };
                default_1.prototype.unRegisterEvents = function () {
                    var self = this;
                    self.demographicsService.setDirtyFlag(false);
                    for (var _i = 0, _a = self.eventList; _i < _a.length; _i++) {
                        var subscription = _a[_i];
                        self.event.unsubscribe(subscription.actionName, subscription.id);
                    }
                };
                default_1.prototype.formatTitleCase = function (text) {
                    if (!text)
                        return text;
                    var textProcessed = text.split(' ').map(function (word) {
                        return (word.charAt(0).toUpperCase() + word.slice(1));
                    }).join(' ');
                    textProcessed = textProcessed.split('-').map(function (word) {
                        return (word.charAt(0).toUpperCase() + word.slice(1));
                    }).join('-');
                    return textProcessed.split('\'').map(function (word) {
                        return (word.charAt(0).toUpperCase() + word.slice(1));
                    }).join('\'');
                };
                default_1.$inject = [demographics_service_1.default.serviceName, event_service_1.default.serviceName, '$filter', '$rootRouter', event_service_2.default.serviceName, '$scope', ocg_service_1.default.serviceName, timeline_service_1.TimelineService.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=edit.controller.js.map