System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var inputFieldNameMaxLength, inputFieldAccountMaxLength, progressiveStayProtocol, twoMidnightProtocol;
    return {
        setters:[],
        execute: function() {
            exports_1("inputFieldNameMaxLength", inputFieldNameMaxLength = 50);
            exports_1("inputFieldAccountMaxLength", inputFieldAccountMaxLength = 100);
            exports_1("progressiveStayProtocol", progressiveStayProtocol = 'Progressive Stay');
            exports_1("twoMidnightProtocol", twoMidnightProtocol = 'Two Midnight');
        }
    }
});
//# sourceMappingURL=edit.constant.js.map