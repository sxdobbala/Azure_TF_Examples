System.register(['./demographics.service', '../ocg/ocg.service', '../ProtocolRules/ProtocolRules.service', '../events/event.service', '../ocg/ocg.event'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var demographics_service_1, ocg_service_1, ProtocolRules_service_1, event_service_1, ocg_event_1;
    var default_1;
    return {
        setters:[
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (ProtocolRules_service_1_1) {
                ProtocolRules_service_1 = ProtocolRules_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (ocg_event_1_1) {
                ocg_event_1 = ocg_event_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(demographicsService, $filter, ocgService, protocolRulesService, eventService) {
                    this.demographicsService = demographicsService;
                    this.$filter = $filter;
                    this.ocgService = ocgService;
                    this.protocolRulesService = protocolRulesService;
                    this.eventService = eventService;
                    /* END - 2 way bindings for child components*/
                    this.messages = {};
                    this.suggestedProtocolsList = [];
                    this.eventList = [];
                    this.registerEvents();
                    this.setTranslation();
                }
                default_1.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                default_1.prototype.setTranslation = function () {
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                };
                default_1.prototype.$onChanges = function () {
                    this.intialize();
                };
                default_1.prototype.intialize = function () {
                    var _this = this;
                    var self = this;
                    self.setupEmptyAssessment();
                    self.assessment = self.demographicsService.assessment;
                    if (self.assessmentId && self.assessmentId > 0) {
                        self.demographicsService.getAssessment(self.assessmentId).then(function (response) {
                            if (response) {
                                self.assessment.formattedAdmitDate = _this.$filter('date')(self.assessment.admitDate, _this.messages.dateFormat);
                                self.assessment.formattedStartOfServiceDate = _this.$filter('date')(self.assessment.startOfServiceDate, _this.messages.dateFormat);
                                self.assessment.formattedBirthDate = _this.$filter('date')(self.assessment.birthDate, _this.messages.dateFormat);
                            }
                        });
                        this.checkToRecalculateDefaultProtocols();
                    }
                };
                default_1.prototype.setupEmptyAssessment = function () {
                    var self = this;
                    self.demographicsService.assessment = {
                        assessmentId: 0
                    };
                };
                default_1.prototype.checkToRecalculateDefaultProtocols = function () {
                    var self = this;
                    //if the page refresh happens because of payor change- and SOS is also changed at the same time, this boolean is set
                    if (self.demographicsService.recalculateDefaultProtocols) {
                        self.protocolRulesService.loadProtocolRules(self.assessmentId).then(function () {
                            self.ocgService.getOcgServiceDays(self.assessmentId).then(function () {
                                self.reCalculateDefaultProtocols();
                            });
                        });
                    }
                    self.demographicsService.recalculateDefaultProtocols = false;
                };
                default_1.prototype.reCalculateDefaultProtocols = function () {
                    var _this = this;
                    var _loop_1 = function(serviceDay) {
                        if (serviceDay.protocol.value !== 0) {
                            this_1.protocolRulesService.getDefaultProtocol(serviceDay.serviceDayDate, serviceDay.ccd)
                                .then(function (response) {
                                if (response) {
                                    if (response.defaultProtocol.value !== serviceDay.protocol.value) {
                                        _this.suggestedProtocolsList.push({
                                            serviceDate: _this.$filter('date')(serviceDay.serviceDayDate, _this.messages.dateFormat),
                                            protocol: response.defaultProtocol
                                        });
                                        _this.showSuggestedProtocolsDialog = true;
                                    }
                                }
                            });
                        }
                    };
                    var this_1 = this;
                    for (var _i = 0, _a = this.ocgService.ocgServiceDays; _i < _a.length; _i++) {
                        var serviceDay = _a[_i];
                        _loop_1(serviceDay);
                    }
                };
                default_1.prototype.hideSuggestedProtocolDialog = function () {
                    this.suggestedProtocolsList = [];
                    this.showSuggestedProtocolsDialog = false;
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    var self = this;
                    var subscription = this.eventService.subscribe(ocg_event_1.ocgReCalculateDefaultProtocols, function () {
                        _this.reCalculateDefaultProtocols();
                    });
                    self.eventList.push(subscription);
                };
                default_1.prototype.unRegisterEvents = function () {
                    var self = this;
                    for (var _i = 0, _a = self.eventList; _i < _a.length; _i++) {
                        var subscription = _a[_i];
                        self.eventService.unsubscribe(subscription.actionName, subscription.id);
                    }
                };
                default_1.$inject = [demographics_service_1.default.serviceName, '$filter', ocg_service_1.default.serviceName, ProtocolRules_service_1.default.serviceName, event_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=demographics.controller.js.map