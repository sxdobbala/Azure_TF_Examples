System.register(['../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService, $filter) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                    this.$filter = $filter;
                    this.hospitalList = [];
                    this.payorList = [];
                    this.orderForReviewList = [];
                    this.genderList = [];
                    this.messages = {};
                    this.formName = 'assessmentForm';
                    this.recalculateDefaultProtocols = false;
                    this.isDirty = false;
                    this.setTranslation();
                }
                default_1.prototype.setTranslation = function () {
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                };
                default_1.prototype.getAssessment = function (assessmentId) {
                    var self = this;
                    var data = { id: assessmentId };
                    return self.$http.get(this.appConfig.urls.getAssessmentById, { params: data }).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.assessment);
                            self.assessment.admitDate = new Date(self.assessment.admitDate.toString());
                            self.assessment.startOfServiceDate = new Date(self.assessment.startOfServiceDate.toString());
                            self.assessment.birthDate = new Date(self.assessment.birthDate.toString());
                            self.assessment.formattedAdmitDate = self.$filter('date')(self.assessment.admitDate, self.messages.dateFormat);
                            self.assessment.formattedStartOfServiceDate = self.$filter('date')(self.assessment.startOfServiceDate, self.messages.dateFormat);
                            self.assessment.formattedBirthDate = self.$filter('date')(self.assessment.birthDate, self.messages.dateFormat);
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getHospitalList = function () {
                    var self = this;
                    return self.$http.get(this.appConfig.urls.getHospitalList).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.hospitalList);
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getPayorList = function () {
                    var self = this;
                    return self.$http.get(this.appConfig.urls.getPayorList).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.payorList);
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getOrderForReviewList = function () {
                    var self = this;
                    return self.$http.get(this.appConfig.urls.getOrderForReviewList).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.orderForReviewList);
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getGenderList = function () {
                    var self = this;
                    return self.$http.get(this.appConfig.urls.getGenderList).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.genderList);
                        }
                        return true;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.saveAssessment = function (assessment) {
                    if (assessment.assessmentId > 0) {
                        return this.updateDemograhics(assessment);
                    }
                    return this.insertDemograhics(assessment);
                };
                default_1.prototype.updateDemograhics = function (assessment) {
                    var self = this;
                    var assessmentUpdateModel = self.getAssessmentUpdateModel(assessment);
                    return self.$http.post(this.appConfig.urls.updateDemographics, assessmentUpdateModel).then(function (response) {
                        return response.data;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.insertDemograhics = function (assessment) {
                    var self = this;
                    self.insertedAssessmentId = 0;
                    var assessmentInsertModel = self.getAssessmentInsertModel(assessment);
                    return self.$http.put(this.appConfig.urls.insertDemographics, assessmentInsertModel).then(function (response) {
                        if (response.data && response.data.assessmentSaveOutput.assessmentId > 0) {
                            self.insertedAssessmentId = response.data.assessmentSaveOutput.assessmentId;
                        }
                        return response.data;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getAssessmentUpdateModel = function (assessment) {
                    var self = this;
                    var assessmentUpdateModel = self.getAssessmentInsertModel(assessment);
                    assessmentUpdateModel.EncounterId = assessment.encounterId;
                    return assessmentUpdateModel;
                };
                default_1.prototype.getAssessmentInsertModel = function (assessment) {
                    return {
                        assessmentId: assessment.assessmentId,
                        firstName: assessment.firstName,
                        middleName: assessment.middleName,
                        lastName: assessment.lastName,
                        hospitalId: assessment.hospital.value,
                        admitDate: assessment.formattedAdmitDate,
                        startOfServiceDate: assessment.formattedStartOfServiceDate,
                        birthDate: assessment.formattedBirthDate,
                        accountNumber: assessment.accountNumber,
                        orderForReviewId: assessment.orderForReview.value,
                        genderId: assessment.gender.value,
                        payorId: assessment.payor.value
                    };
                };
                default_1.prototype.isPageDirty = function () {
                    return this.isDirty;
                };
                default_1.prototype.setDirtyFlag = function (flag) {
                    return this.isDirty = flag;
                };
                default_1.serviceName = 'demographicsService';
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName, '$filter', '$rootRouter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=demographics.service.js.map