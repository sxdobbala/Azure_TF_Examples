System.register(['./pageFooter.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var pageFooter_component_1;
    return {
        setters:[
            function (pageFooter_component_1_1) {
                pageFooter_component_1 = pageFooter_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.pageFooter', ['compass.uitk'])
                .component(pageFooter_component_1.default.componentName, new pageFooter_component_1.default());
        }
    }
});
//# sourceMappingURL=pageFooter.init.js.map