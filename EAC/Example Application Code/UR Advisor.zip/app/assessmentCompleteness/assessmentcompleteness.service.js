System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, $filter, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.$filter = $filter;
                    this.ajaxErrorService = ajaxErrorService;
                    this.messages = {};
                    this.setTranslation();
                }
                // Completeness Methods
                default_1.prototype.checkForOcgDataCompleteness = function (assessmentId) {
                    var _this = this;
                    var that = this;
                    var data = { assessmentId: assessmentId };
                    return that.$http.get(this.appConfig.urls.getIsOcgComplete, { params: data }).then(function (response) {
                        return response.data;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.checkForRiskFactorsDataCompleteness = function (assessmentId) {
                    var _this = this;
                    var that = this;
                    var data = { assessmentId: assessmentId };
                    return that.$http.get(this.appConfig.urls.getIsRiskFactorsComplete, { params: data }).then(function (response) {
                        return response.data;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.checkForRecommendationDataCompleteness = function (assessmentId) {
                    var _this = this;
                    var that = this;
                    var data = { assessmentId: assessmentId };
                    return that.$http.get(this.appConfig.urls.getIsRecommendationComplete, { params: data }).then(function (response) {
                        return response.data;
                    }, function (error) {
                        if (error.data == _this.messages.recommCompletenessCheckFailure) {
                            console.error(_this.messages.recommCompletenessCheckFailure);
                            return false;
                        }
                        else {
                            return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                        }
                    });
                };
                default_1.prototype.checkForAssessmentCompleteness = function (assessmentId) {
                    var _this = this;
                    var that = this;
                    var data = { assessmentId: assessmentId };
                    return that.$http.get(this.appConfig.urls.getIsAssessmentComplete, { params: data }).then(function (response) {
                        return response.data;
                    }, function (error) {
                        if (error.data == _this.messages.assessmentCompletenessValidationFailure) {
                            console.error(_this.messages.assessmentCompletenessValidationFailure);
                            return false;
                        }
                        else {
                            return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                        }
                    });
                };
                // Translation Method
                default_1.prototype.setTranslation = function () {
                    this.messages.assessmentCompletenessCheckFailure = this.$filter('translate')('assessmentcompleteness_check_failure');
                    this.messages.ocgCompletenessCheckFailure = this.$filter('translate')('assessmentcompleteness_ocg_check_failure');
                    this.messages.riskFactorsCompletenessCheckFailure = this.$filter('translate')('assessmentcompleteness_risk_factors_check_failure');
                    this.messages.recommCompletenessCheckFailure = this.$filter('translate')('assessmentcompleteness_final_recomm_check_failure');
                    this.messages.assessmentCompletenessValidationFailure = this.$filter('translate')('assessmentcompleteness_validation_failure');
                };
                default_1.serviceName = 'assessmentcompletenessService';
                default_1.$inject = ['$http', 'appConfig', '$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentcompleteness.service.js.map