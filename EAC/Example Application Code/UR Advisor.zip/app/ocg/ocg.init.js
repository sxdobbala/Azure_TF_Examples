System.register(['./ocg.component', './ocg.service', '../ProtocolRules/ProtocolRules.service', 'ocgDay', 'ocgDetails'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_component_1, ocg_service_1, ProtocolRules_service_1;
    return {
        setters:[
            function (ocg_component_1_1) {
                ocg_component_1 = ocg_component_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (ProtocolRules_service_1_1) {
                ProtocolRules_service_1 = ProtocolRules_service_1_1;
            },
            function (_1) {},
            function (_2) {}],
        execute: function() {
            angular
                .module('compass.ocg', ['compass.ocgDay', 'compass.ocgDetails'])
                .service(ocg_service_1.default.serviceName, ocg_service_1.default)
                .service(ProtocolRules_service_1.default.serviceName, ProtocolRules_service_1.default)
                .component(ocg_component_1.default.componentName, new ocg_component_1.default());
        }
    }
});
//# sourceMappingURL=ocg.init.js.map