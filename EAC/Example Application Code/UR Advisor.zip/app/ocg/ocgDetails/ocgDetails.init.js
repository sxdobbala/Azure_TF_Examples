System.register(['./ocgDetails.component', 'ocgKeywordFilter', 'ocgSearch'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgDetails_component_1;
    return {
        setters:[
            function (ocgDetails_component_1_1) {
                ocgDetails_component_1 = ocgDetails_component_1_1;
            },
            function (_1) {},
            function (_2) {}],
        execute: function() {
            angular
                .module('compass.ocgDetails', ['compass.ocgSearch', 'compass.ocgKeywordFilter'])
                .component(ocgDetails_component_1.default.componentName, new ocgDetails_component_1.default());
        }
    }
});
//# sourceMappingURL=ocgDetails.init.js.map