System.register(['./ocg.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_controller_1;
    var default_1;
    return {
        setters:[
            function (ocg_controller_1_1) {
                ocg_controller_1 = ocg_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/ocg/ocg.html';
                    this.controller = ocg_controller_1.default;
                }
                default_1.componentName = 'ocg';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocg.component.js.map