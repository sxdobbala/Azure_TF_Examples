System.register(['../ocg.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_service_1;
    var default_1;
    return {
        setters:[
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($scope, service) {
                    var _this = this;
                    this.$scope = $scope;
                    this.service = service;
                    this.ocgSearch = '';
                    this.filteredOcgList = [{ label: '', value: 0 }];
                    this.$scope.$watch(function () { return _this.ocgSearch; }, function (newValue, oldValue) {
                        if (newValue !== oldValue) {
                            _this.applyFilter();
                        }
                    });
                }
                default_1.prototype.$onChanges = function () {
                    this.setUpBackupOcg();
                    this.loadOcgList();
                };
                default_1.prototype.setUpBackupOcg = function () {
                    if (this.ocg) {
                        this.backupOcg = { value: this.ocg.value, label: this.ocg.label };
                    }
                };
                default_1.prototype.loadOcgList = function () {
                    var _this = this;
                    if (this.service.ocgList.length > 0) {
                        this.applyFilter();
                    }
                    else {
                        this.service.getOcgList().then(function (response) {
                            _this.applyFilter();
                        });
                    }
                };
                default_1.prototype.applyFilter = function () {
                    var searchText = this.ocgSearch.replace(/^\s+|\s+$/g, '');
                    var searchRegex = new RegExp(searchText, 'i');
                    if (this.isFilterByKeyword()) {
                        this.filterByKeywords(searchRegex);
                    }
                    else {
                        this.filterByDirectSearch(searchRegex);
                    }
                    this.setOcgBasedOnBackupValue();
                };
                default_1.prototype.isFilterByKeyword = function () {
                    return this.filteredOcgListByKeywords != null;
                };
                default_1.prototype.filterByKeywords = function (searchRegex) {
                    this.filteredOcgList = [];
                    for (var _i = 0, _a = this.filteredOcgListByKeywords; _i < _a.length; _i++) {
                        var ocgId = _a[_i];
                        for (var _b = 0, _c = this.service.ocgList; _b < _c.length; _b++) {
                            var ocg = _c[_b];
                            if (ocgId === ocg.value && ocg.label.search(searchRegex) !== -1) {
                                this.filteredOcgList.push(ocg);
                            }
                        }
                    }
                };
                default_1.prototype.filterByDirectSearch = function (searchRegex) {
                    this.filteredOcgList = this.service.ocgList.filter(function (element) {
                        return element.label.search(searchRegex) !== -1;
                    });
                };
                default_1.prototype.setOcgBasedOnBackupValue = function () {
                    var _this = this;
                    if (this.filteredOcgList.filter(function (ocg) { return ocg.value === _this.backupOcg.value; }).length > 0) {
                        this.setOcg();
                    }
                    else {
                        this.ocg = { value: this.backupOcg.value, label: this.backupOcg.label };
                    }
                };
                default_1.prototype.setOcg = function () {
                    if (this.ocg) {
                        for (var _i = 0, _a = this.filteredOcgList; _i < _a.length; _i++) {
                            var ocgRecord = _a[_i];
                            if (ocgRecord.value === this.ocg.value) {
                                this.ocg = ocgRecord;
                                return;
                            }
                        }
                    }
                };
                default_1.$inject = ['$scope', ocg_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocgSearch.controller.js.map