System.register(['../ocg.service', './ocgKeywordFilter.constants'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_service_1, ocgKeywordFilterConstants;
    var default_1;
    return {
        setters:[
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (ocgKeywordFilterConstants_1) {
                ocgKeywordFilterConstants = ocgKeywordFilterConstants_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($scope, ocgService, $timeout) {
                    this.$scope = $scope;
                    this.ocgService = ocgService;
                    this.$timeout = $timeout;
                    this.operatorAny = {
                        label: ocgKeywordFilterConstants.any,
                        value: 1
                    };
                    this.operatorAll = {
                        label: ocgKeywordFilterConstants.all,
                        value: 2
                    };
                    this.operatorList = [this.operatorAny, this.operatorAll];
                    this.operatorSelectedValue = this.operatorAll;
                    this.filters = [];
                    this.keywordSortOrder = "label";
                }
                //Parent context overrides these
                default_1.prototype.onCommit = function (context) { };
                default_1.prototype.$onChanges = function () {
                    this.initialize();
                };
                default_1.prototype.initialize = function () {
                    if (this.keywordOcgsList) {
                        this.keywordList = this.keywordOcgsList.map(function (x) { return x.keyword; });
                        if (this.filters.length == 0)
                            this.addANewFilter();
                    }
                };
                default_1.prototype.deleteAFilter = function (filter) {
                    var self = this;
                    if (self.filters.length > 0) {
                        var i = 0;
                        for (; i < self.filters.length; i++) {
                            if ((filter === null && self.filters[i] === null) ||
                                (filter !== null && filter.value === self.filters[i].value))
                                break;
                        }
                        self.filters.splice(i, 1);
                    }
                    //if all filters are removed, then add a default filter.
                    if (self.filters.length === 0) {
                        self.addANewFilter();
                    }
                    this._onCommit();
                };
                default_1.prototype.addANewFilter = function () {
                    this.filters.push(null);
                };
                default_1.prototype.onSelect = function (filter, index) {
                    this.filters[index] = filter;
                    this._onCommit();
                };
                default_1.prototype.reset = function () {
                    this.keywordList = angular.copy(this.ocgService.keywordList.map(function (x) { return x.keyword; }));
                    //remove all filters, don't assign it with []
                    this.filters.splice(0, this.filters.length);
                    //restore filters
                    this.filters = [];
                    this.operatorSelectedValue = this.operatorAll;
                    this.addANewFilter();
                    this._onCommit();
                };
                default_1.prototype.onKeywordOperatorChange = function () {
                    var _this = this;
                    this.$timeout(function () {
                        _this._onCommit();
                    });
                };
                default_1.prototype.allSelectedValues = function () {
                    return this.filters.filter(function (f) { return f && f !== null; }).map(function (f) { return f.value; });
                };
                default_1.prototype._onCommit = function () {
                    this.onCommit({
                        selectedValues: this.allSelectedValues(),
                        selectedKeywordOperator: this.operatorSelectedValue.label
                    });
                };
                default_1.$inject = ['$scope', ocg_service_1.default.serviceName, '$timeout'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocgKeywordFilter.controller.js.map