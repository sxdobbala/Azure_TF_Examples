System.register(['./ocgKeywordFilter.component', 'uiselect'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgKeywordFilter_component_1;
    return {
        setters:[
            function (ocgKeywordFilter_component_1_1) {
                ocgKeywordFilter_component_1 = ocgKeywordFilter_component_1_1;
            },
            function (_1) {}],
        execute: function() {
            angular.module('compass.ocgKeywordFilter', ['compass.uitk', 'ui.select'])
                .component(ocgKeywordFilter_component_1.default.componentName, new ocgKeywordFilter_component_1.default());
        }
    }
});
//# sourceMappingURL=ocgKeywordFilter.init.js.map