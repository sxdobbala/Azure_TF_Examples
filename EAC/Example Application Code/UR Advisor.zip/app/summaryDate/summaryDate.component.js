System.register(["./summaryDate.controller"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summaryDate_controller_1;
    var default_1;
    return {
        setters:[
            function (summaryDate_controller_1_1) {
                summaryDate_controller_1 = summaryDate_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/summaryDate/summaryDate.html';
                    this.controller = summaryDate_controller_1.default;
                    this.bindings = {
                        dateModel: '=',
                    };
                }
                default_1.componentName = 'summaryDate';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=summaryDate.component.js.map