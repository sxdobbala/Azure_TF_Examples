//Registers dependencies with angular's DI container
System.register(['./summaryDate.component', './summaryDate.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summaryDate_component_1, summaryDate_service_1;
    return {
        setters:[
            function (summaryDate_component_1_1) {
                summaryDate_component_1 = summaryDate_component_1_1;
            },
            function (summaryDate_service_1_1) {
                summaryDate_service_1 = summaryDate_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.summaryDate', ['compass.uitk'])
                .component(summaryDate_component_1.default.componentName, new summaryDate_component_1.default())
                .service(summaryDate_service_1.default.serviceName, summaryDate_service_1.default);
        }
    }
});
//# sourceMappingURL=summaryDate.init.js.map