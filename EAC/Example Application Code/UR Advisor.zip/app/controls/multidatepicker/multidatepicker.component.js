System.register(['./multidatepicker.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var multidatepicker_controller_1;
    var ToastComponent;
    return {
        setters:[
            function (multidatepicker_controller_1_1) {
                multidatepicker_controller_1 = multidatepicker_controller_1_1;
            }],
        execute: function() {
            ToastComponent = (function () {
                function ToastComponent() {
                    this.controller = multidatepicker_controller_1.default;
                    this.templateUrl = 'app/controls/multidatepicker/multidatepicker.html';
                    this.bindings = {
                        onCommit: '&',
                        onCancel: '&',
                    };
                }
                ToastComponent.componentName = 'multidatepicker';
                return ToastComponent;
            }());
            exports_1("default", ToastComponent);
        }
    }
});
//# sourceMappingURL=multidatepicker.component.js.map