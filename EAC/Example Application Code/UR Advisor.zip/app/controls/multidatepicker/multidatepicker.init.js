System.register(['dependencies', './multidatepicker.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var multidatepicker_component_1;
    return {
        setters:[
            function (_1) {},
            function (multidatepicker_component_1_1) {
                multidatepicker_component_1 = multidatepicker_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.multidatepicker', ['gm.datepickerMultiSelect', 'compass.uitk'])
                .component(multidatepicker_component_1.default.componentName, new multidatepicker_component_1.default());
        }
    }
});
//# sourceMappingURL=multidatepicker.init.js.map