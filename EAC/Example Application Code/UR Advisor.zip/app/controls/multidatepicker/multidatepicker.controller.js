System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var MultidatepickerController;
    return {
        setters:[],
        execute: function() {
            MultidatepickerController = (function () {
                function MultidatepickerController() {
                    this.allDates = [];
                    var self = this;
                    self.datepickerOptions = {
                        customClass: function (data) {
                            var current = data.date.getTime();
                            var retVal = '';
                            if (self.allDates.some(function (v) { return v === current; }))
                                retVal = 'selected';
                            return retVal;
                        }
                    };
                }
                //Parent context overrides these
                MultidatepickerController.prototype.onCommit = function (context) {
                };
                MultidatepickerController.prototype.onCancel = function () {
                };
                MultidatepickerController.prototype.raiseCommit = function () {
                    this.onCommit({ data: this.allDates });
                    this.reset();
                };
                MultidatepickerController.prototype.raiseCancel = function () {
                    this.onCancel();
                    this.reset();
                };
                MultidatepickerController.prototype.reset = function () {
                    this.currentDate = null;
                    //Empty the array
                    while (this.allDates.length > 0)
                        this.allDates.pop();
                };
                return MultidatepickerController;
            }());
            exports_1("default", MultidatepickerController);
        }
    }
});
//# sourceMappingURL=multidatepicker.controller.js.map