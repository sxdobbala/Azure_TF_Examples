System.register(['header', 'assessment', 'summary', './assessmentContainer.component', './assessmentContainer.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentContainer_component_1, assessmentContainer_service_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (assessmentContainer_component_1_1) {
                assessmentContainer_component_1 = assessmentContainer_component_1_1;
            },
            function (assessmentContainer_service_1_1) {
                assessmentContainer_service_1 = assessmentContainer_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.assessmentContainer', ['compass.uitk', 'compass.header', 'compass.assessment', 'compass.summary'])
                .component(assessmentContainer_component_1.default.componentName, new assessmentContainer_component_1.default())
                .service(assessmentContainer_service_1.default.serviceName, assessmentContainer_service_1.default);
        }
    }
});
//# sourceMappingURL=assessmentContainer.init.js.map