System.register(['./requiresDaysMessage.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var requiresDaysMessage_component_1;
    return {
        setters:[
            function (requiresDaysMessage_component_1_1) {
                requiresDaysMessage_component_1 = requiresDaysMessage_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.shared.requiresDaysMessage', ['uitk.component.uitkMessage'])
                .component(requiresDaysMessage_component_1.default.componentName, new requiresDaysMessage_component_1.default());
        }
    }
});
//# sourceMappingURL=requiresDaysMessage.init.js.map