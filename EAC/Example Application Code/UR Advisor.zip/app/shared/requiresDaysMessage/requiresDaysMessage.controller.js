System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var requiresDaysMessageController;
    return {
        setters:[],
        execute: function() {
            requiresDaysMessageController = (function () {
                function requiresDaysMessageController($filter, $sanitize) {
                    this.$filter = $filter;
                    this.$sanitize = $sanitize;
                    this.model = {
                        id: 'errMsg',
                        messageType: 'error',
                        closeButton: false,
                        position: 'inline',
                        visible: true,
                        content: ''
                    };
                    //Html content must be sanitized
                    this.model.content = '<span>' + $sanitize($filter('translate')('requires_ocg_and_days')) + '</span>';
                    this.model.id = this.model.id + (requiresDaysMessageController.uniqueNumber++);
                }
                requiresDaysMessageController.prototype.$onInit = function () {
                    //Default message
                    this.translationId = this.translationId || 'requires_ocg_and_days';
                    //Html content must be sanitized
                    this.model.content = '<span>' + this.$sanitize(this.$filter('translate')(this.translationId)) + '</span>';
                    this.model.id = this.model.id + (requiresDaysMessageController.uniqueNumber++);
                };
                //Auto-incrementing number used to make Id for each instance unique
                requiresDaysMessageController.uniqueNumber = 0;
                requiresDaysMessageController.$inject = ['$filter', '$sanitize'];
                return requiresDaysMessageController;
            }());
            exports_1("default", requiresDaysMessageController);
        }
    }
});
//# sourceMappingURL=requiresDaysMessage.controller.js.map