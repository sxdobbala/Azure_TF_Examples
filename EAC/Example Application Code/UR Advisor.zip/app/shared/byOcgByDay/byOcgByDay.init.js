System.register(['./byOcgByDay.component', './componentProxy.directive'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var byOcgByDay_component_1, componentProxy_directive_1;
    return {
        setters:[
            function (byOcgByDay_component_1_1) {
                byOcgByDay_component_1 = byOcgByDay_component_1_1;
            },
            function (componentProxy_directive_1_1) {
                componentProxy_directive_1 = componentProxy_directive_1_1;
            }],
        execute: function() {
            angular
                .module('compass.byOcgByDay', [])
                .component(byOcgByDay_component_1.default.componentName, new byOcgByDay_component_1.default())
                .directive(componentProxy_directive_1.default.directiveName, function () { return new componentProxy_directive_1.default(); });
        }
    }
});
//# sourceMappingURL=byOcgByDay.init.js.map