System.register(['./byOcgByDay.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var byOcgByDay_controller_1;
    var default_1;
    return {
        setters:[
            function (byOcgByDay_controller_1_1) {
                byOcgByDay_controller_1 = byOcgByDay_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/shared/byOcgByDay/byOcgByDay.html';
                    this.controller = byOcgByDay_controller_1.default;
                    this.bindings = {
                        model: '<',
                        componentName: '<'
                    };
                }
                default_1.componentName = 'byOcgByDay';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=byOcgByDay.component.js.map