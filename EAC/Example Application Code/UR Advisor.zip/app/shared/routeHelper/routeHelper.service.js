System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($location) {
                    this.$location = $location;
                    this.$inject = ['$location'];
                }
                //TODO: Write a more flexible implementation
                default_1.prototype.getAssessmentId = function () {
                    //Fishing the assessment Id out of the url to work around the Route Parameters being unavailable for child/auxilary routes
                    var urlParts = this.$location.url().split('/');
                    var indexOfAssessmentId = urlParts.indexOf('assessment') + 1;
                    if (indexOfAssessmentId != 0 && urlParts.length > indexOfAssessmentId) {
                        return Number(urlParts[indexOfAssessmentId]);
                    }
                    return null;
                };
                default_1.serviceName = "RouteHelper";
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=routeHelper.service.js.map