System.register(['./helper.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var helper_service_1;
    return {
        setters:[
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.shared.helper', [])
                .service(helper_service_1.default.serviceName, helper_service_1.default);
        }
    }
});
//# sourceMappingURL=helper.init.js.map