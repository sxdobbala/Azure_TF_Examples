System.register(['../../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(appConfig, $http, ajaxErrorService) {
                    this.appConfig = appConfig;
                    this.$http = $http;
                    this.ajaxErrorService = ajaxErrorService;
                }
                default_1.prototype.getConfigSetting = function (configKey) {
                    var self = this;
                    var data = { "ConfigKey": configKey };
                    return self.$http.get(this.appConfig.urls.getConfigSetting, { params: data }).then(function (response) {
                        return response;
                    }, function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.serviceName = "Helper";
                default_1.$inject = ['appConfig', '$http', ajaxErrorService_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=helper.service.js.map