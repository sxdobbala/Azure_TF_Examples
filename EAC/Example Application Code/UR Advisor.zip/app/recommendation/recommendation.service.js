System.register(['../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($q, $http, appConfig, ajaxErrorService) {
                    this.$q = $q;
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                    this.isDirty = false;
                }
                default_1.prototype.isPageDirty = function () {
                    return this.isDirty;
                };
                default_1.prototype.setDirtyFlag = function (flag) {
                    return this.isDirty = flag;
                };
                default_1.prototype.getData = function (assessmentId) {
                    var _this = this;
                    var self = this;
                    return this.$http.get(this.appConfig.urls.getRecommendations, {
                        params: {
                            AssessmentId: assessmentId
                        }
                    }).then(function (response) {
                        var record = response.data || {};
                        record.data = (record.data || []).map(function (day) {
                            //Convert dates from strings to Date objects
                            day.serviceDate = new Date(day.serviceDate);
                            //Provide a default status list for UITK (avoids errors)
                            day.patientStatusList = [{ value: '', label: '' }];
                            return day;
                        });
                        return record;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getPatientStatus = function (isNota) {
                    var _this = this;
                    return this.$http.get(this.appConfig.urls.getPatientStatus, {
                        params: {
                            IsNota: isNota
                        }
                    }).then(function (response) {
                        var _data = response.data;
                        var _default = {};
                        _default.value = 0;
                        _default.label = "Select";
                        _data.unshift(_default);
                        return _data;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.saveRecommendations = function (recommendations) {
                    var _this = this;
                    return this.$http.post(this.appConfig.urls.updateRecommendations, recommendations).then(function (response) {
                        return response.data;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.serviceName = "recommendationService";
                default_1.$inject = ['$q', '$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=recommendation.service.js.map