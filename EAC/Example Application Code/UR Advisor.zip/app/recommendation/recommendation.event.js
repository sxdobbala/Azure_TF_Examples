System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var recommendationOnPageError, recommendationOnPageIncomplete, recommendationOnPageComplete, recommendationOnPageCheckCompleteness, recommendationOnNavigationSave, recommendationOnNavigationDiscard, recommendationOnPageResetRecommendationCompleteness;
    return {
        setters:[],
        execute: function() {
            exports_1("recommendationOnPageError", recommendationOnPageError = 'recommendation.onPage.Error');
            exports_1("recommendationOnPageIncomplete", recommendationOnPageIncomplete = 'recommendation.onPage.Incomplete');
            exports_1("recommendationOnPageComplete", recommendationOnPageComplete = 'recommendation.onPage.Complete');
            exports_1("recommendationOnPageCheckCompleteness", recommendationOnPageCheckCompleteness = 'recommendation.onPage.Check.Completeness');
            exports_1("recommendationOnNavigationSave", recommendationOnNavigationSave = 'recommendation.onNavigation.Save');
            exports_1("recommendationOnNavigationDiscard", recommendationOnNavigationDiscard = 'recommendation.onNavigation.Discard');
            exports_1("recommendationOnPageResetRecommendationCompleteness", recommendationOnPageResetRecommendationCompleteness = 'recommendation.onPage.Reset.Recommendation.Completeness');
        }
    }
});
//# sourceMappingURL=recommendation.event.js.map