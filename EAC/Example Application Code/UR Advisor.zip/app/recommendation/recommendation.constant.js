System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AdministrativeNota;
    return {
        setters:[],
        execute: function() {
            exports_1("AdministrativeNota", AdministrativeNota = 'Administrative NOTA');
        }
    }
});
//# sourceMappingURL=recommendation.constant.js.map