System.register(['./timeline.constant', "../events/event.service", '../assessmentCompleteness/assessmentcompleteness.service', "../ocg/ocg.event", "../riskfactor/riskfactor.event", "../recommendation/recommendation.event", "../completeAssessment/completeAssessment.event"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var TimelineConstant, event_service_1, assessmentcompleteness_service_1, ocgEvents, riskfactorEvents, recommendationEvents, completeAssessmentEvents;
    var TimelineService;
    return {
        setters:[
            function (TimelineConstant_1) {
                TimelineConstant = TimelineConstant_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (assessmentcompleteness_service_1_1) {
                assessmentcompleteness_service_1 = assessmentcompleteness_service_1_1;
            },
            function (ocgEvents_1) {
                ocgEvents = ocgEvents_1;
            },
            function (riskfactorEvents_1) {
                riskfactorEvents = riskfactorEvents_1;
            },
            function (recommendationEvents_1) {
                recommendationEvents = recommendationEvents_1;
            },
            function (completeAssessmentEvents_1) {
                completeAssessmentEvents = completeAssessmentEvents_1;
            }],
        execute: function() {
            TimelineService = (function () {
                function TimelineService($q, events, router, assessmentCompletenessService) {
                    this.$q = $q;
                    this.events = events;
                    this.router = router;
                    this.assessmentCompletenessService = assessmentCompletenessService;
                    this.status = {
                        Empty: 'empty',
                        Current: 'current',
                        Filled: 'filled',
                        Error: 'error',
                        Disabled: 'disabled'
                    };
                    this.urls = {
                        Ocg: 'ocg',
                        RiskFactor: 'risk',
                        Recommendation: 'recommendation',
                        CompleteAssessment: 'complete'
                    };
                    this.pages = [
                        { cssClass: 'tk-col-1-4', name: 'Ocg', displayText: 'Optum Clinical Group', status: 'empty', url: this.urls.Ocg },
                        { cssClass: 'tk-col-1-4', name: 'RiskFactor', displayText: 'Risk Factors', status: 'empty', url: this.urls.RiskFactor },
                        { cssClass: 'tk-col-1-4', name: 'Recommendation', displayText: 'Summary Recommendation', status: 'empty', url: this.urls.Recommendation },
                        { cssClass: 'tk-col-1-4', name: 'CompleteAssessment', displayText: 'Complete Assessment', status: 'empty', url: this.urls.CompleteAssessment }
                    ];
                    this.ocgPage = this.pages[TimelineConstant.ocgPageIndex];
                    this.riskFactorPage = this.pages[TimelineConstant.riskFactorPageIndex];
                    this.recommendationPage = this.pages[TimelineConstant.recommendationPageIndex];
                    this.completeAssessmentPage = this.pages[TimelineConstant.completeAssessmentPageIndex];
                    this.registerRecommendationEvents();
                    this.registerCompleteAssessmentEvents();
                }
                TimelineService.prototype.registerRecommendationEvents = function () {
                    var _this = this;
                    this.events.subscribe(recommendationEvents.recommendationOnPageComplete, function () {
                        _this.recommendationPage.status = _this.status.Filled;
                    });
                    this.events.subscribe(recommendationEvents.recommendationOnPageIncomplete, function () {
                        _this.recommendationPage.status = _this.status.Empty;
                    });
                    this.events.subscribe(recommendationEvents.recommendationOnPageError, function () {
                        _this.recommendationPage.status = _this.status.Error;
                    });
                };
                TimelineService.prototype.registerCompleteAssessmentEvents = function () {
                    var _this = this;
                    this.events.subscribe(completeAssessmentEvents.completeAssessmentOnPageComplete, function () {
                        _this.completeAssessmentPage.status = _this.status.Filled;
                    });
                    this.events.subscribe(completeAssessmentEvents.completeAssessmentOnPageIncomplete, function () {
                        _this.completeAssessmentPage.status = _this.status.Empty;
                    });
                    this.events.subscribe(completeAssessmentEvents.completeAssessmentOnPageError, function () {
                        _this.completeAssessmentPage.status = _this.status.Error;
                    });
                };
                TimelineService.prototype.navigate = function (url, id) {
                    if (url) {
                        this.router.navigateByUrl('assessment/' + id + '/' + url);
                    }
                    else
                        return null;
                };
                TimelineService.prototype.checkForAssessmentCompleteness = function () {
                    var self = this;
                    return self.assessmentCompletenessService.checkForAssessmentCompleteness(self.assessmentId).then(function (isAssessmentComplete) {
                        if (isAssessmentComplete) {
                            self.events.raise(completeAssessmentEvents.completeAssessmentOnPageComplete);
                        }
                        else {
                            self.events.raise(completeAssessmentEvents.completeAssessmentOnPageIncomplete);
                        }
                        return isAssessmentComplete;
                    });
                };
                TimelineService.prototype.checkForOcgCompleteness = function () {
                    var _this = this;
                    return this.assessmentCompletenessService.checkForOcgDataCompleteness(this.assessmentId).then(function (isOcgComplete) {
                        var eventName = '';
                        eventName = isOcgComplete ? ocgEvents.ocgOnPageComplete : ocgEvents.ocgOnPageIncomplete;
                        _this.events.raise(eventName).then(function (response) {
                            if (response && response[0]) {
                                _this.savedOcgCompletenessStatus = response[0];
                            }
                        });
                        return isOcgComplete;
                    });
                };
                TimelineService.prototype.checkForRiskFactorsCompleteness = function () {
                    var _this = this;
                    return this.assessmentCompletenessService.checkForRiskFactorsDataCompleteness(this.assessmentId).then(function (isRiskFactorsComplete) {
                        var eventName = '';
                        eventName = isRiskFactorsComplete
                            ? riskfactorEvents.riskFactorOnPageComplete
                            : riskfactorEvents.riskFactorOnPageIncomplete;
                        _this.events.raise(eventName).then(function (response) {
                            if (response && response[0]) {
                                _this.savedRiskFactorCompletenessStatus = response[0];
                            }
                        });
                        return isRiskFactorsComplete;
                    });
                };
                TimelineService.prototype.checkForRecommendationCompleteness = function () {
                    var _this = this;
                    var self = this;
                    return self.assessmentCompletenessService.checkForRecommendationDataCompleteness(this.assessmentId).then(function (isRecommendationComplete) {
                        var eventName = '';
                        eventName = isRecommendationComplete ? recommendationEvents.recommendationOnPageComplete : recommendationEvents.recommendationOnPageIncomplete;
                        _this.events.raise(eventName).then(function (response) {
                            if (response && response[1]) {
                                _this.savedRecommendationCompletenessStatus = response[1];
                            }
                        });
                        return isRecommendationComplete;
                    });
                };
                TimelineService.prototype.isPageDirty = function () {
                    return this.isDirty;
                };
                TimelineService.prototype.setDirtyFlag = function (flag) {
                    return this.isDirty = flag;
                };
                TimelineService.serviceName = 'timelineservice';
                TimelineService.$inject = ['$q', event_service_1.default.serviceName, '$rootRouter', assessmentcompleteness_service_1.default.serviceName];
                return TimelineService;
            }());
            exports_1("TimelineService", TimelineService);
        }
    }
});
//# sourceMappingURL=timeline.service.js.map