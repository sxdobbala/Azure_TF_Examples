System.register(['./timeline.component', './timeline.service', 'helper', 'assessmentCompleteness'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var timeline_component_1, timeline_service_1;
    return {
        setters:[
            function (timeline_component_1_1) {
                timeline_component_1 = timeline_component_1_1;
            },
            function (timeline_service_1_1) {
                timeline_service_1 = timeline_service_1_1;
            },
            function (_1) {},
            function (_2) {}],
        execute: function() {
            angular
                .module('compass.timeline', ['compass.assessmentcompleteness', 'compass.shared.helper'])
                .service(timeline_service_1.TimelineService.serviceName, timeline_service_1.TimelineService)
                .component(timeline_component_1.default.componentName, new timeline_component_1.default());
        }
    }
});
//# sourceMappingURL=timeline.init.js.map