System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var isPageDirty, checkIfAssessmentIncompleteInCaseUserEnteredManually, isNlpAvailable;
    return {
        setters:[],
        execute: function() {
            exports_1("isPageDirty", isPageDirty = 'IS_PAGE_DIRTY');
            exports_1("checkIfAssessmentIncompleteInCaseUserEnteredManually", checkIfAssessmentIncompleteInCaseUserEnteredManually = 'timeline.check.assessment.incomplete');
            exports_1("isNlpAvailable", isNlpAvailable = 'IS_NLP_AVAILABLE');
        }
    }
});
//# sourceMappingURL=timeline.event.js.map