System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgPageIndex, riskFactorPageIndex, recommendationPageIndex, completeAssessmentPageIndex;
    return {
        setters:[],
        execute: function() {
            exports_1("ocgPageIndex", ocgPageIndex = 0);
            exports_1("riskFactorPageIndex", riskFactorPageIndex = 1);
            exports_1("recommendationPageIndex", recommendationPageIndex = 2);
            exports_1("completeAssessmentPageIndex", completeAssessmentPageIndex = 3);
        }
    }
});
//# sourceMappingURL=timeline.constant.js.map