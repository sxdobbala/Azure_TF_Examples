System.register(['./assessmentdateFilter.component', './assessmentdateFilter.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentdateFilter_component_1, assessmentdateFilter_service_1;
    return {
        setters:[
            function (assessmentdateFilter_component_1_1) {
                assessmentdateFilter_component_1 = assessmentdateFilter_component_1_1;
            },
            function (assessmentdateFilter_service_1_1) {
                assessmentdateFilter_service_1 = assessmentdateFilter_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.assessmentdateFilter', ['compass.uitk'])
                .service(assessmentdateFilter_service_1.default.serviceName, assessmentdateFilter_service_1.default)
                .component(assessmentdateFilter_component_1.default.componentName, new assessmentdateFilter_component_1.default());
        }
    }
});
//# sourceMappingURL=assessmentdateFilter.init.js.map