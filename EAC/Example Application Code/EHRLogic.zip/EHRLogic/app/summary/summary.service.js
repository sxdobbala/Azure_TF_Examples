System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.summaryData = [];
                }
                default_1.prototype.getSummaryData = function (assessmentId) {
                    var self = this;
                    var data = { "AssessmentId": assessmentId };
                    return this.$http.get(this.appConfig.urls.summaryList, { params: data }).then(function (response) {
                        for (var _i = 0, _a = response.data; _i < _a.length; _i++) {
                            var currentSummary = _a[_i];
                            currentSummary.dateDetail.isOpen = false;
                        }
                        self.summaryData = response.data;
                        return true;
                    }, function (error) {
                        return false;
                    });
                };
                default_1.serviceName = 'summaryService';
                default_1.$inject = ['$http', 'appConfig'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=summary.service.js.map