System.register(['./summary.service', '../events/common.events', '../events/event.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summary_service_1, commonEvents, event_service_1;
    var default_1;
    return {
        setters:[
            function (summary_service_1_1) {
                summary_service_1 = summary_service_1_1;
            },
            function (commonEvents_1) {
                commonEvents = commonEvents_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(events, service) {
                    this.events = events;
                    this.service = service;
                    this.dateList = [];
                    this.dateListCopy = [];
                    this.assessmentPanelList = [];
                    this.assessmentPanelListCopy = [];
                    this.assessmentNumberList = [];
                    this.registerEvents();
                }
                default_1.prototype.$onChanges = function () {
                    if (this.assessmentId) {
                        this.getSummaryData();
                    }
                };
                default_1.prototype.getSummaryData = function () {
                    var _this = this;
                    this.service.getSummaryData(this.assessmentId).then(function (response) {
                        if (response) {
                            _this.dateList = _this.service.summaryData;
                        }
                    });
                };
                default_1.prototype.getData = function () {
                    var _this = this;
                    var self = this;
                    this.service.getSummaryData(self.assessmentId).then(function (response) {
                        if (response) {
                            self.assessmentPanelList = _this.service.summaryData;
                            angular.copy(self.assessmentPanelList, self.assessmentPanelListCopy);
                        }
                    });
                };
                default_1.prototype.getEventRaisedData = function () {
                    var _this = this;
                    var self = this;
                    angular.copy(self.dateList, self.dateListCopy);
                    this.service.getSummaryData(self.assessmentId).then(function (response) {
                        if (response) {
                            if (self.assessmentPanelList.length > 0) {
                                self.assessmentPanelList.splice(0, self.assessmentPanelList.length);
                            }
                            _this.dateList = _this.service.summaryData;
                            for (var _i = 0, _a = _this.dateList; _i < _a.length; _i++) {
                                var newDateItem = _a[_i];
                                for (var _b = 0, _c = _this.dateListCopy; _b < _c.length; _b++) {
                                    var oldDateItem = _c[_b];
                                    if (newDateItem.dateDetail.dayOfServiceId === oldDateItem.dateDetail.dayOfServiceId) {
                                        newDateItem.dateDetail.isOpen = oldDateItem.dateDetail.isOpen;
                                    }
                                }
                            }
                        }
                    });
                };
                default_1.prototype.registerEvents = function () {
                    var self = this;
                    this.events.subscribe(commonEvents.summarySave, function () {
                        self.getEventRaisedData();
                    });
                };
                default_1.$inject = [event_service_1.default.serviceName, summary_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=summary.controller.js.map