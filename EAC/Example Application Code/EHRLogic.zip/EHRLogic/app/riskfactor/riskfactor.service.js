System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.formName = "riskFactorForm";
                    this.isDirty = false;
                }
                default_1.prototype.isPageDirty = function () {
                    return this.isDirty;
                };
                default_1.prototype.setDirtyFlag = function (flag) {
                    return this.isDirty = flag;
                };
                default_1.serviceName = 'riskfactorService';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=riskfactor.service.js.map