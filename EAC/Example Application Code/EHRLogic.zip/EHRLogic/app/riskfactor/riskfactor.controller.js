System.register(['../events/event.service', './riskfactor.event', './riskfactor.service', '../shared/routeHelper/routeHelper.service', '../ocg/ocg.service', '../serviceDayRiskFactors/serviceDayRiskFactors.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var event_service_1, riskFactorEvents, riskfactor_service_1, routeHelper_service_1, ocg_service_1, serviceDayRiskFactors_service_1;
    var default_1;
    return {
        setters:[
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (riskFactorEvents_1) {
                riskFactorEvents = riskFactorEvents_1;
            },
            function (riskfactor_service_1_1) {
                riskfactor_service_1 = riskfactor_service_1_1;
            },
            function (routeHelper_service_1_1) {
                routeHelper_service_1 = routeHelper_service_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (serviceDayRiskFactors_service_1_1) {
                serviceDayRiskFactors_service_1 = serviceDayRiskFactors_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(eventService, service, routeHelper, ocgService, $filter, $scope, serviceDayRiskFactorsService) {
                    var _this = this;
                    this.eventService = eventService;
                    this.service = service;
                    this.routeHelper = routeHelper;
                    this.ocgService = ocgService;
                    this.$filter = $filter;
                    this.$scope = $scope;
                    this.serviceDayRiskFactorsService = serviceDayRiskFactorsService;
                    this.clinicalGroup = '';
                    this.hasNoServiceDays = false;
                    this.serviceDayTabs = {
                        id: 'serviceDayTabsId',
                        selectedIndex: 0,
                        tabs: [],
                    };
                    this.showDateTabChangeConfirmationDialog = false;
                    this.templateUrl = 'app/riskfactor/serviceDayTab.html';
                    this.$scope.$watch(function (s) { return _this.serviceDayTabs.selectedIndex; }, function (newValue, oldValue) { return _this.onDateTabChange(newValue, oldValue); });
                }
                // Route Events
                default_1.prototype.$routerOnActivate = function () {
                    this.assessmentId = this.routeHelper.getAssessmentId();
                    if (this.assessmentId && this.assessmentId != null) {
                        this.loadServiceDays();
                    }
                };
                ;
                default_1.prototype.loadServiceDays = function () {
                    var _this = this;
                    this.ocgService.getOcgServiceDays(this.assessmentId).then(function (response) {
                        if (response && _this.ocgService.ocgServiceDays.length > 0) {
                            _this.clinicalGroup = _this.ocgService.ocgServiceDays[0].clinicalGroup.label;
                            var serviceDateTitle = '';
                            for (var _i = 0, _a = _this.ocgService.ocgServiceDays; _i < _a.length; _i++) {
                                var serviceDay = _a[_i];
                                serviceDateTitle = _this.$filter('date')(new Date(serviceDay.serviceDate), _this.$filter('translate')('date_format'));
                                _this.serviceDayTabs.tabs.push({
                                    title: serviceDateTitle,
                                    templateurl: _this.templateUrl,
                                    disabled: false,
                                    data: { dayOfServiceId: serviceDay.dayOfServiceId, protocol: serviceDay.protocol }
                                });
                            }
                        }
                        else {
                            _this.hasNoServiceDays = true;
                        }
                    });
                };
                default_1.prototype.onDateTabChange = function (newSelectedIndex, oldSelectedIndex) {
                    if (newSelectedIndex != oldSelectedIndex) {
                        this.eventService.raise(riskFactorEvents.riskFactorPageIsdirty);
                        if (this.service.isPageDirty()) {
                            this.serviceDayRiskFactorsService.riskFactorListToSave = [];
                            angular.copy(this.serviceDayRiskFactorsService.riskFactorList, this.serviceDayRiskFactorsService.riskFactorListToSave);
                            this.showDateTabChangeConfirmationDialog = true;
                        }
                    }
                };
                default_1.prototype.onDateTabChangeConfirmation = function (save) {
                    this.showDateTabChangeConfirmationDialog = false;
                    if (save) {
                        this.eventService.raise(riskFactorEvents.riskFactorOnDateTabChangeSave);
                    }
                    else {
                        this.eventService.raise(riskFactorEvents.riskFactorOnNavigationDiscard);
                    }
                };
                default_1.$inject = [event_service_1.default.serviceName, riskfactor_service_1.default.serviceName, routeHelper_service_1.default.serviceName, ocg_service_1.default.serviceName, '$filter', '$scope', serviceDayRiskFactors_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=riskfactor.controller.js.map