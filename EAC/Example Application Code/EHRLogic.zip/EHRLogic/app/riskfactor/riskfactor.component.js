System.register(['./riskfactor.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var riskfactor_controller_1;
    var default_1;
    return {
        setters:[
            function (riskfactor_controller_1_1) {
                riskfactor_controller_1 = riskfactor_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/riskfactor/riskfactor.html';
                    this.controller = riskfactor_controller_1.default;
                }
                default_1.componentName = 'riskfactor';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=riskfactor.component.js.map