System.register(['./riskfactor.component', './riskfactor.service', 'serviceDayRiskFactors', 'requiresDaysMessage'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var riskfactor_component_1, riskfactor_service_1;
    return {
        setters:[
            function (riskfactor_component_1_1) {
                riskfactor_component_1 = riskfactor_component_1_1;
            },
            function (riskfactor_service_1_1) {
                riskfactor_service_1 = riskfactor_service_1_1;
            },
            function (_1) {},
            function (_2) {}],
        execute: function() {
            angular
                .module('compass.riskfactor', ['compass.serviceDayRiskFactors', 'compass.shared.requiresDaysMessage'])
                .service(riskfactor_service_1.default.serviceName, riskfactor_service_1.default)
                .component(riskfactor_component_1.default.componentName, new riskfactor_component_1.default());
        }
    }
});
//# sourceMappingURL=riskfactor.init.js.map