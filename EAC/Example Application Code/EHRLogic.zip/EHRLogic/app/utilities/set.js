System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Set;
    return {
        setters:[],
        execute: function() {
            Set = (function () {
                function Set() {
                }
                /**
                * Return union of all arrays
                * @param arrays
                */
                //sorting parameter type changed
                Set.union = function (arrays) {
                    //var hash: { [key: number]: compass.OcgContainer.IOcgDisplayOrderModel } = {};
                    var result = [];
                    var duplicateFound = false;
                    for (var _i = 0, arrays_1 = arrays; _i < arrays_1.length; _i++) {
                        var arr = arrays_1[_i];
                        for (var _a = 0, arr_1 = arr; _a < arr_1.length; _a++) {
                            var x = arr_1[_a];
                            duplicateFound = false;
                            for (var _b = 0, result_1 = result; _b < result_1.length; _b++) {
                                var item = result_1[_b];
                                if (x.ocgId == item.ocgId) {
                                    duplicateFound = true;
                                    break;
                                }
                            }
                            if (!duplicateFound)
                                result.push(x);
                        }
                    }
                    //return Object.keys(hash).map((e) => Number(e));
                    return result;
                };
                //sorting parameters type changed
                Set.intersect2Arrays = function (arr1, arr2) {
                    var hash = {};
                    var result = [];
                    if (!arr1 || !arr2)
                        return result;
                    for (var _i = 0, arr1_1 = arr1; _i < arr1_1.length; _i++) {
                        var x = arr1_1[_i];
                        hash[x] = true;
                    }
                    for (var _a = 0, arr2_1 = arr2; _a < arr2_1.length; _a++) {
                        var x = arr2_1[_a];
                        if (x in hash) {
                            result.push(x);
                        }
                    }
                    return result;
                };
                Set.getIntersectionofArrays = function (arr1, arr2) {
                    var hash = {};
                    var tempResult = [];
                    var result = [];
                    if (!arr1 || !arr2)
                        return result;
                    for (var _i = 0, arr1_2 = arr1; _i < arr1_2.length; _i++) {
                        var x = arr1_2[_i];
                        tempResult.push(x);
                    }
                    for (var _a = 0, arr2_2 = arr2; _a < arr2_2.length; _a++) {
                        var x = arr2_2[_a];
                        for (var _b = 0, tempResult_1 = tempResult; _b < tempResult_1.length; _b++) {
                            var item = tempResult_1[_b];
                            if (item.ocgId === x.ocgId) {
                                result.push(x);
                                break;
                            }
                        }
                    }
                    return result;
                };
                /**
                 * Return intersection of all arrays
                 * @param arrays
                 */
                //sorting parameter type changed
                Set.intersect = function (arrays) {
                    if (!arrays)
                        return [];
                    if (arrays.length === 1) {
                        return arrays[0];
                    }
                    var result = this.intersect2Arrays(arrays[0], arrays[1]);
                    for (var i = 2; i < arrays.length; i++) {
                        result = this.intersect2Arrays(result, arrays[i]);
                    }
                    return result;
                };
                Set.getIntersection = function (arrays) {
                    if (!arrays)
                        return [];
                    if (arrays.length === 1) {
                        return arrays[0];
                    }
                    var result = this.getIntersectionofArrays(arrays[0], arrays[1]);
                    for (var i = 2; i < arrays.length; i++) {
                        result = this.getIntersectionofArrays(result, arrays[i]);
                    }
                    return result;
                };
                /**
                 * Set(arr1) - Set(arr2)
                 * @param arr1
                 * @param arr2
                 */
                Set.substract = function (arr1, arr2) {
                    if (!arr1)
                        return [];
                    if (!arr2)
                        return arr1;
                    var intersectSet = this.intersect2Arrays(arr1, arr2); // Find out all the common items.
                    var res = [];
                    for (var _i = 0, arr1_3 = arr1; _i < arr1_3.length; _i++) {
                        var element = arr1_3[_i];
                        if (intersectSet.indexOf(element) === -1) {
                            res.push(element);
                        }
                    }
                    return res;
                };
                return Set;
            }());
            exports_1("default", Set);
        }
    }
});
//# sourceMappingURL=set.js.map