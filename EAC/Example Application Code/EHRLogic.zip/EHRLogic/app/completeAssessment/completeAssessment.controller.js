System.register(['../events/event.service', '../shared/routeHelper/routeHelper.service', './completeAssessment.event', './completeAssessment.service', '../events/common.events', "../completeAssessment/completeAssessment.event", "../timeline/timeline.event"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var event_service_1, routeHelper_service_1, completeAssessment_event_1, completeAssessment_service_1, common_events_1, completeAssessmentEvents, timelineEvents, commonEvents;
    var default_1;
    return {
        setters:[
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (routeHelper_service_1_1) {
                routeHelper_service_1 = routeHelper_service_1_1;
            },
            function (completeAssessment_event_1_1) {
                completeAssessment_event_1 = completeAssessment_event_1_1;
            },
            function (completeAssessment_service_1_1) {
                completeAssessment_service_1 = completeAssessment_service_1_1;
            },
            function (common_events_1_1) {
                common_events_1 = common_events_1_1;
                commonEvents = common_events_1_1;
            },
            function (completeAssessmentEvents_1) {
                completeAssessmentEvents = completeAssessmentEvents_1;
            },
            function (timelineEvents_1) {
                timelineEvents = timelineEvents_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(event, routeHelper, $filter, completeAssessmentService) {
                    this.event = event;
                    this.routeHelper = routeHelper;
                    this.$filter = $filter;
                    this.completeAssessmentService = completeAssessmentService;
                    this.setTranslation();
                }
                default_1.prototype.showError = function () {
                    this.event.raise(completeAssessment_event_1.completeAssessmentOnPageError);
                };
                default_1.prototype.hideError = function () {
                    this.event.raise(completeAssessment_event_1.completeAssessmentOnPageComplete);
                };
                // Route Events
                default_1.prototype.$routerOnActivate = function () {
                    this.assessmentId = this.routeHelper.getAssessmentId();
                    this.previewLetter();
                    this.event.raise(timelineEvents.checkIfAssessmentIncompleteInCaseUserEnteredManually);
                };
                ;
                default_1.prototype.$onChanges = function () {
                    this.subscribeEvents();
                };
                default_1.prototype.$onDestroy = function () {
                    this.unsubscribeEvents();
                };
                default_1.prototype.previewLetter = function () {
                    var _this = this;
                    if (this.assessmentId && this.assessmentId != null) {
                        this.completeAssessmentService.getLetterPreview(this.assessmentId).then(function () {
                            _this.data = _this.completeAssessmentService.previewData;
                        });
                    }
                };
                default_1.prototype.generateLetter = function () {
                    var _this = this;
                    this.completeAssessmentService.generateLetter(this.assessmentId).then(function (response) {
                        if (response) {
                            _this.event.raise(common_events_1.RefreshLetterList);
                            _this.event.raise(completeAssessmentEvents.completeAssessmentOnPageComplete);
                            _this.event.raise(commonEvents.summarySave);
                        }
                        else {
                        }
                    });
                    ;
                };
                default_1.prototype.setTranslation = function () {
                    this.letterReviewedText = this.$filter('translate')('assessmentcompleteness_confirm_text');
                };
                default_1.prototype.subscribeEvents = function () {
                    var self = this;
                    this.event.subscribe(completeAssessment_event_1.refreshPreview, function () {
                        self.data = '';
                        self.previewLetter();
                    }, true);
                };
                default_1.prototype.unsubscribeEvents = function () {
                    this.event.empty(completeAssessment_event_1.refreshPreview);
                };
                default_1.$inject = [event_service_1.default.serviceName, routeHelper_service_1.default.serviceName, '$filter', completeAssessment_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=completeAssessment.controller.js.map