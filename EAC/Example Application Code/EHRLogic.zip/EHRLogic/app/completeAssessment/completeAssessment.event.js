System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var completeAssessmentOnPageError, completeAssessmentOnPageIncomplete, completeAssessmentOnPageComplete, refreshPreview;
    return {
        setters:[],
        execute: function() {
            exports_1("completeAssessmentOnPageError", completeAssessmentOnPageError = 'completeAssessment.onPage.Error');
            exports_1("completeAssessmentOnPageIncomplete", completeAssessmentOnPageIncomplete = 'completeAssessment.onPage.Incomplete');
            exports_1("completeAssessmentOnPageComplete", completeAssessmentOnPageComplete = 'completeAssessment.onPage.Complete');
            exports_1("refreshPreview", refreshPreview = 'completeAssessment.onPage.RefreshPreview');
        }
    }
});
//# sourceMappingURL=completeAssessment.event.js.map