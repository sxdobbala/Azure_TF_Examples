System.register(['./completeAssessment.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var completeAssessment_controller_1;
    var default_1;
    return {
        setters:[
            function (completeAssessment_controller_1_1) {
                completeAssessment_controller_1 = completeAssessment_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/completeAssessment/completeAssessment.html';
                    this.controller = completeAssessment_controller_1.default;
                }
                default_1.componentName = 'completeAssessment';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=completeAssessment.component.js.map