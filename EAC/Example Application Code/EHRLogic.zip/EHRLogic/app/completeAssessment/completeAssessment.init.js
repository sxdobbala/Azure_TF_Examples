System.register(['./completeAssessment.component', '../shared/letter/pdfviewer.directive', './completeAssessment.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var completeAssessment_component_1, pdfviewer_directive_1, completeAssessment_service_1;
    return {
        setters:[
            function (completeAssessment_component_1_1) {
                completeAssessment_component_1 = completeAssessment_component_1_1;
            },
            function (pdfviewer_directive_1_1) {
                pdfviewer_directive_1 = pdfviewer_directive_1_1;
            },
            function (completeAssessment_service_1_1) {
                completeAssessment_service_1 = completeAssessment_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.completeAssessment', [])
                .component(completeAssessment_component_1.default.componentName, new completeAssessment_component_1.default())
                .service(completeAssessment_service_1.default.serviceName, completeAssessment_service_1.default)
                .directive(pdfviewer_directive_1.default.directiveName, function () { return new pdfviewer_directive_1.default(); });
        }
    }
});
//# sourceMappingURL=completeAssessment.init.js.map