System.register(['./assessmentcompleteness.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentcompleteness_service_1;
    return {
        setters:[
            function (assessmentcompleteness_service_1_1) {
                assessmentcompleteness_service_1 = assessmentcompleteness_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.assessmentcompleteness', [])
                .service(assessmentcompleteness_service_1.default.serviceName, assessmentcompleteness_service_1.default);
        }
    }
});
//# sourceMappingURL=assessmentcompleteness.init.js.map