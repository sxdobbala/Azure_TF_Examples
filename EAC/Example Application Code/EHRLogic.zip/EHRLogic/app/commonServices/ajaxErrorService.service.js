System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($filter) {
                    this.$filter = $filter;
                    this._noacsess = "No access to application";
                }
                default_1.prototype.ShowCommonAjaxError = function (errorString) {
                    //For Unauthorized Exception
                    if (errorString.length > 0 && errorString.indexOf(this._noacsess) >= 0) {
                        console.error(errorString);
                        return false;
                    }
                    console.error(this.$filter('translate')('ajax_common_error'));
                    return false;
                };
                default_1.serviceName = 'ajaxErrorService.service';
                default_1.$inject = ['$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ajaxErrorService.service.js.map