//Registers dependencies with angular's DI container
System.register(['examplehospital', 'edithospital', './examplehospitalcontainer.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var examplehospitalcontainer_component_1;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (examplehospitalcontainer_component_1_1) {
                examplehospitalcontainer_component_1 = examplehospitalcontainer_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.examplehospitalcontainer', ['compass.uitk',
                'compass.examplehospital',
                'compass.edithospital'
            ])
                .component(examplehospitalcontainer_component_1.default.componentName, new examplehospitalcontainer_component_1.default());
        }
    }
});
//# sourceMappingURL=examplehospitalcontainer.init.js.map