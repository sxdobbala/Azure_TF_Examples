System.register(['../../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                }
                default_1.prototype.GetList = function () {
                    var _this = this;
                    return this.$http.get(this.appConfig.urls.getExampleHospitalAll).then(function (response) {
                        return response.data || false;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                default_1.serviceName = 'HospitalService';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=examplehospital.service.js.map