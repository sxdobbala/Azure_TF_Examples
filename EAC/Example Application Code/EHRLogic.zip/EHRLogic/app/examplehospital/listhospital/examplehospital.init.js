//Registers dependencies with angular's DI container
System.register(['./examplehospital.component', './examplehospital.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var examplehospital_component_1, examplehospital_service_1;
    return {
        setters:[
            function (examplehospital_component_1_1) {
                examplehospital_component_1 = examplehospital_component_1_1;
            },
            function (examplehospital_service_1_1) {
                examplehospital_service_1 = examplehospital_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.examplehospital', ['compass.uitk'])
                .component(examplehospital_component_1.default.componentName, new examplehospital_component_1.default())
                .service(examplehospital_service_1.default.serviceName, examplehospital_service_1.default);
        }
    }
});
//# sourceMappingURL=examplehospital.init.js.map