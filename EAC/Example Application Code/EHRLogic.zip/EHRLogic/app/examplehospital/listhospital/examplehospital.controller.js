System.register(['./examplehospital.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var examplehospital_service_1;
    var default_1;
    return {
        setters:[
            function (examplehospital_service_1_1) {
                examplehospital_service_1 = examplehospital_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(hospitalService, $scope) {
                    this.hospitalService = hospitalService;
                    this.$scope = $scope;
                    this.model = {
                        records: [],
                        columns: [
                            {
                                columnId: 'LegalName',
                                label: 'Legal Name',
                                dataType: 'text',
                                cellTemplate: '<span ng-bind="::record.LegalName"></span>',
                            },
                            {
                                columnId: 'CommonName',
                                label: 'Common Name',
                                dataType: 'text',
                                cellTemplate: '<span ng-bind="::record.CommonName"></span>',
                            },
                            {
                                columnId: 'ModifiedOn',
                                label: 'Modifiied On',
                                dataType: 'date',
                                cellTemplate: '<span ng-bind="::record.ModifiedOn"></span>',
                            },
                            {
                                columnId: 'EncountersCount',
                                label: 'Encounters',
                                cellTemplate: '<span ng-bind="::record.EncountersCount"></span>',
                            }
                        ],
                        subColumns: [
                            {
                                columnId: 'LegalNameEdit',
                                label: 'Legal Name',
                                cellTemplate: '<span ng-bind="::record.LegalName"></span>',
                            },
                            {
                                columnId: 'CommonNameEdit',
                                label: 'Common Name',
                                cellTemplate: '<input></input>',
                            },
                        ],
                        totalRecordsCount: 0,
                    };
                    var self = this;
                    hospitalService.GetList().then(function (result) {
                        angular.copy(result.data, self.model.records);
                        self.model.totalRecordsCount = self.model.records.length;
                    });
                    $scope.$watch(function (s) { return self.refreshList; }, function (newValue, oldValue) {
                        if (newValue) {
                            hospitalService.GetList().then(function (result) {
                                angular.copy(result.data, self.model.records);
                                self.model.totalRecordsCount = self.model.records.length;
                            });
                        }
                    });
                }
                default_1.$inject = [examplehospital_service_1.default.serviceName, '$scope'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=examplehospital.controller.js.map