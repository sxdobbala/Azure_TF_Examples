System.register(['./routeHelper.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var routeHelper_service_1;
    return {
        setters:[
            function (routeHelper_service_1_1) {
                routeHelper_service_1 = routeHelper_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.shared.routeHelper', [])
                .service(routeHelper_service_1.default.serviceName, routeHelper_service_1.default);
        }
    }
});
//# sourceMappingURL=routeHelper.init.js.map