System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            //Simple directive that takes a component name as a string, and an expression to evaluate for the model, and dynamically creates that component
            default_1 = (function () {
                function default_1() {
                    this.link = {
                        post: function (scope, element, attributes, controller, transclude) {
                            //Component name is required
                            if (attributes.$attr['componentName'] && element.attr(attributes.$attr['componentName'])) {
                                //get the component name from the angular expression
                                var componentName = scope.$eval(element.attr(attributes.$attr['componentName']));
                                //get the angular expression that the component will use for its model
                                var modelExpression = element.attr(attributes.$attr['model']);
                                //Define the html for the component
                                var html = '<' + componentName + ' model="' + modelExpression + '"></' + componentName + '>';
                                //Can't use normal constructor injection because the object is instantiated directly in the init file
                                var $compile = element.injector().get('$compile');
                                //Compile the component using the current scope
                                var e = $compile(html)(scope);
                                //Add the component to the page, replacing this directive
                                element.replaceWith(e);
                            }
                            else {
                                console.error('unable to load component');
                                return "";
                            }
                        }
                    };
                }
                default_1.directiveName = 'componentProxy';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=componentProxy.directive.js.map