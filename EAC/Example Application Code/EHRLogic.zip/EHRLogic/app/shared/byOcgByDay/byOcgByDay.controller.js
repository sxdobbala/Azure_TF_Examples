System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            default_1 = (function () {
                function default_1($filter) {
                    this.$filter = $filter;
                    this.byOcgModel = {
                        id: null,
                        selectedIndex: 0,
                        tabs: [{
                                title: '',
                                templateurl: null,
                                disabled: false,
                                model: null
                            }]
                    };
                }
                default_1.prototype.$onChanges = function (hash) {
                    var self = this;
                    if (hash.model && this.model.length > 0) {
                        var tabList = this.model.map(function (ocg) {
                            return {
                                title: ocg.ocgName,
                                templateurl: '/app/shared/byOcgByDay/byOcg.html',
                                disabled: false,
                                model: {
                                    id: null,
                                    selectedIndex: 0,
                                    componentName: self.componentName,
                                    tabs: ocg.daysOfService.map(function (day) {
                                        return {
                                            title: self.$filter('date')(new Date(day.serviceDate), 'MM-dd-yyyy'),
                                            templateurl: '/app/shared/byOcgByDay/byDay.html',
                                            disabled: false,
                                            model: day,
                                        };
                                    })
                                }
                            };
                        });
                        this.byOcgModel.tabs = tabList;
                        //Workaround first tab not displaying the correct template (due to the change event not firing after update)
                        this.byOcgModel.selectedIndex = '0';
                    }
                };
                default_1.$inject = ['$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=byOcgByDay.controller.js.map