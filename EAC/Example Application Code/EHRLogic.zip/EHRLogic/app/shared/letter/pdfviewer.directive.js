System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var default_1;
    return {
        setters:[],
        execute: function() {
            //Simple directive that takes a component name as a string, and an expression to evaluate for the model, and dynamically creates that component
            default_1 = (function () {
                function default_1() {
                    this.scope = {
                        data: '='
                    };
                    this.link = {
                        post: function (scope, element, attributes, controller, transclude) {
                            if (attributes.$attr['data'] && element.attr(attributes.$attr['data'])) {
                                // Retrieve any custom class provided.
                                var cssClass = '';
                                if (attributes.$attr['class']) {
                                    cssClass = element.attr(attributes.$attr['class']);
                                }
                                // Retrieve the scaling information from the tag.
                                var scale = 1.5;
                                if (attributes.$attr['scale']) {
                                    scale = parseFloat(element.attr(attributes.$attr['scale']));
                                }
                                scope.$watch('data', function (newValue, oldValue) {
                                    if (newValue) {
                                        //Define the html for the component
                                        var html = [];
                                        PDFJS = PDFJS || window['PDFJS'];
                                        // atob() is used to convert base64 encoded PDF to binary-like data.
                                        var pdfData = atob(newValue);
                                        // Disable workers to avoid yet another cross-origin issue (workers need
                                        // the URL of the script to be loaded, and dynamically loading a cross-origin
                                        // script does not work).
                                        // PDFJS.disableWorker = true;
                                        // The workerSrc property shall be specified.
                                        PDFJS.workerSrc = 'Scripts/pdfjs/pdf.worker.js';
                                        // Using DocumentInitParameters object to load binary data.
                                        var loadingTask = PDFJS.getDocument({ data: pdfData });
                                        loadingTask.promise.then(function (pdf) {
                                            html.push('<div id="pdf-viewer-dir">');
                                            if (pdf.numPages > 0) {
                                                for (var pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                                                    html.push('<canvas id="pdf-viewer-canvas-' + pageNum + '"></canvas>');
                                                }
                                            }
                                            html.push('</div>');
                                            //Can't use normal constructor injection because the object is instantiated directly in the init file
                                            var $compile = element.injector().get('$compile');
                                            //Compile the component using the current scope
                                            var e = $compile(html.join(''))(scope);
                                            //Add the component to the page, replacing this directive
                                            element.empty().append(e);
                                            // Loop through the pages and render each page.
                                            for (var pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                                                pdf.getPage(pageNum).then(function (page) {
                                                    var viewport = page.getViewport(scale);
                                                    // Prepare canvas using PDF page dimensions
                                                    var canvas;
                                                    canvas = document.getElementById('pdf-viewer-canvas-' + page.pageNumber);
                                                    var context = canvas.getContext('2d');
                                                    canvas.height = viewport.height;
                                                    canvas.width = viewport.width;
                                                    // Render PDF page into canvas context
                                                    var renderContext = { canvasContext: context, viewport: viewport };
                                                    page.render(renderContext).then(function () { });
                                                });
                                            }
                                        }, function (reason) {
                                            console.error(reason);
                                        });
                                    }
                                });
                            }
                            else {
                                return "";
                            }
                        }
                    };
                }
                default_1.directiveName = 'pdfViewer';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=pdfviewer.directive.js.map