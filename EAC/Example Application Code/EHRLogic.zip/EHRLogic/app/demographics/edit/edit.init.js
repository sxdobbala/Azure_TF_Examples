System.register(['./edit.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var edit_component_1;
    return {
        setters:[
            function (edit_component_1_1) {
                edit_component_1 = edit_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.editdemographics', [])
                .component(edit_component_1.default.componentName, new edit_component_1.default());
        }
    }
});
//# sourceMappingURL=edit.init.js.map