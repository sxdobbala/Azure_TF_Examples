System.register(['../demographics/demographics.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var demographics_service_1;
    var default_1;
    return {
        setters:[
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                // Constructor
                function default_1($http, appConfig, $q, $filter, service) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.$q = $q;
                    this.$filter = $filter;
                    this.service = service;
                    // Declare the Public Data Members
                    this.protocolRules = Array();
                    this.messages = {};
                    this.setTranslation();
                }
                // Get Methods
                default_1.prototype.loadProtocolRules = function (assessmentId) {
                    var that = this;
                    that.assessmentId = assessmentId;
                    return that.getProtocolRulesFromServer();
                };
                // Calculation Methods
                default_1.prototype.getDefaultProtocol = function (dos, ccd) {
                    var that = this;
                    if (!that.protocolRules || that.protocolRules === null || that.protocolRules.length === 0) {
                        that.getProtocolRules().then(function (response) {
                            if (response) {
                                return that.calculateDefaultProtocol(dos, ccd);
                            }
                            return null;
                        });
                    }
                    return that.$q.resolve(that.calculateDefaultProtocol(dos, ccd));
                };
                // Private Methods
                default_1.prototype.getProtocolRulesFromServer = function () {
                    var that = this;
                    var data = { assessmentId: that.assessmentId };
                    return that.$http.get(this.appConfig.urls.protocolRules, { params: data }).then(function (response) {
                        angular.copy(response.data, that.protocolRules);
                        return true;
                    }, function (error) {
                        console.error(that.messages.protocolRulesGetFailure);
                        return false;
                    });
                };
                default_1.prototype.getProtocolRules = function () {
                    var that = this;
                    //Template Type rules vary only for reviews(based on Hospital payor), 
                    //as COMPASS window opens for a review, if these rules are loaded once, they need not be loaded for different assessment on same review.
                    if (that.protocolRules && that.protocolRules !== null && that.protocolRules.length > 0) {
                        return that.$q.resolve(true);
                    }
                    return that.getProtocolRulesFromServer();
                };
                default_1.prototype.calculateDefaultProtocol = function (dos, ccd) {
                    var that = this;
                    if (ccd) {
                        return that.getProtocolBasedOnRules(0, ccd);
                    }
                    var sos = new Date(that.service.assessment.startOfServiceDate.toString());
                    if (!dos || dos.toString() === 'Invalid Date' || dos.getTime() < sos.getTime()) {
                        return {
                            defaultProtocol: null,
                            message: null
                        };
                    }
                    var daysSinceSos = that.getDaysDifference(dos, sos);
                    return that.getProtocolBasedOnRules(daysSinceSos, ccd);
                };
                default_1.prototype.getProtocolBasedOnRules = function (daysSinceSos, ccd) {
                    var that = this;
                    var matchingRules = that.protocolRules.filter(function (rule) {
                        return rule.defaultAfterDaysSinceStartOfService !== null && rule.defaultAfterDaysSinceStartOfService <= daysSinceSos && rule.isCustodialConvenienceOrDelay === ccd;
                    }).sort(function (rule, nextRule) {
                        return nextRule.defaultAfterDaysSinceStartOfService - rule.defaultAfterDaysSinceStartOfService;
                    });
                    if (matchingRules === null || (matchingRules != null && matchingRules.length === 0)) {
                        matchingRules = that.protocolRules.filter(function (rule) { return rule.defaultAfterDaysSinceStartOfService === null && rule.isCustodialConvenienceOrDelay === ccd; });
                    }
                    if (matchingRules === null || (matchingRules != null && matchingRules.length === 0)) {
                        return {
                            defaultProtocol: null,
                            message: null
                        };
                    }
                    return {
                        defaultProtocol: matchingRules[0].protocol,
                        message: null
                    };
                };
                default_1.prototype.getDaysDifference = function (dos, sos) {
                    // The number of milliseconds in one day
                    var oneDay = 1000 * 60 * 60 * 24;
                    // Convert both dates to milliseconds
                    var dosMs = dos.getTime();
                    var sosMs = sos.getTime();
                    // Calculate the difference in milliseconds
                    var differenceMs = Math.abs(dosMs - sosMs);
                    // Convert back to days and return
                    return Math.round(differenceMs / oneDay);
                };
                default_1.prototype.setTranslation = function () {
                    this.messages.protocolRulesGetFailure = this.$filter('translate')('ocg_protocol_rules_get_failure');
                    this.messages.recommendedProtocolMessage = this.$filter('translate')('ocg_recommended_protocol');
                };
                default_1.serviceName = 'protocolRulesService';
                // Inject
                default_1.$inject = ['$http', 'appConfig', '$q', '$filter', demographics_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ProtocolRules.service.js.map