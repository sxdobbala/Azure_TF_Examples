System.register(['./assessmentList.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentList_service_1;
    var default_1;
    return {
        setters:[
            function (assessmentList_service_1_1) {
                assessmentList_service_1 = assessmentList_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, $filter, $http) {
                    this.service = service;
                    this.$filter = $filter;
                    this.$http = $http;
                    this.messages = {};
                    this.modelAssessmentList = {
                        clearAllFilters: true,
                        links: ['<span><a href="" title="Refresh Grid" ng-click="model.linkClick()" ><uitk:icon-font icon="cux-icon-refresh"></uitk:icon-font> {{"Refresh" | uitkTranslate}}</a></span>'],
                        linkClick: function () {
                            var currentTableModel = this;
                            this.onRefreshCalled = true;
                            this.onLoad(true);
                        },
                        records: [],
                        totalRecordsCount: 0,
                        pagination: {
                            currentPageNumber: 1,
                            recordsPerPage: 10, paginationWindow: 1,
                            recordsPerPageChoices: [10, 20, 30]
                        },
                        onChange: function (filterConditions) {
                            var currentTableModel = this;
                            if (this.filterConditionsCache === undefined || !angular.equals(filterConditions, this.filterConditionsCache) || this.onRefreshCalled) {
                                if (filterConditions.searchBy === undefined || filterConditions.searchBy.indexOf('dateAdmitted') < 0) {
                                    currentTableModel.admitFilterDialog.beginDate = null;
                                    currentTableModel.admitFilterDialog.endDate = null;
                                    currentTableModel.filterAdmitDialogOldSession = null;
                                }
                                if (filterConditions.searchBy === undefined || filterConditions.searchBy.indexOf('completedOn') < 0) {
                                    currentTableModel.completedOnFilterDialog.beginDate = null;
                                    currentTableModel.completedOnFilterDialog.endDate = null;
                                    currentTableModel.filterCompletedDialogOldSession = null;
                                }
                                this.service.getList(filterConditions).then(function (response) {
                                    if (response) {
                                        currentTableModel.totalRecordsCount = currentTableModel.service.totalRecordCount;
                                        currentTableModel.records = currentTableModel.service.filteredRecords.slice();
                                    }
                                });
                                this.filterConditionsCache = angular.copy(filterConditions);
                                this.onRefreshCalled = false;
                            }
                        },
                        columns: [
                            {
                                columnId: 'name',
                                label: 'Name',
                                style: "width: 260px;",
                                layoutOrder: 1,
                                sortable: true,
                                sortOrder: 0,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="nameFilter" class="oui-a11y-hidden">Filter by name</label> ',
                                    '<input type="text" ng-model="column.searchInput" id="nameFilter"/> '
                                ].join(''),
                                cellTemplate: '<a ng-href="#!/assessment/{{record.assessmentId}}"  ng-bind="::record.name"> </a>'
                            },
                            {
                                columnId: 'hospital',
                                label: 'Hospital',
                                style: "width: 260px;",
                                layoutOrder: 2,
                                sortable: true,
                                sortOrder: 0,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="hospitalFilter" class="oui-a11y-hidden">Filter by name</label> ',
                                    '<input type="text" ng-model="column.searchInput" id="hospitalFilter"/> '
                                ].join(''),
                                cellTemplate: '<span ng-bind="::record.hospital"> </span>'
                            },
                            {
                                columnId: 'accountNumber',
                                label: 'Account Number',
                                style: "width: 169px;",
                                layoutOrder: 3,
                                sortable: true,
                                sortOrder: 0,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="accountNumberFilter" class="oui-a11y-hidden">Filter by hospital</label> ',
                                    '<input type="text" ng-model="column.searchInput" id="accountNumberFilter"/> '
                                ].join(''),
                                cellTemplate: '<span ng-bind="::record.accountNumber"> </span>'
                            },
                            {
                                columnId: 'status',
                                label: 'Status',
                                style: "width: 175px;",
                                layoutOrder: 4,
                                sortable: true,
                                sortOrder: 0,
                                searchInput: 'Pending',
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="statusFilter" class="oui-a11y-hidden">Filter by status</label> ',
                                    '<select ng-model="column.searchInput" id="statusFilter">',
                                    '	<option value="">All</option>',
                                    '	<option value="Pending">Pending</option>',
                                    '	<option value="Complete">Complete</option>',
                                    '</select> '
                                ].join(''),
                                cellTemplate: '<span ng-bind="::record.status"> </span>'
                            },
                            {
                                columnId: 'dateAdmitted',
                                label: 'Date Admitted',
                                style: "width: 175px;",
                                layoutOrder: 5,
                                sortable: true,
                                sortOrder: 1,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="dateAdmittedFilter" class="oui-a11y-hidden">Filter by admit date</label> ',
                                    '<a href="" ng-click="model.launchAdmitDateFilterDialog()"> <uitk:icon-font icon= "cux-icon-filter"></uitk:icon-font></a>',
                                    '<uitk:dialog dialog-id="admitDateDialogID"  call-back-hide="model.onAdmitDialogCancel()" dialog-role="dialog" confirm-dialog="false" header-text="Filter by Date" show= "model.showAdmitDateFilterDialog" ng-if="model.showAdmitDateFilterDialog" >',
                                    '<assessmentdate-filter id="admitDateContentID"  close-dialog="model.showAdmitDateFilterDialog = false" date-filter-dialog="model.admitFilterDialog" on-cancel="model.onAdmitDialogCancel()" set-search-input="model.setAdmitSearchInput(column)" ></assessmentdate-filter>',
                                    '</uitk:dialog>'
                                ].join(''),
                                cellTemplate: '<span ng-bind=\'::record.dateAdmitted|date:"MM-dd-yyyy"\'> </span>'
                            },
                            {
                                columnId: 'completedBy',
                                label: 'Completed By',
                                style: "width: 260px;",
                                layoutOrder: 6,
                                sortable: true,
                                sortOrder: 0,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="completedByFilter" class="oui-a11y-hidden">Filter by completed by</label> ',
                                    '<input type="text" ng-model="column.searchInput" id="completedByFilter"/> '
                                ].join(''),
                                cellTemplate: '<span ng-bind="::record.completedBy"> </span>'
                            },
                            {
                                columnId: 'completedOn',
                                label: 'Completed On',
                                style: "width: 169px;",
                                layoutOrder: 7,
                                sortable: true,
                                sortOrder: 0,
                                enableSearch: true,
                                cellHeaderTemplate: [
                                    '<label for="completedOnFilter" class="oui-a11y-hidden">Filter by admit date</label> ',
                                    '<a href="" ng-click="model.launchCompletedOnDateFilterDialog()"> <uitk:icon-font icon= "cux-icon-filter"></uitk:icon-font></a>',
                                    '<uitk:dialog dialog-id="completedDateDialogID"  call-back-hide="model.onCompletedOnDialogCancel()" dialog-role="dialog" confirm-dialog="false" header-text="Filter by Date" show= "model.showCompletedDateFilterDialog" ng-if="model.showCompletedDateFilterDialog" >',
                                    '<assessmentdate-filter id="completedOnContentID" close-dialog="model.showCompletedDateFilterDialog = false" date-filter-dialog="model.completedOnFilterDialog" on-cancel="model.onCompletedOnDialogCancel()" set-search-input="model.setCompletedOnSearchInput(column)" ></assessmentdate-filter>',
                                    '</uitk:dialog>'
                                ].join(''),
                                cellTemplate: '<span ng-bind=\'::record.completedOn|date:"MM-dd-yyyy h:mm a"\'> </span>'
                            }
                        ],
                        validateDateInput: function (filterDialog) {
                            var currentTableModel = this;
                            if (filterDialog.filterMethodType == 0) {
                                if (filterDialog.beginDate == null) {
                                    filterDialog.beginDateError = true;
                                    var errorFields = new Array();
                                    var errorMessages = new Array();
                                    errorFields.push(currentTableModel.messages.beginDateEmpty);
                                    currentTableModel.displayFilterValidationMessages(errorMessages, errorFields);
                                    return false;
                                }
                            }
                            else if (filterDialog.filterMethodType == 1) {
                                if (filterDialog.beginDate == null || filterDialog.endDate == null) {
                                    var errorFields = new Array();
                                    var errorMessages = new Array();
                                    if (filterDialog.beginDate == null) {
                                        filterDialog.beginDateError = true;
                                        errorFields.push(currentTableModel.messages.beginDateEmpty);
                                    }
                                    if (filterDialog.endDate == null) {
                                        filterDialog.endDateError = true;
                                        errorFields.push(currentTableModel.messages.endDateEmpty);
                                    }
                                    currentTableModel.displayFilterValidationMessages(errorMessages, errorFields);
                                    return false;
                                }
                            }
                            return true;
                        },
                        setSearchInput: function (column, filterDialog) {
                            var currentTableModel = this;
                            filterDialog.beginDateError = false;
                            filterDialog.endDateError = false;
                            if (filterDialog.filterMethodType === 0) {
                                if (filterDialog.beginDate !== null) {
                                    currentTableModel.filterAdmitDialogOldSession = angular.copy(filterDialog);
                                    var dateValue = currentTableModel.$filter('date')(filterDialog.beginDate, this.messages.dateFormat);
                                    column.searchInput = dateValue;
                                }
                            }
                            else if (filterDialog.filterMethodType === 1) {
                                var beginDate = currentTableModel.$filter('date')(filterDialog.beginDate, this.messages.dateFormat);
                                var endDate = currentTableModel.$filter('date')(filterDialog.endDate, this.messages.dateFormat);
                                column.searchInput = beginDate + 'TO' + endDate;
                            }
                            else {
                                filterDialog.beginDate = null;
                                filterDialog.endDate = null;
                                column.searchInput = '';
                            }
                        },
                        setAdmitSearchInput: function (column) {
                            var currentTableModel = this;
                            if (currentTableModel.validateDateInput(currentTableModel.admitFilterDialog)) {
                                currentTableModel.setSearchInput(column, currentTableModel.admitFilterDialog);
                                currentTableModel.filterAdmitDialogOldSession = angular.copy(currentTableModel.admitFilterDialog);
                                currentTableModel.showAdmitDateFilterDialog = false;
                            }
                        },
                        setCompletedOnSearchInput: function (column) {
                            var currentTableModel = this;
                            if (currentTableModel.validateDateInput(currentTableModel.completedOnFilterDialog)) {
                                currentTableModel.setSearchInput(column, currentTableModel.completedOnFilterDialog);
                                currentTableModel.filterCompletedDialogOldSession = angular.copy(currentTableModel.completedOnFilterDialog);
                                currentTableModel.showCompletedDateFilterDialog = false;
                            }
                        },
                        filterAdmitDialogOldSession: null,
                        filterCompletedDialogOldSession: null,
                        admitFilterDialog: {
                            filterMethodType: 0,
                            filterMethodItems: [
                                {
                                    label: 'Filter by single date',
                                    value: '0',
                                    disabled: false
                                },
                                {
                                    label: 'Filter by date range',
                                    value: '1',
                                    disabled: false
                                },
                                {
                                    label: 'Clear Filters',
                                    value: '2',
                                    disabled: false
                                }
                            ],
                            beginDateViewModel: {
                                maxYear: new Date().getFullYear(),
                                iconCalendar: true,
                                displayTipText: '<span></span>'
                            },
                            endDateViewModel: {
                                maxYear: new Date().getFullYear(),
                                iconCalendar: true,
                                displayTipText: '<span></span>'
                            },
                            beginDate: null,
                            endDate: null,
                            beginDateError: false
                        },
                        completedOnFilterDialog: {
                            filterMethodType: 0,
                            filterMethodItems: [
                                {
                                    label: 'Filter by single date',
                                    value: '0',
                                    disabled: false
                                },
                                {
                                    label: 'Filter by date range',
                                    value: '1',
                                    disabled: false
                                },
                                {
                                    label: 'Clear Filters',
                                    value: '2',
                                    disabled: false
                                }
                            ],
                            beginDateViewModel: {
                                maxYear: new Date().getFullYear(),
                                iconCalendar: true,
                                displayTipText: '<span></span>'
                            },
                            endDateViewModel: {
                                maxYear: new Date().getFullYear(),
                                iconCalendar: true,
                                displayTipText: '<span></span>'
                            },
                            beginDate: null,
                            endDate: null
                        },
                        showAdmitDateFilterDialog: false,
                        showCompletedDateFilterDialog: false,
                        launchAdmitDateFilterDialog: function () {
                            var currentTableModel = this;
                            this.showAdmitDateFilterDialog = true;
                        },
                        launchCompletedOnDateFilterDialog: function () {
                            var currentTableModel = this;
                            this.showCompletedDateFilterDialog = true;
                        },
                        onFilterDialogCancel: function (filterDialog) {
                            filterDialog.beginDate = null;
                            filterDialog.endDate = null;
                            filterDialog.beginDateError = false;
                            filterDialog.endDateError = false;
                        },
                        onAdmitDialogCancel: function () {
                            var currentTableModel = this;
                            if (currentTableModel.filterAdmitDialogOldSession === null) {
                                currentTableModel.onFilterDialogCancel(currentTableModel.admitFilterDialog);
                            }
                            else {
                                currentTableModel.admitFilterDialog = angular.copy(currentTableModel.filterAdmitDialogOldSession);
                            }
                            this.showAdmitDateFilterDialog = false;
                        },
                        onCompletedOnDialogCancel: function () {
                            var currentTableModel = this;
                            if (currentTableModel.filterCompletedDialogOldSession == null) {
                                currentTableModel.onFilterDialogCancel(currentTableModel.completedOnFilterDialog);
                            }
                            else {
                                currentTableModel.completedOnFilterDialog = angular.copy(currentTableModel.filterCompletedDialogOldSession);
                            }
                            this.showCompletedDateFilterDialog = false;
                        },
                        displayFilterValidationMessages: function (errorMessages, errorFields) {
                            var Error = '<ul class="tk-padding-bottom-min">' + errorMessages.join('</ul><ul class="tk-padding-bottom-min">') + '</ul>' +
                                '<ul class="dateFilter-errors">' + this.messages.dateFilterError + errorFields.join(', ') + '</ul>';
                            console.error(Error);
                        }
                    };
                    this.initialize();
                    this.setTranslation();
                }
                default_1.prototype.setTranslation = function () {
                    this.messages.beginDateEmpty = this.$filter('translate')('assessmentList_filter_beginDate');
                    this.messages.endDateEmpty = this.$filter('translate')('assessmentList_filter_endDate');
                    this.messages.dateFilterError = this.$filter('translate')('assessmentList_filter_validation');
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                };
                default_1.prototype.initialize = function () {
                    var self = this;
                    self.modelAssessmentList.service = this.service;
                    self.modelAssessmentList.$filter = self.$filter;
                    self.modelAssessmentList.messages = self.messages;
                };
                default_1.$inject = [assessmentList_service_1.default.serviceName, '$filter', '$http'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentList.controller.js.map