System.register(["./main.controller", "../examplehospital/examplehospitalcontainer.component", "../assessmentList/assessmentList.component", "../assessmentContainer/assessmentContainer.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var main_controller_1, examplehospitalcontainer_component_1, assessmentList_component_1, assessmentContainer_component_1;
    var default_1;
    return {
        setters:[
            function (main_controller_1_1) {
                main_controller_1 = main_controller_1_1;
            },
            function (examplehospitalcontainer_component_1_1) {
                examplehospitalcontainer_component_1 = examplehospitalcontainer_component_1_1;
            },
            function (assessmentList_component_1_1) {
                assessmentList_component_1 = assessmentList_component_1_1;
            },
            function (assessmentContainer_component_1_1) {
                assessmentContainer_component_1 = assessmentContainer_component_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/main/main.html';
                    this.controller = main_controller_1.default;
                    this.bindings = {};
                    this.$routeConfig = [
                        { path: '/assessmentList', name: 'AssessmentList', component: assessmentList_component_1.default.componentName, useAsDefault: true },
                        { path: '/hospital', name: 'Example', component: examplehospitalcontainer_component_1.default.componentName },
                        { path: '/assessment', name: 'CreateAssessment', component: assessmentContainer_component_1.default.componentName },
                        { path: '/assessment/:id/...', name: 'EditAssessment', component: assessmentContainer_component_1.default.componentName }
                    ];
                }
                default_1.componentName = 'start';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=main.component.js.map