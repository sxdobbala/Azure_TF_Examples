System.register(['./recommendation.component', './recommendation.service', 'byOcgByDay', 'requiresDaysMessage', 'routeHelper'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var recommendation_component_1, recommendation_service_1;
    return {
        setters:[
            function (recommendation_component_1_1) {
                recommendation_component_1 = recommendation_component_1_1;
            },
            function (recommendation_service_1_1) {
                recommendation_service_1 = recommendation_service_1_1;
            },
            function (_1) {},
            function (_2) {},
            function (_3) {}],
        execute: function() {
            angular
                .module('compass.recommendation', ['compass.byOcgByDay', 'compass.shared.requiresDaysMessage', 'compass.shared.routeHelper'])
                .component(recommendation_component_1.default.componentName, new recommendation_component_1.default())
                .service(recommendation_service_1.default.serviceName, recommendation_service_1.default);
        }
    }
});
//# sourceMappingURL=recommendation.init.js.map