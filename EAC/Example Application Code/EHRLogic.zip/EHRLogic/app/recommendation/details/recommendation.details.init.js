System.register(['./recommendation.details.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var recommendation_details_component_1;
    return {
        setters:[
            function (recommendation_details_component_1_1) {
                recommendation_details_component_1 = recommendation_details_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.recommendation.details', [])
                .component(recommendation_details_component_1.default.componentName, new recommendation_details_component_1.default());
        }
    }
});
//# sourceMappingURL=recommendation.details.init.js.map