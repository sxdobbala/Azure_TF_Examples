System.register(['../events/event.service', './recommendation.service', './recommendation.event', './recommendation.constant', '../shared/routeHelper/routeHelper.service', '../riskfactor/riskfactor.event', '../events/common.events'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var event_service_1, recommendation_service_1, recommendationEvents, recommendation_constant_1, routeHelper_service_1, riskFactorEvents, commonEvents;
    var recommendationController;
    return {
        setters:[
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (recommendation_service_1_1) {
                recommendation_service_1 = recommendation_service_1_1;
            },
            function (recommendationEvents_1) {
                recommendationEvents = recommendationEvents_1;
            },
            function (recommendation_constant_1_1) {
                recommendation_constant_1 = recommendation_constant_1_1;
            },
            function (routeHelper_service_1_1) {
                routeHelper_service_1 = routeHelper_service_1_1;
            },
            function (riskFactorEvents_1) {
                riskFactorEvents = riskFactorEvents_1;
            },
            function (commonEvents_1) {
                commonEvents = commonEvents_1;
            }],
        execute: function() {
            //WARNING: No more than one recommendation component can exist at any time, because isDirty state management is in the service (which is a singleton)
            recommendationController = (function () {
                function recommendationController(event, service, routeHelper, $filter, $q, $scope, $sanitize) {
                    this.event = event;
                    this.service = service;
                    this.routeHelper = routeHelper;
                    this.$filter = $filter;
                    this.$q = $q;
                    this.$scope = $scope;
                    this.$sanitize = $sanitize;
                    this.showRecommendationWarning = false;
                    this.recommendationsForNota = [];
                    this.recommendationsForNonNota = [];
                    this.messages = {};
                    this.showCancelConfirmationDialog = false;
                    this.eventList = [];
                }
                //The postLink event happens after all the view is linked to the model, so the recommendationForm is not null here
                recommendationController.prototype.$postLink = function () {
                    this.registerEvents();
                    this.setupDirtyWatch();
                    this.setTranslation();
                    this.initialize();
                };
                recommendationController.prototype.initialize = function () {
                    var _this = this;
                    this.service.setDirtyFlag(false); // Reset the dirty flag when the page loads.
                    this.assessmentId = this.routeHelper.getAssessmentId();
                    var callbacks = [];
                    callbacks.push(this.service.getPatientStatus(true).then(function (data) {
                        _this.recommendationsForNota = data;
                    }));
                    callbacks.push(this.service.getPatientStatus(false).then(function (data) {
                        _this.recommendationsForNonNota = data;
                    }));
                    if (this.assessmentId) {
                        var self = this;
                        callbacks.push(this.service.getData(this.assessmentId).then(function (data) {
                            var self = _this;
                            _this.model = data;
                            _this.model.data.forEach(function (day) {
                                day.warningMessages = self.setupWarning(day);
                            });
                            _this.missingEarlierNodes = _this.model.data.length == 0;
                        }));
                        this.$q.all(callbacks).then(function () {
                            var count = 0;
                            _this.model.data.forEach(function (day) {
                                var isNota = day.protocolName == recommendation_constant_1.AdministrativeNota ? true : false;
                                day.patientStatusList = isNota ? _this.recommendationsForNota : _this.recommendationsForNonNota;
                                //Find the selected status in the list, and assign it
                                day.selectedPatientStatus = day.patientStatusList.reduce(function (selected, item) {
                                    //If selected, change current to the the selected
                                    if (item.value == day.patientStatusId) {
                                        return item;
                                    }
                                    else {
                                        //Otherwise keep the selection                            
                                        return selected;
                                    }
                                }, day.patientStatusList[0]);
                                _this.onSelect(day);
                            });
                        }, function (error) {
                            console.error('error loading recommendation section');
                        });
                    }
                    else {
                        console.error('unable to determine assessment id');
                    }
                };
                recommendationController.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                recommendationController.prototype.save = function () {
                    var _this = this;
                    var self = this;
                    self.model.assessmentId = this.assessmentId;
                    for (var index in self.model.data) {
                        self.model.data[index].patientStatusList[0].label = "";
                        self.model.data[index].patientStatusId = self.model.data[index].selectedPatientStatus.value;
                    }
                    return this.service.saveRecommendations(self.model).then(function (result) {
                        if (!result) {
                            return self.$q.reject('unhandled error');
                        }
                        for (var index in self.model.data) {
                            self.model.data[index].patientStatusList[0].label = "Select";
                            self.model.data[index].patientStatusId = self.model.data[index].selectedPatientStatus.value;
                        }
                        if (result) {
                            if (result.isRecommendationViewComplete) {
                                console.log(self.messages.saveRecommendationSuccess);
                            }
                            else {
                                console.warn(self.messages.saveRecommendationWarning);
                            }
                        }
                        //Reset the form's dirty flag
                        self.recommendationForm.$setPristine();
                        _this.event.raise(commonEvents.summarySave);
                        _this.event.raise(riskFactorEvents.riskFactorOnPageCheckRiskFactorCompleteness);
                        if (result) {
                            if (result.isRecommendationViewComplete) {
                                //Display filled circle to user
                                _this.event.raise(recommendationEvents.recommendationOnPageComplete);
                            }
                            else {
                                _this.event.raise(recommendationEvents.recommendationOnPageIncomplete);
                            }
                        }
                        return true;
                    }, function (error) {
                        //Display error icon to user
                        _this.event.raise(recommendationEvents.recommendationOnPageError);
                        //Continue propogating the error
                        return self.$q.reject(error);
                    });
                };
                recommendationController.prototype.setTranslation = function () {
                    this.messages.saveRecommendationSuccess = this.$filter('translate')('recommendation_save_success');
                    this.messages.saveRecommendationWarning = this.$filter('translate')('recommendation_save_warning');
                };
                recommendationController.prototype.registerEvents = function () {
                    var _this = this;
                    this.eventList.push(this.event.subscribe(recommendationEvents.recommendationOnNavigationSave, function () {
                        return _this.save();
                    }));
                    this.eventList.push(this.event.subscribe(recommendationEvents.recommendationOnNavigationDiscard, function () {
                        _this.event.raise(recommendationEvents.recommendationOnPageResetRecommendationCompleteness);
                        return _this.$q.resolve(true);
                    }));
                };
                recommendationController.prototype.unRegisterEvents = function () {
                    for (var _i = 0, _a = this.eventList; _i < _a.length; _i++) {
                        var item = _a[_i];
                        this.event.unsubscribe(item.actionName, item.id);
                    }
                };
                recommendationController.prototype.setupDirtyWatch = function () {
                    var _this = this;
                    this.$scope.$watch(function (s) { return _this.recommendationForm.$dirty; }, function (isDirty) {
                        _this.service.setDirtyFlag(isDirty);
                        if (isDirty) {
                            _this.event.raise(recommendationEvents.recommendationOnPageIncomplete);
                        }
                    }, false);
                };
                recommendationController.prototype.setupWarning = function (day) {
                    var warningMessage = {};
                    warningMessage.id = 'warningMsg_' + day.dayOfServiceId.toString();
                    warningMessage.messageType = 'warning';
                    warningMessage.closeButton = false;
                    warningMessage.position = 'inline';
                    warningMessage.visible = true;
                    warningMessage.content = '<span>Selected Risk Factors do not support the selected Recommendation.</span>';
                    return warningMessage;
                };
                recommendationController.prototype.onSelect = function (day) {
                    var self = this;
                    day.showRecommendationWarning =
                        (day.isIpNotValid && day.selectedPatientStatus.label == 'Inpatient') ? true :
                            (day.isOpNotValid && day.selectedPatientStatus.label == 'Outpatient') ? true :
                                (day.isNaNotValid && day.selectedPatientStatus.label == 'Not Appropriate') ? true : false;
                    self.setupWarning(day);
                };
                recommendationController.prototype.onCancel = function () {
                    if (this.recommendationForm.$dirty) {
                        this.showCancelConfirmationDialog = true;
                    }
                };
                recommendationController.prototype.onCancelConfirmation = function (cancel) {
                    this.showCancelConfirmationDialog = false;
                    if (cancel) {
                        this.initialize();
                        this.event.raise(recommendationEvents.recommendationOnPageCheckCompleteness);
                        this.event.raise(recommendationEvents.recommendationOnPageResetRecommendationCompleteness);
                        this.recommendationForm.$setPristine();
                    }
                };
                recommendationController.$inject = [
                    event_service_1.default.serviceName,
                    recommendation_service_1.default.serviceName,
                    routeHelper_service_1.default.serviceName,
                    '$filter',
                    '$q',
                    '$scope',
                    '$sanitize'];
                return recommendationController;
            }());
            exports_1("default", recommendationController);
        }
    }
});
//# sourceMappingURL=recommendation.controller.js.map