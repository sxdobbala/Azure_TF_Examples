System.register(['./letter-list.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var letter_list_service_1;
    var default_1;
    return {
        setters:[
            function (letter_list_service_1_1) {
                letter_list_service_1 = letter_list_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service) {
                    var _this = this;
                    this.service = service;
                    /* END - 1 way bindings from Parent component*/
                    this.letterGrid = {
                        service: this,
                        records: [],
                        totalRecordsCount: 0,
                        columns: [
                            {
                                columnId: 'fileName',
                                label: 'File Name',
                                style: "width: 260px;",
                                layoutOrder: 1,
                                cellTemplate: '<a target="_blank" href="{{model.getUrl(record.documentId)}}">{{model.getFileName(record.fileName, record.extension)}}</a>'
                            },
                            {
                                columnId: 'createdOn',
                                label: 'Created On',
                                style: "width: 260px;",
                                layoutOrder: 2,
                                cellTemplate: '<span ng-bind=\'::record.createdOnDate|date:"MM/dd/yyyy hh:mm:ss a"\'></span>'
                            },
                            {
                                columnId: 'createdBy',
                                label: 'Created By',
                                layoutOrder: 3,
                                cellTemplate: '<span ng-bind="::record.createdBy"></span>'
                            }
                        ],
                        getUrl: function (documentId) {
                            return _this.service.documentUrl + '?id=' + documentId;
                        },
                        getFileName: function (fileName, extension) {
                            return fileName + (extension ? ('.' + extension) : '');
                        },
                        onChange: function () {
                            for (var counter = 0; counter < _this.data.length; counter++) {
                                _this.data[counter].createdOnDate = new Date(_this.data[counter].createdOn);
                            }
                            _this.letterGrid.records = _this.data;
                            _this.letterGrid.totalRecordsCount = _this.data.length;
                        }
                    };
                }
                default_1.prototype.$onChanges = function () {
                    this.letterGrid.records = this.data;
                    this.letterGrid.totalRecordsCount = this.data.length;
                };
                default_1.$inject = [letter_list_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=letter-list.controller.js.map