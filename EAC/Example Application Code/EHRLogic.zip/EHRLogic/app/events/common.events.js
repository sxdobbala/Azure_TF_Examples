System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summarySave, navigate, RefreshLetterList;
    return {
        setters:[],
        execute: function() {
            exports_1("summarySave", summarySave = 'SUMMARY_SAVE');
            exports_1("navigate", navigate = 'NAVIGATE');
            exports_1("RefreshLetterList", RefreshLetterList = 'REFRESH_LETTER_LIST');
        }
    }
});
//# sourceMappingURL=common.events.js.map