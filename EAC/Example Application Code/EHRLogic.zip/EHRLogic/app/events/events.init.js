System.register(['./event.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var event_service_1;
    return {
        setters:[
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.events', [])
                .service(event_service_1.default.serviceName, event_service_1.default);
        }
    }
});
//# sourceMappingURL=events.init.js.map