System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgOnPageError, ocgOnPageIncomplete, ocgOnPageComplete, ocgOnNavigationSave, ocgOnNavigationDiscard, ocgFieldsIsdirty, ocgOnPageCheckOcgCompleteness, ocgOnPageResetOcgCompleteness, ocgSetupDefaultProtocol, ocgReCalculateDefaultProtocols;
    return {
        setters:[],
        execute: function() {
            exports_1("ocgOnPageError", ocgOnPageError = 'ocg.onPage.Error');
            exports_1("ocgOnPageIncomplete", ocgOnPageIncomplete = 'ocg.onPage.Incomplete');
            exports_1("ocgOnPageComplete", ocgOnPageComplete = 'ocg.onPage.Complete');
            exports_1("ocgOnNavigationSave", ocgOnNavigationSave = 'ocg.onNavigation.Save');
            exports_1("ocgOnNavigationDiscard", ocgOnNavigationDiscard = 'ocg.onNavigation.Discard');
            exports_1("ocgFieldsIsdirty", ocgFieldsIsdirty = 'ocg.onPage.Isdirty');
            exports_1("ocgOnPageCheckOcgCompleteness", ocgOnPageCheckOcgCompleteness = 'ocg.onPage.Check.Ocg.Completeness');
            exports_1("ocgOnPageResetOcgCompleteness", ocgOnPageResetOcgCompleteness = 'ocg.onPage.Reset.Ocg.Completeness');
            exports_1("ocgSetupDefaultProtocol", ocgSetupDefaultProtocol = 'ocg.onServiceDay.Save.SetupDefaultProtocol');
            exports_1("ocgReCalculateDefaultProtocols", ocgReCalculateDefaultProtocols = 'ocg.onServiceDay.Save.ReCalculateDefaultProtocols');
        }
    }
});
//# sourceMappingURL=ocg.event.js.map