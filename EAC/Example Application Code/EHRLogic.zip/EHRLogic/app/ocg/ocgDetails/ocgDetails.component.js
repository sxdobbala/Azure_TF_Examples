System.register(['./ocgDetails.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgDetails_controller_1;
    var default_1;
    return {
        setters:[
            function (ocgDetails_controller_1_1) {
                ocgDetails_controller_1 = ocgDetails_controller_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/ocg/ocgDetails/ocgDetails.html';
                    this.controller = ocgDetails_controller_1.default;
                    this.bindings = {
                        ocg: '=',
                    };
                }
                default_1.componentName = 'ocgDetails';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocgDetails.component.js.map