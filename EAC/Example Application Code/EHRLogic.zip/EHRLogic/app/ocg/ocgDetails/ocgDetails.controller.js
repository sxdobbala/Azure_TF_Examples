System.register(['../ocg.service', '../ocgKeywordFilter/ocgKeywordFilter.constants', '../../utilities/set'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_service_1, ocgKeywordFilterConstants, set_1;
    var default_1;
    return {
        setters:[
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (ocgKeywordFilterConstants_1) {
                ocgKeywordFilterConstants = ocgKeywordFilterConstants_1;
            },
            function (set_1_1) {
                set_1 = set_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, $filter) {
                    this.service = service;
                    this.$filter = $filter;
                    this.ocgDetails = [];
                    this.showOcgDetailsDialog = false;
                    this.whenToUse = '';
                    this.selectedprotocolId = 0;
                    this.getKeywordsList();
                }
                default_1.prototype.getKeywordsList = function () {
                    var self = this;
                    self.service.getAllKeywords().then(function (response) {
                        self.keywordOcgsList = [];
                        angular.copy(self.service.keywordList, self.keywordOcgsList);
                        self.setUpKeywordToOcg();
                    });
                };
                default_1.prototype.setUpKeywordToOcg = function () {
                    var self = this;
                    if (this.keywordOcgsList) {
                        this.keywordToOcg = {};
                        var _loop_1 = function(obj) {
                            angular.forEach(obj.ocgs, function (value) {
                                value.keywordId = obj.keyword.value;
                            });
                            self.keywordToOcg[obj.keyword.value] = obj.ocgs;
                        };
                        for (var _i = 0, _a = self.keywordOcgsList; _i < _a.length; _i++) {
                            var obj = _a[_i];
                            _loop_1(obj);
                        }
                    }
                };
                default_1.prototype.showOcgDetails = function () {
                    var _this = this;
                    this.ocgDetails = this.service.ocgUsage;
                    this.service.getOcgUsage(this.ocg.value).then(function (response) {
                        if (response) {
                            _this.showOcgDetailsDialog = true;
                            // By default select & show the first template.
                            if (_this.ocgDetails.length > 0) {
                                _this.showWhenToUse(_this.ocgDetails[0].protocol.value);
                            }
                        }
                    });
                };
                default_1.prototype.showWhenToUse = function (protocolId) {
                    this.whenToUse = '';
                    this.selectedprotocolId = protocolId;
                    var data = this.ocgDetails.filter(function (val) {
                        return val.protocol.value === protocolId;
                    });
                    if (data && data.length > 0) {
                        this.whenToUse = data[0].whenToUse;
                    }
                };
                default_1.prototype.onSelect = function (selectedValues, keywordOperatorType) {
                    if (selectedValues.length === 0 || keywordOperatorType == undefined) {
                        this.filteredOcgs = null;
                        return;
                    }
                    var allOcgFilters = new Array();
                    for (var _i = 0, selectedValues_1 = selectedValues; _i < selectedValues_1.length; _i++) {
                        var keywordId = selectedValues_1[_i];
                        allOcgFilters.push(this.keywordToOcg[keywordId]);
                    }
                    var unorderedOcgs = [];
                    switch (keywordOperatorType) {
                        case ocgKeywordFilterConstants.all:
                            unorderedOcgs = set_1.default.getIntersection(allOcgFilters);
                            break;
                        case ocgKeywordFilterConstants.any:
                            unorderedOcgs = set_1.default.union(allOcgFilters);
                            break;
                    }
                    this.filteredOcgs = this.$filter('orderBy')(unorderedOcgs, ['keywordId', 'displayOrder', 'clinicalGroupName']).map(function (item) { return item.ocgId; });
                };
                default_1.$inject = [ocg_service_1.default.serviceName, '$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocgDetails.controller.js.map