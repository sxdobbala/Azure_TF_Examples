System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var any, all;
    return {
        setters:[],
        execute: function() {
            exports_1("any", any = "Any");
            exports_1("all", all = "All");
        }
    }
});
//# sourceMappingURL=ocgKeywordFilter.constants.js.map