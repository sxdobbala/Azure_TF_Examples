System.register(['./ocgKeywordFilter.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgKeywordFilter_controller_1;
    var OcgSearchComponent;
    return {
        setters:[
            function (ocgKeywordFilter_controller_1_1) {
                ocgKeywordFilter_controller_1 = ocgKeywordFilter_controller_1_1;
            }],
        execute: function() {
            OcgSearchComponent = (function () {
                function OcgSearchComponent() {
                    this.templateUrl = 'app/ocg/ocgKeywordFilter/ocgKeywordFilter.html';
                    this.controller = ocgKeywordFilter_controller_1.default;
                    this.bindings = {
                        keywordOcgsList: '<',
                        onCommit: '&'
                    };
                }
                OcgSearchComponent.componentName = 'ocgKeywordFilter';
                return OcgSearchComponent;
            }());
            exports_1("default", OcgSearchComponent);
        }
    }
});
//# sourceMappingURL=ocgKeywordFilter.component.js.map