System.register(['../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                    this.formName = 'ocgForm';
                    this.isDirty = false;
                    this.ocgServiceDays = new Array();
                    this.protocolList = [{ label: '', value: 0 }];
                    this.ocgList = Array();
                    this.ocgUsage = [];
                    this.keywordList = [];
                }
                default_1.prototype.isPageDirty = function () {
                    return this.isDirty;
                };
                default_1.prototype.setDirtyFlag = function (flag) {
                    return this.isDirty = flag;
                };
                default_1.prototype.getAllKeywords = function () {
                    var self = this;
                    var onComplete = function (response) {
                        angular.copy(response.data, self.keywordList);
                        return true;
                    };
                    var onError = function (error) {
                        return self.ajaxErrorService.ShowCommonAjaxError(error.data.message);
                    };
                    return self.$http.get(self.appConfig.urls.getAllKeywords).then(onComplete, onError);
                };
                default_1.prototype.getOcgServiceDays = function (assessmentId) {
                    var _this = this;
                    var self = this;
                    var params = { assessmentId: assessmentId };
                    return this.$http.get(this.appConfig.urls.ocgServiceDays, { params: params }).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.ocgServiceDays);
                            for (var _i = 0, _a = self.ocgServiceDays; _i < _a.length; _i++) {
                                var item = _a[_i];
                                item.serviceDayDate = new Date(item.serviceDate);
                            }
                            return true;
                        }
                        return false;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getProtocolList = function (assessmentId) {
                    var _this = this;
                    var self = this;
                    var data = { assessmentId: assessmentId };
                    return self.$http.get(self.appConfig.urls.protocolList, { params: data }).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.protocolList);
                            return true;
                        }
                        return false;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getOcgList = function () {
                    var that = this;
                    return that.$http.get(this.appConfig.urls.ocgList).then(function (response) {
                        angular.copy(response.data, that.ocgList);
                        return true;
                    }, function (error) {
                        return false;
                    });
                };
                default_1.prototype.saveOcgServiceDays = function (serviceDays) {
                    var _this = this;
                    var self = this;
                    return this.$http.post(this.appConfig.urls.ocgServiceDays, serviceDays).then(function (response) {
                        return response.data;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.getOcgUsage = function (clinicalGroupId) {
                    var _this = this;
                    var data = { clinicalGroupId: clinicalGroupId };
                    return this.$http.get(this.appConfig.urls.ocgusage, { params: data }).then(function (response) {
                        angular.copy(response.data, _this.ocgUsage);
                        return true;
                    }, function (error) {
                        return false;
                    });
                };
                default_1.serviceName = 'ocgService';
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocg.service.js.map