System.register(['../shared/routeHelper/routeHelper.service', '../events/event.service', '../events/common.events', './ocg.event', './ocg.service', '../demographics/demographics.service', '../riskfactor/riskfactor.event', '../recommendation/recommendation.event', '../ProtocolRules/ProtocolRules.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var routeHelper_service_1, event_service_1, commonEvents, ocgEvents, ocg_service_1, demographics_service_1, riskFactorEvents, recommendation_event_1, ProtocolRules_service_1;
    var default_1;
    return {
        setters:[
            function (routeHelper_service_1_1) {
                routeHelper_service_1 = routeHelper_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (commonEvents_1) {
                commonEvents = commonEvents_1;
            },
            function (ocgEvents_1) {
                ocgEvents = ocgEvents_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (demographics_service_1_1) {
                demographics_service_1 = demographics_service_1_1;
            },
            function (riskFactorEvents_1) {
                riskFactorEvents = riskFactorEvents_1;
            },
            function (recommendation_event_1_1) {
                recommendation_event_1 = recommendation_event_1_1;
            },
            function (ProtocolRules_service_1_1) {
                ProtocolRules_service_1 = ProtocolRules_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, routeHelper, event, demographicsService, $filter, $scope, $q, $timeout, protocolRulesService) {
                    this.service = service;
                    this.routeHelper = routeHelper;
                    this.event = event;
                    this.demographicsService = demographicsService;
                    this.$filter = $filter;
                    this.$scope = $scope;
                    this.$q = $q;
                    this.$timeout = $timeout;
                    this.protocolRulesService = protocolRulesService;
                    this.datesWithProtocolChange = new Array();
                    this.showCancelConfirmationDialog = false;
                    this.showClinicalGroupChangeConfirmationDialog = false;
                    this.showProtocolChangeConfirmationDialog = false;
                    this.messages = {};
                    this.serviceDaysToSave = new Array();
                    this.routeChanged = false;
                    this.setTranslation();
                    this.registerEvents();
                }
                default_1.prototype.$onInit = function () {
                    this.formName = this.service.formName;
                    this.service.setDirtyFlag(false); // Reset the dirty flag when the page loads.
                };
                default_1.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                // Route Events
                default_1.prototype.$routerOnActivate = function () {
                    this.assessmentId = this.routeHelper.getAssessmentId();
                    if (this.assessmentId && this.assessmentId != null) {
                        this.initialize();
                    }
                };
                ;
                default_1.prototype.setTranslation = function () {
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                    this.messages.dateLabel = this.$filter('translate')('ocg_day_date_label');
                    this.messages.ocgLabel = this.$filter('translate')('ocg_optum_clinical_group_label');
                    this.messages.protocolLabel = this.$filter('translate')('ocg_day_protocol_label');
                    this.messages.duplicateDatesValidation = this.$filter('translate')('ocg_duplicate_dates_validation');
                    this.messages.invalidDateValidation = this.$filter('translate')('ocg_invalid_date_validation');
                    this.messages.requiredFieldsValidation = this.$filter('translate')('ocg_required_fileds_validation');
                    this.messages.saveFailure = this.$filter('translate')('ocg_save_failure');
                    this.messages.saveSuccess = this.$filter('translate')('ocg_save_success');
                    this.messages.startOfServiceLaterThanServiceDate = this.$filter('translate')('ocg_save_start_of_service_later_than_service_date');
                };
                default_1.prototype.initialize = function () {
                    var _this = this;
                    this.protocolRulesService.loadProtocolRules(this.assessmentId).then(function () {
                        _this.loadOcgServiceDays();
                    });
                    this.setupDirtyWatch();
                };
                default_1.prototype.CheckTimelineNodeCompleteness = function () {
                    this.event.raise(ocgEvents.ocgOnPageCheckOcgCompleteness);
                    this.event.raise(riskFactorEvents.riskFactorOnPageCheckRiskFactorCompleteness);
                    this.event.raise(recommendation_event_1.recommendationOnPageCheckCompleteness);
                };
                default_1.prototype.setupServiceDays = function () {
                    var ocg = this.service.ocgServiceDays[0].clinicalGroup;
                    this.clinicalGroup = { value: ocg.value, label: ocg.label };
                    this.backupClinicalGroup = { value: ocg.value, label: ocg.label };
                    this.ocgServiceDays = [];
                    angular.copy(this.service.ocgServiceDays, this.ocgServiceDays);
                    for (var _i = 0, _a = this.ocgServiceDays; _i < _a.length; _i++) {
                        var serviceDay = _a[_i];
                        serviceDay.serviceDayDate = serviceDay.serviceDate ? new Date(serviceDay.serviceDate) : new Date('');
                        serviceDay.dateViewModel = this.getDateViewModel();
                        serviceDay.protocolList = [{ value: 0, label: '' }];
                        serviceDay.savedProtocol = { value: serviceDay.protocol.value, label: serviceDay.protocol.label };
                    }
                };
                default_1.prototype.checkAssessmentAndsetupInitialServiceDays = function () {
                    var _this = this;
                    if (this.demographicsService.assessment.assessmentId > 0) {
                        this.setupInitialServiceDays();
                        return;
                    }
                    this.demographicsService.getAssessment(this.assessmentId).then(function (response) {
                        _this.setupInitialServiceDays();
                    });
                };
                default_1.prototype.setupInitialServiceDays = function () {
                    this.clinicalGroup = { value: 0, label: '' };
                    this.backupClinicalGroup = { value: 0, label: '' };
                    this.ocgServiceDays = [];
                    this.ocgServiceDays.push({
                        dayOfServiceId: 0,
                        ccd: false,
                        serviceDayDate: new Date(this.demographicsService.assessment.admitDate ? this.demographicsService.assessment.admitDate.toString() : ''),
                        protocol: { value: 0, label: '' },
                        protocolList: [{ value: 0, label: '' }],
                        savedProtocol: { value: 0, label: '' }
                    });
                };
                default_1.prototype.loadOcgServiceDays = function () {
                    var _this = this;
                    this.service.getOcgServiceDays(this.assessmentId).then(function (response) {
                        if (response) {
                            if (_this.service.ocgServiceDays.length > 0) {
                                _this.setupServiceDays();
                            }
                            else {
                                _this.checkAssessmentAndsetupInitialServiceDays();
                            }
                        }
                    });
                };
                default_1.prototype.loadOcgServiceDaysAfterCancel = function () {
                    var _this = this;
                    //enforcing child component bindings refresh
                    this.ocgServiceDays = null;
                    this.clinicalGroup = null;
                    if (this.service.ocgServiceDays.length > 0) {
                        //enforcing 2-way binding if we do not have to make the service call
                        this.$timeout(function () { _this.setupServiceDays(); });
                        return;
                    }
                    this.loadOcgServiceDays();
                };
                default_1.prototype.loadOcgServiceDaysAfterSave = function () {
                    var _this = this;
                    this.service.getOcgServiceDays(this.assessmentId).then(function (response) {
                        if (response) {
                            var ocg = _this.service.ocgServiceDays[0].clinicalGroup;
                            _this.backupClinicalGroup = { value: ocg.value, label: ocg.label };
                            var _loop_1 = function(serviceDay) {
                                serviceDay.savedProtocol = { value: serviceDay.protocol.value, label: serviceDay.protocol.label };
                                if (serviceDay.dayOfServiceId === 0) {
                                    serviceDay.dayOfServiceId = _this.service.ocgServiceDays.filter(function (day) {
                                        return new Date(day.serviceDate).getTime() === serviceDay.serviceDayDate.getTime();
                                    })[0].dayOfServiceId;
                                }
                            };
                            for (var _i = 0, _a = _this.ocgServiceDays; _i < _a.length; _i++) {
                                var serviceDay = _a[_i];
                                _loop_1(serviceDay);
                            }
                            _this.event.raise(ocgEvents.ocgSetupDefaultProtocol);
                        }
                    });
                };
                default_1.prototype.getDateViewModel = function () {
                    return {
                        maxYear: new Date().getFullYear(),
                        renderHintText: false,
                        iconCalendar: true,
                    };
                };
                default_1.prototype.updateModelToSave = function (serviceDayToSave) {
                    //for any day(newly added or modified) that is not deleted set few values
                    if (serviceDayToSave.isDayToBeDeleted === undefined) {
                        serviceDayToSave.isDayToBeDeleted = false;
                        if (!serviceDayToSave.dateViewModel.invalid && serviceDayToSave.serviceDayDate) {
                            serviceDayToSave.serviceDayDate.setHours(0, 0, 0, 0);
                        }
                    }
                    serviceDayToSave.serviceDate = this.$filter('date')(serviceDayToSave.serviceDayDate, this.messages.dateFormat);
                };
                default_1.prototype.updateModelToSaveForOldAssessment = function () {
                    for (var _i = 0, _a = this.service.ocgServiceDays; _i < _a.length; _i++) {
                        var serviceDay = _a[_i];
                        serviceDay.isDayToBeDeleted = true;
                        for (var _b = 0, _c = this.serviceDaysToSave; _b < _c.length; _b++) {
                            var serviceDayToSave = _c[_b];
                            this.updateModelToSave(serviceDayToSave);
                            if (serviceDayToSave.dayOfServiceId === serviceDay.dayOfServiceId) {
                                serviceDay.isDayToBeDeleted = false;
                            }
                        }
                        if (serviceDay.isDayToBeDeleted) {
                            this.serviceDaysToSave.push(serviceDay);
                        }
                    }
                };
                // Before saving Service Days create the model (set isDayToBeDeleted flag).
                default_1.prototype.createModelToSave = function () {
                    angular.copy(this.ocgServiceDays, this.serviceDaysToSave);
                    if (this.service.ocgServiceDays.length > 0) {
                        this.updateModelToSaveForOldAssessment();
                    }
                    else {
                        for (var _i = 0, _a = this.serviceDaysToSave; _i < _a.length; _i++) {
                            var serviceDayToSave = _a[_i];
                            this.updateModelToSave(serviceDayToSave);
                        }
                    }
                };
                default_1.prototype.validateServiceDates = function () {
                    var errorMessages = new Array();
                    var missingRequiredFields = new Array();
                    var _loop_2 = function(serviceDay) {
                        if (serviceDay.isDayToBeDeleted) {
                            return "continue";
                        }
                        if (errorMessages.indexOf(this_1.messages.invalidDateValidation) < 0 && serviceDay.dateViewModel.invalid) {
                            errorMessages.push(this_1.messages.invalidDateValidation);
                        }
                        else if (missingRequiredFields.indexOf(this_1.messages.dateLabel) < 0 &&
                            (!serviceDay.serviceDayDate || serviceDay.serviceDayDate === null || serviceDay.serviceDayDate.toString() === 'Invalid Date')) {
                            missingRequiredFields.push(this_1.messages.dateLabel);
                        }
                        else {
                            if (errorMessages.indexOf(this_1.messages.duplicateDatesValidation) < 0) {
                                var duplicateDates = this_1.serviceDaysToSave.filter(function (nextDay) {
                                    return !nextDay.isDayToBeDeleted && nextDay !== serviceDay &&
                                        !nextDay.dateViewModel.invalid && nextDay.serviceDayDate !== null &&
                                        nextDay.serviceDayDate.getTime() === serviceDay.serviceDayDate.getTime();
                                });
                                if (duplicateDates.length > 0) {
                                    errorMessages.push(this_1.messages.duplicateDatesValidation);
                                }
                            }
                            if (errorMessages.indexOf(this_1.messages.startOfServiceLaterThanServiceDate) < 0 &&
                                serviceDay.serviceDayDate < this_1.demographicsService.assessment.startOfServiceDate) {
                                errorMessages.push(this_1.messages.startOfServiceLaterThanServiceDate);
                            }
                        }
                        if (missingRequiredFields.indexOf(this_1.messages.protocolLabel) < 0 && serviceDay.protocol.value === 0) {
                            missingRequiredFields.push(this_1.messages.protocolLabel);
                        }
                    };
                    var this_1 = this;
                    for (var _i = 0, _a = this.serviceDaysToSave; _i < _a.length; _i++) {
                        var serviceDay = _a[_i];
                        var state_2 = _loop_2(serviceDay);
                        if (state_2 === "continue") continue;
                    }
                    if (this.clinicalGroup.value === 0) {
                        missingRequiredFields.push(this.messages.ocgLabel);
                    }
                    var requiredFieldsMessage = '';
                    if (missingRequiredFields.length > 0) {
                        requiredFieldsMessage = [
                            '<ul>',
                            '<li class="tk-padding-bottom-min">' + this.messages.requiredFieldsValidation + '</li>',
                            '<li class="tk-padding-left-1t"><span class="tk-padding-right-min">-</span>',
                            missingRequiredFields.join('</li><li class="tk-padding-left-1t"><span class="tk-padding-right-min">-</span>'),
                            '</li></ul>'
                        ].join('');
                    }
                    if (missingRequiredFields.length > 0 || errorMessages.length > 0) {
                        console.error(requiredFieldsMessage + '<ul><li class="tk-padding-top-min">' + errorMessages.join('</li><li class="tk-padding-top-min">') + '</li></ul>');
                        return false;
                    }
                    return true;
                };
                default_1.prototype.saveServiceDays = function (raisedOnRouteChange) {
                    var _this = this;
                    if (raisedOnRouteChange === void 0) { raisedOnRouteChange = false; }
                    var serviceDaysSaveModel = {
                        assessmentId: this.assessmentId,
                        serviceDays: this.serviceDaysToSave.map(function (sd) {
                            return {
                                clinicalGroupId: _this.clinicalGroup.value,
                                dayOfServiceId: sd.dayOfServiceId,
                                serviceDate: sd.serviceDate,
                                protocolId: sd.protocol.value,
                                ccd: sd.ccd,
                                isDayDelete: sd.isDayToBeDeleted,
                            };
                        })
                    };
                    return this.service.saveOcgServiceDays(serviceDaysSaveModel).then(function (response) {
                        if (response) {
                            if (raisedOnRouteChange) {
                                _this.service.getOcgServiceDays(_this.assessmentId);
                            }
                            else {
                                _this.loadOcgServiceDaysAfterSave();
                                _this.$scope[_this.formName].$setPristine();
                                console.log(_this.messages.saveSuccess);
                            }
                            if (_this.routeChanged) {
                                _this.routeChanged = false;
                                _this.event.raise(commonEvents.navigate);
                            }
                            _this.event.raise(commonEvents.summarySave);
                            _this.CheckTimelineNodeCompleteness();
                            return true;
                        }
                        console.error(_this.messages.saveFailure);
                        _this.routeChanged = false;
                        return false;
                    });
                };
                default_1.prototype.hasClinicalGroupChanged = function () {
                    return this.backupClinicalGroup.value !== 0 && this.backupClinicalGroup.value !== this.clinicalGroup.value;
                };
                default_1.prototype.hasProtocolChanged = function () {
                    this.datesWithProtocolChange = [];
                    for (var _i = 0, _a = this.serviceDaysToSave; _i < _a.length; _i++) {
                        var serviceDay = _a[_i];
                        if (!serviceDay.isDayToBeDeleted && serviceDay.savedProtocol.value !== 0 &&
                            serviceDay.savedProtocol.value !== serviceDay.protocol.value) {
                            this.datesWithProtocolChange.push(serviceDay.serviceDate);
                        }
                    }
                    return this.datesWithProtocolChange.length > 0;
                };
                default_1.prototype.onClinicalGroupChangeConfirmation = function (save) {
                    this.showClinicalGroupChangeConfirmationDialog = false;
                    if (save) {
                        this.saveServiceDays(this.routeChanged);
                    }
                    else {
                        this.routeChanged = false;
                    }
                };
                default_1.prototype.onProtocolChangeConfirmation = function (save) {
                    this.showProtocolChangeConfirmationDialog = false;
                    if (save) {
                        this.saveServiceDays(this.routeChanged);
                    }
                    else {
                        this.routeChanged = false;
                    }
                };
                default_1.prototype.validateAndSave = function (raisedOnRouteChange) {
                    if (raisedOnRouteChange === void 0) { raisedOnRouteChange = false; }
                    this.createModelToSave();
                    if (!this.validateServiceDates()) {
                        return this.$q.resolve(false);
                    }
                    if (this.hasClinicalGroupChanged()) {
                        this.routeChanged = raisedOnRouteChange;
                        this.showClinicalGroupChangeConfirmationDialog = true;
                        return this.$q.resolve(false);
                    }
                    if (this.hasProtocolChanged()) {
                        this.routeChanged = raisedOnRouteChange;
                        this.showProtocolChangeConfirmationDialog = true;
                        return this.$q.resolve(false);
                    }
                    return this.saveServiceDays(raisedOnRouteChange);
                };
                default_1.prototype.onCancel = function () {
                    if (this.$scope[this.formName].$dirty) {
                        this.showCancelConfirmationDialog = true;
                    }
                };
                default_1.prototype.onCancelConfirmation = function (cancel) {
                    this.showCancelConfirmationDialog = false;
                    if (cancel) {
                        this.loadOcgServiceDaysAfterCancel();
                        this.$scope[this.formName].$setPristine();
                        this.event.raise(ocgEvents.ocgOnPageResetOcgCompleteness);
                    }
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    this.event.subscribe(ocgEvents.ocgFieldsIsdirty, function () {
                        _this.service.setDirtyFlag(_this.$scope[_this.formName].$dirty);
                    });
                    this.event.subscribe(ocgEvents.ocgOnNavigationSave, function () {
                        return _this.validateAndSave(true);
                    });
                    this.event.subscribe(ocgEvents.ocgOnNavigationDiscard, function () {
                        _this.event.raise(ocgEvents.ocgOnPageResetOcgCompleteness);
                        return _this.$q.resolve(true);
                    });
                };
                default_1.prototype.unRegisterEvents = function () {
                    this.service.setDirtyFlag(false);
                    this.event.empty(ocgEvents.ocgFieldsIsdirty);
                    this.event.empty(ocgEvents.ocgOnNavigationDiscard);
                    this.event.empty(ocgEvents.ocgOnNavigationSave);
                };
                default_1.prototype.setupDirtyWatch = function () {
                    var _this = this;
                    this.$scope.$watch(function (s) { return _this.$scope[_this.formName].$dirty; }, function (isDirty) {
                        if (_this.$scope[_this.formName].$dirty) {
                            _this.event.raise(ocgEvents.ocgOnPageIncomplete);
                        }
                    }, false);
                };
                default_1.$inject = [ocg_service_1.default.serviceName, routeHelper_service_1.default.serviceName, event_service_1.default.serviceName, demographics_service_1.default.serviceName, '$filter', '$scope', '$q', '$timeout', ProtocolRules_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocg.controller.js.map