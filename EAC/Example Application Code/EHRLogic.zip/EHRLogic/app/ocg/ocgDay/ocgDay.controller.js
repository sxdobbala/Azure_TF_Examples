System.register(['../ocg.service', '../../ProtocolRules/ProtocolRules.service', '../ocg.event', '../../events/event.service', '../../events/common.events'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocg_service_1, ProtocolRules_service_1, ocg_event_1, event_service_1, commonEvents;
    var default_1;
    return {
        setters:[
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (ProtocolRules_service_1_1) {
                ProtocolRules_service_1 = ProtocolRules_service_1_1;
            },
            function (ocg_event_1_1) {
                ocg_event_1 = ocg_event_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (commonEvents_1) {
                commonEvents = commonEvents_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, $filter, $scope, protocolRulesService, $timeout, eventService) {
                    var _this = this;
                    this.service = service;
                    this.$filter = $filter;
                    this.$scope = $scope;
                    this.protocolRulesService = protocolRulesService;
                    this.$timeout = $timeout;
                    this.eventService = eventService;
                    this.messages = {};
                    this.protocolList = [];
                    this.viewModel = {
                        service: this,
                        records: [],
                        totalRecordsCount: 0,
                        columns: [
                            {
                                columnId: 'date',
                                style: "width: 250px; text-align: left;",
                                layoutOrder: 2,
                                sortable: false,
                                sortOrder: 1,
                                label: '<span>{{"ocg_day_date_label"|translate}}&nbsp;<span class="cux-icon-asterisk" style="font-weight:bold !important;"></span></span>',
                                cellTemplate: [
                                    '<div class="inline-calendar">',
                                    '<a id="delete_{{record.dayOfServiceId}}" class="tk-cursor-pointer tk-margin-right-halft" ng-click="model.onServiceDayDelete(record)"><span class="cux-icon-delete"></span></a>',
                                    '<uitk:calendar id="dayofservice_{{record.dayOfServiceId}}" name="calendar" ng-model="record.serviceDayDate" view-model="record.dateViewModel" on-change="model.service.setUpProtocolAndMessageForServiceDay(record);" class="tk-display-inline-block"/>',
                                    '</div>'].join('')
                            },
                            {
                                columnId: 'ccd', style: "width: 70px; text-align: center;",
                                layoutOrder: 3,
                                sortable: false,
                                label: [
                                    '<div>{{"ocg_day_ccd_label"|translate}}',
                                    '<span uitk-tooltip id="ccd-tooltip" class="tk-margin-left-halft tk-border-bottom-none" tooltip-placement="above">',
                                    '<span class="cux-icon-help tk-text-decoration-none" style="font-size:small !important;"></span>',
                                    '<uitk-tooltip-content>{{"ocg_ccd_tooltip"|translate}}</uitk-tooltip-content>',
                                    '</span></div>'].join(''),
                                cellTemplate: '<div style="text-align: center;"><input type="checkbox" ng-model="record.ccd" ng-click="model.service.handleCcdChange(record);"/></div>'
                            },
                            {
                                columnId: 'protocol',
                                layoutOrder: 4,
                                style: "width: 500px; text-align: left;",
                                sortable: false,
                                sortOrder: 0,
                                label: '<span>{{"ocg_day_protocol_label"|translate}}&nbsp;<span class="cux-icon-asterisk" style="font-weight:bold !important;"></span></span>',
                                cellTemplate: [
                                    '<div>',
                                    '<div class="tk-float-left tk-display-inline-block">',
                                    '<uitk:select ng-hide="record.ccd" id="protocol_{{record.dayOfServiceId}}" item-list="record.protocolList" selected-value="record.protocol" ng-change="model.service.handleProtocolChange(record);"></uitk:select>',
                                    '<span ng-show="record.ccd">{{record.protocol.label}}</span>',
                                    '</div>',
                                    '<div ng-show="record.message" class="tk-display-inline-block tk-padding-min tk-margin-left-halft oui-rfrm-has-error">{{record.message }}</div>',
                                    '</div>'].join('')
                            }
                        ],
                        onChange: function () {
                            var self = _this;
                            _this.sortOldestToNewest();
                            self.viewModel.records = self.data;
                            self.viewModel.totalRecordsCount = self.data.length;
                            for (var _i = 0, _a = self.data; _i < _a.length; _i++) {
                                var day = _a[_i];
                                self.loadProtocolList(day);
                            }
                        },
                        onServiceDayDelete: function (record) {
                            if (this.records.length > 1) {
                                this.records.splice(this.records.indexOf(record), 1);
                                this.service.$scope.$parent[this.service.formName].$setDirty();
                            }
                            else {
                                console.error(this.service.messages.dayDeleteValidation);
                            }
                        }
                    };
                    this.formName = this.service.formName;
                    this.setTranslation();
                    this.registerEvents();
                }
                default_1.prototype.sortOldestToNewest = function () {
                    var self = this;
                    self.data.sort(function (a, b) {
                        return b.serviceDayDate > a.serviceDayDate ? -1 : 1;
                    });
                };
                default_1.prototype.$onDestroy = function () {
                    this.unregisterEvents();
                };
                default_1.prototype.setTranslation = function () {
                    this.messages.dateFormat = this.$filter('translate')('date_format');
                    this.messages.dayDeleteValidation = this.$filter('translate')('ocg_day_delete_validation');
                };
                default_1.prototype.setProtocol = function (day) {
                    angular.copy(this.protocolList, day.protocolList);
                    if (day.protocol && !day.ccd) {
                        var matchingprotocols = day.protocolList.filter(function (protocol) { return protocol.value === day.protocol.value; });
                        day.protocol = matchingprotocols && matchingprotocols.length > 0 ? matchingprotocols[0] : day.protocol;
                    }
                    this.setUpProtocolAndMessageForServiceDay(day);
                };
                default_1.prototype.loadProtocolList = function (day) {
                    var _this = this;
                    if (this.protocolList.length == 0) {
                        this.service.getProtocolList(this.assessmentId).then(function (response) {
                            if (response) {
                                angular.copy(_this.service.protocolList, _this.protocolList);
                                _this.setProtocol(day);
                            }
                        });
                    }
                    else {
                        this.setProtocol(day);
                    }
                };
                default_1.prototype.showMultiCalender = function () {
                    this.showMultiCalenderControl = true;
                };
                default_1.prototype.cancelAddServiceDays = function () {
                    this.showMultiCalenderControl = false;
                };
                default_1.prototype.addServiceDays = function (serviceDays) {
                    for (var _i = 0, serviceDays_1 = serviceDays; _i < serviceDays_1.length; _i++) {
                        var dateNumber = serviceDays_1[_i];
                        var newDate = new Date(dateNumber);
                        newDate.setHours(0, 0, 0, 0);
                        var serviceday = {};
                        serviceday.dayOfServiceId = 0;
                        serviceday.ccd = false;
                        serviceday.serviceDayDate = newDate;
                        serviceday.dateViewModel = this.getDateViewModel();
                        serviceday.protocol = { label: '', value: 0 };
                        serviceday.savedProtocol = { label: '', value: 0 };
                        if (this.protocolList.length > 0) {
                            serviceday.protocolList = Array();
                            angular.copy(this.protocolList, serviceday.protocolList);
                        }
                        else {
                            serviceday.protocolList = [{ value: 0, label: '' }];
                        }
                        this.setUpProtocolAndMessageForServiceDay(serviceday);
                        this.viewModel.records.push(serviceday);
                    }
                    this.data = this.viewModel.records;
                    this.viewModel.totalRecordsCount = this.viewModel.records.length;
                    this.showMultiCalenderControl = false;
                };
                default_1.prototype.getDateViewModel = function () {
                    return {
                        maxYear: new Date().getFullYear(),
                        renderHintText: false,
                        iconCalendar: true
                    };
                };
                default_1.prototype.setUpProtocolAndMessageForServiceDay = function (serviceDay) {
                    var _this = this;
                    this.protocolRulesService.getDefaultProtocol(serviceDay.serviceDayDate, serviceDay.ccd)
                        .then(function (response) {
                        if (response) {
                            serviceDay.message = response.message;
                            if (response.defaultProtocol != null) {
                                if (serviceDay.ccd) {
                                    //when ccd indicator is set to true
                                    serviceDay.protocol = { value: response.defaultProtocol.value, label: response.defaultProtocol.label };
                                }
                                else if (serviceDay.dayOfServiceId === 0 || !serviceDay.protocol || serviceDay.protocol.value === 0) {
                                    //new Date or when protocol is empty
                                    var defaultProtocol = serviceDay.protocolList.filter(function (protocol) { return protocol.value === response.defaultProtocol.value; });
                                    if (defaultProtocol !== null && defaultProtocol.length > 0) {
                                        serviceDay.protocol = defaultProtocol[0];
                                    }
                                }
                                else if (response.defaultProtocol.value !== serviceDay.protocol.value) {
                                    serviceDay.message = _this.protocolRulesService.messages.recommendedProtocolMessage.replace('{0}', response.defaultProtocol.label);
                                }
                            }
                        }
                    });
                };
                default_1.prototype.handleCcdChange = function (serviceDay) {
                    if (!serviceDay.ccd) {
                        serviceDay.protocol = null;
                    }
                    this.setUpProtocolAndMessageForServiceDay(serviceDay);
                };
                default_1.prototype.handleProtocolChange = function (serviceDay) {
                    var _this = this;
                    //if this is a new Date make sure we do not override the TemplateType just selected
                    if (serviceDay.dayOfServiceId !== 0) {
                        this.$timeout(function () { return _this.setUpProtocolAndMessageForServiceDay(serviceDay); });
                    }
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    this.eventService.subscribe(ocg_event_1.ocgSetupDefaultProtocol, function () {
                        for (var _i = 0, _a = _this.data; _i < _a.length; _i++) {
                            var day = _a[_i];
                            _this.setUpProtocolAndMessageForServiceDay(day);
                        }
                    });
                    this.eventService.subscribe(commonEvents.summarySave, function () {
                        _this.viewModel.onChange();
                    });
                };
                default_1.prototype.unregisterEvents = function () {
                    this.eventService.empty(ocg_event_1.ocgSetupDefaultProtocol);
                };
                default_1.$inject = [ocg_service_1.default.serviceName, '$filter', '$scope', ProtocolRules_service_1.default.serviceName, '$timeout', event_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=ocgDay.controller.js.map