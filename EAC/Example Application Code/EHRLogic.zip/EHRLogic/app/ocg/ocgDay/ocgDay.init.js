System.register(['./ocgDay.component', 'multidatepicker'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgDay_component_1;
    return {
        setters:[
            function (ocgDay_component_1_1) {
                ocgDay_component_1 = ocgDay_component_1_1;
            },
            function (_1) {}],
        execute: function() {
            angular
                .module('compass.ocgDay', ['compass.multidatepicker'])
                .component(ocgDay_component_1.default.componentName, new ocgDay_component_1.default());
        }
    }
});
//# sourceMappingURL=ocgDay.init.js.map