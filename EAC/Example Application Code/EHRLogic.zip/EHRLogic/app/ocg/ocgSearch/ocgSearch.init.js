System.register(['./ocgSearch.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgSearch_component_1;
    return {
        setters:[
            function (ocgSearch_component_1_1) {
                ocgSearch_component_1 = ocgSearch_component_1_1;
            }],
        execute: function() {
            angular
                .module('compass.ocgSearch', [])
                .component(ocgSearch_component_1.default.componentName, new ocgSearch_component_1.default());
        }
    }
});
//# sourceMappingURL=ocgSearch.init.js.map