System.register(['./ocgSearch.controller'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ocgSearch_controller_1;
    var OcgSearchComponent;
    return {
        setters:[
            function (ocgSearch_controller_1_1) {
                ocgSearch_controller_1 = ocgSearch_controller_1_1;
            }],
        execute: function() {
            OcgSearchComponent = (function () {
                function OcgSearchComponent() {
                    this.templateUrl = 'app/ocg/ocgSearch/ocgSearch.html';
                    this.controller = ocgSearch_controller_1.default;
                    this.bindings = {
                        /* Two-way Binding */
                        ocg: '=',
                        /*One-way Binding*/
                        filteredOcgListByKeywords: '<',
                    };
                }
                OcgSearchComponent.componentName = 'ocgSearch';
                return OcgSearchComponent;
            }());
            exports_1("default", OcgSearchComponent);
        }
    }
});
//# sourceMappingURL=ocgSearch.component.js.map