System.register(['../commonServices/ajaxErrorService.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ajaxErrorService_service_1;
    var default_1;
    return {
        setters:[
            function (ajaxErrorService_service_1_1) {
                ajaxErrorService_service_1 = ajaxErrorService_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1($http, appConfig, ajaxErrorService) {
                    this.$http = $http;
                    this.appConfig = appConfig;
                    this.ajaxErrorService = ajaxErrorService;
                    this.riskFactorList = new Array();
                    this.riskFactorListToSave = new Array();
                }
                default_1.prototype.getRiskFactorList = function (dayOfServiceId) {
                    var _this = this;
                    var self = this;
                    var params = { dayOfServiceId: dayOfServiceId };
                    return this.$http.get(this.appConfig.urls.riskFactors, { params: params }).then(function (response) {
                        if (response.data) {
                            angular.copy(response.data, self.riskFactorList);
                            return true;
                        }
                        self.riskFactorList = [];
                        return false;
                    }, function (error) {
                        return _this.ajaxErrorService.ShowCommonAjaxError(error.data);
                    });
                };
                default_1.prototype.saveRiskFactor = function (data) {
                    var that = this;
                    return that.$http.post(this.appConfig.urls.riskFactors, data).then(function (response) {
                        return true;
                    }, function (error) {
                        return false;
                    });
                };
                default_1.serviceName = 'serviceDayRiskFactorsService';
                default_1.$inject = ['$http', 'appConfig', ajaxErrorService_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=serviceDayRiskFactors.service.js.map