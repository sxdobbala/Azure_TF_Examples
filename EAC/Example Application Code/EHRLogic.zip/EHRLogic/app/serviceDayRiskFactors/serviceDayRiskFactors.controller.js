System.register(['./serviceDayRiskFactors.service', '../riskfactor/riskFactor.service', '../ocg/ocg.service', '../events/event.service', '../riskfactor/riskfactor.event', '../events/common.events', '../recommendation/recommendation.event'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var serviceDayRiskFactors_service_1, riskFactor_service_1, ocg_service_1, event_service_1, riskFactorEvents, commonEvents, recommendation_event_1;
    var default_1;
    return {
        setters:[
            function (serviceDayRiskFactors_service_1_1) {
                serviceDayRiskFactors_service_1 = serviceDayRiskFactors_service_1_1;
            },
            function (riskFactor_service_1_1) {
                riskFactor_service_1 = riskFactor_service_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (riskFactorEvents_1) {
                riskFactorEvents = riskFactorEvents_1;
            },
            function (commonEvents_1) {
                commonEvents = commonEvents_1;
            },
            function (recommendation_event_1_1) {
                recommendation_event_1 = recommendation_event_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, $scope, ocgService, $filter, $timeout, eventService, $q, riskfactorService) {
                    this.service = service;
                    this.$scope = $scope;
                    this.ocgService = ocgService;
                    this.$filter = $filter;
                    this.$timeout = $timeout;
                    this.eventService = eventService;
                    this.$q = $q;
                    this.riskfactorService = riskfactorService;
                    this.riskFactorList = new Array();
                    this.showDiscardChangesConfirmation = false;
                    this.daysOfServiceToCopyFrom = [];
                    this.messages = {};
                    this.setTranslation();
                    this.registerEvents();
                    this.formName = this.riskfactorService.formName;
                }
                default_1.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                default_1.prototype.setTranslation = function () {
                    this.messages.saveRiskFactorFailure = this.$filter('translate')('risk_factor_save_failure');
                    this.messages.saveRiskFactorSuccess = this.$filter('translate')('risk_factor_save_success');
                };
                default_1.prototype.$onChanges = function () {
                    this.setFormPristine();
                    this.riskfactorService.setDirtyFlag(false);
                    this.initialize();
                };
                default_1.prototype.initialize = function () {
                    if (this.dayOfServiceId && this.dayOfServiceId > 0) {
                        this.service.previousDayOfServiceId = this.service.currentdayOfServiceId;
                        this.service.currentdayOfServiceId = this.dayOfServiceId;
                        this.getRiskFactorList(this.dayOfServiceId);
                        this.setupServiceDaysList();
                    }
                };
                default_1.prototype.getRiskFactorList = function (dayOfServiceId) {
                    var _this = this;
                    this.service.getRiskFactorList(dayOfServiceId).then(function (response) {
                        if (response) {
                            _this.riskFactorList = _this.service.riskFactorList;
                            _this.setRiskFactorList();
                        }
                        else {
                            _this.riskFactorList = [];
                        }
                    });
                };
                default_1.prototype.setRiskFactorList = function () {
                    for (var _i = 0, _a = this.riskFactorList; _i < _a.length; _i++) {
                        var riskFactorType = _a[_i];
                        for (var _b = 0, _c = riskFactorType.riskFactors; _b < _c.length; _b++) {
                            var riskFactor = _c[_b];
                            this.handleParentRiskFactorSelection(riskFactor);
                        }
                    }
                };
                default_1.prototype.setupServiceDaysList = function () {
                    this.daysOfServiceToCopyFrom = [];
                    var serviceDate = '';
                    if (this.ocgService.ocgServiceDays.length > 1) {
                        this.dayOfServiceToCopyFrom = { value: 0, label: 'Select Date' };
                        this.daysOfServiceToCopyFrom.push(this.dayOfServiceToCopyFrom);
                        for (var _i = 0, _a = this.ocgService.ocgServiceDays; _i < _a.length; _i++) {
                            var dayOfService = _a[_i];
                            serviceDate = this.$filter('date')(new Date(dayOfService.serviceDate), this.$filter('translate')('date_format'));
                            if (this.dayOfServiceId !== dayOfService.dayOfServiceId && this.protocol.value === dayOfService.protocol.value)
                                this.daysOfServiceToCopyFrom.push({ value: dayOfService.dayOfServiceId, label: serviceDate });
                        }
                    }
                };
                default_1.prototype.onCancel = function () {
                    if (this.$scope[this.formName].$dirty) {
                        this.showDiscardChangesConfirmation = true;
                    }
                };
                default_1.prototype.onDiscardChangesConfirmation = function (discard) {
                    this.showDiscardChangesConfirmation = false;
                    if (discard) {
                        this.setFormPristine();
                        this.getRiskFactorList(this.dayOfServiceId);
                        this.dayOfServiceToCopyFrom = this.daysOfServiceToCopyFrom.filter(function (day) { return day.value === 0; })[0];
                        this.resetRiskFactorCompleteness();
                    }
                };
                default_1.prototype.onCopyFromDateChange = function () {
                    var _this = this;
                    this.$timeout(function () { return _this.copyFromSelectedDayOfService(); });
                };
                default_1.prototype.copyFromSelectedDayOfService = function () {
                    var that = this;
                    if (that.dayOfServiceToCopyFrom.value !== 0) {
                        this.getRiskFactorList(that.dayOfServiceToCopyFrom.value);
                        this.setFormDirty();
                    }
                };
                default_1.prototype.subElementOnCheck = function (riskFactor, subRiskFactor) {
                    this.setFormDirty();
                    this.handleParentRiskFactorSelection(riskFactor);
                    this.handleRiskFactorCustomText(subRiskFactor);
                };
                default_1.prototype.handleParentRiskFactorSelection = function (riskFactor) {
                    if (riskFactor.subRiskFactors && riskFactor.subRiskFactors.length > 0) {
                        var selectedSubElementCount = 0;
                        for (var _i = 0, _a = riskFactor.subRiskFactors; _i < _a.length; _i++) {
                            var subElement = _a[_i];
                            if (subElement.isRiskFactorSelected)
                                selectedSubElementCount++;
                        }
                        var isSelected = (selectedSubElementCount > 0 && selectedSubElementCount >= riskFactor.parentRiskFactor.minNumOfSubElements);
                        riskFactor.parentRiskFactor.isRiskFactorSelected = isSelected;
                        riskFactor.parentRiskFactor.isRiskFactorDisabled = !isSelected;
                    }
                    else {
                        riskFactor.parentRiskFactor.isRiskFactorDisabled = false;
                    }
                };
                default_1.prototype.riskFactorOnCheck = function (riskFactor) {
                    this.setFormDirty();
                    if (!riskFactor.parentRiskFactor.isRiskFactorSelected) {
                        for (var _i = 0, _a = riskFactor.subRiskFactors; _i < _a.length; _i++) {
                            var subElement = _a[_i];
                            subElement.isRiskFactorSelected = false;
                            this.handleRiskFactorCustomText(subElement);
                        }
                    }
                    this.handleParentRiskFactorSelection(riskFactor);
                };
                default_1.prototype.handleRiskFactorCustomText = function (subRiskFactor) {
                    if (subRiskFactor.isCustomTextRequired && !subRiskFactor.isRiskFactorSelected) {
                        subRiskFactor.riskFactorCustomText = null;
                    }
                };
                default_1.prototype.saveRiskFactor = function (dayOfServiceId, riskFactorList, raisedOnRouteChange) {
                    var _this = this;
                    if (raisedOnRouteChange === void 0) { raisedOnRouteChange = false; }
                    var selectedRiskFactorsList = new Array();
                    for (var _i = 0, riskFactorList_1 = riskFactorList; _i < riskFactorList_1.length; _i++) {
                        var riskFactorModel = riskFactorList_1[_i];
                        for (var _a = 0, _b = riskFactorModel.riskFactors; _a < _b.length; _a++) {
                            var riskFactorType = _b[_a];
                            if (riskFactorType.parentRiskFactor.isRiskFactorSelected)
                                selectedRiskFactorsList.push({
                                    riskFactorId: riskFactorType.parentRiskFactor.riskFactor.value
                                });
                            for (var _c = 0, _d = riskFactorType.subRiskFactors; _c < _d.length; _c++) {
                                var subRiskFactor = _d[_c];
                                if (subRiskFactor.isRiskFactorSelected)
                                    selectedRiskFactorsList.push({
                                        riskFactorId: subRiskFactor.riskFactor.value,
                                        riskFactorCustomText: subRiskFactor.riskFactorCustomText
                                    });
                            }
                        }
                    }
                    var data = {
                        serviceDayId: dayOfServiceId,
                        riskFactorDetails: selectedRiskFactorsList
                    };
                    return this.service.saveRiskFactor(data).then(function (response) {
                        if (response) {
                            if (!raisedOnRouteChange) {
                                _this.setFormPristine();
                                console.log(_this.messages.saveRiskFactorSuccess);
                            }
                            _this.eventService.raise(commonEvents.summarySave);
                            _this.eventService.raise(riskFactorEvents.riskFactorOnPageCheckRiskFactorCompleteness);
                            _this.eventService.raise(recommendation_event_1.recommendationOnPageCheckCompleteness);
                            return true;
                        }
                        else {
                            console.error(_this.messages.saveRiskFactorFailure);
                            return false;
                        }
                    });
                };
                default_1.prototype.setFormDirty = function () {
                    if (this.$scope[this.formName]) {
                        this.$scope[this.formName].$setDirty();
                    }
                    this.setriskFactorPageIncomplete();
                };
                default_1.prototype.setFormPristine = function () {
                    if (this.$scope[this.formName]) {
                        this.$scope[this.formName].$setPristine();
                    }
                };
                default_1.prototype.resetRiskFactorCompleteness = function () {
                    this.eventService.raise(riskFactorEvents.riskFactorOnPageResetRiskFactorCompleteness);
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    this.eventService.subscribe(riskFactorEvents.riskFactorPageIsdirty, function () {
                        _this.riskfactorService.setDirtyFlag(_this.$scope[_this.formName].$dirty);
                    });
                    this.eventService.subscribe(riskFactorEvents.riskFactorOnNavigationSave, function () {
                        return _this.saveRiskFactor(_this.dayOfServiceId, _this.riskFactorList, true);
                    });
                    this.eventService.subscribe(riskFactorEvents.riskFactorOnNavigationDiscard, function () {
                        return _this.$q.resolve(true);
                    });
                    this.eventService.subscribe(riskFactorEvents.riskFactorOnDateTabChangeSave, function () {
                        return _this.saveRiskFactor(_this.service.previousDayOfServiceId, _this.service.riskFactorListToSave, true);
                    });
                };
                default_1.prototype.unRegisterEvents = function () {
                    this.riskfactorService.setDirtyFlag(false);
                    this.eventService.empty(riskFactorEvents.riskFactorPageIsdirty);
                    this.eventService.empty(riskFactorEvents.riskFactorOnNavigationSave);
                    this.eventService.empty(riskFactorEvents.riskFactorOnNavigationDiscard);
                    this.eventService.empty(riskFactorEvents.riskFactorOnDateTabChangeSave);
                };
                default_1.prototype.setriskFactorPageIncomplete = function () {
                    this.eventService.raise(riskFactorEvents.riskFactorOnPageIncomplete);
                };
                default_1.$inject = [serviceDayRiskFactors_service_1.default.serviceName, '$scope', ocg_service_1.default.serviceName, '$filter', '$timeout', event_service_1.default.serviceName, '$q', riskFactor_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=serviceDayRiskFactors.controller.js.map