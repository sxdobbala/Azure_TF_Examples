System.register(['./assessmentContainer.service', '../timeline/timeline.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentContainer_service_1, timeline_service_1;
    var default_1;
    return {
        setters:[
            function (assessmentContainer_service_1_1) {
                assessmentContainer_service_1 = assessmentContainer_service_1_1;
            },
            function (timeline_service_1_1) {
                timeline_service_1 = timeline_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, timelineService) {
                    this.service = service;
                    this.timelineService = timelineService;
                }
                default_1.prototype.$routerOnActivate = function (routeData) {
                    this.assessmentId = routeData.params['id'] || 0;
                    this.timelineService.assessmentId = this.assessmentId;
                };
                /* END - 1 way bindings for Child components*/
                default_1.$inject = [assessmentContainer_service_1.default.serviceName, timeline_service_1.TimelineService.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentContainer.controller.js.map