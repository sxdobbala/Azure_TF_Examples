System.register(["./assessmentContainer.controller", "../timeline/timeline.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentContainer_controller_1, timeline_component_1;
    var default_1;
    return {
        setters:[
            function (assessmentContainer_controller_1_1) {
                assessmentContainer_controller_1 = assessmentContainer_controller_1_1;
            },
            function (timeline_component_1_1) {
                timeline_component_1 = timeline_component_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1() {
                    this.templateUrl = 'app/assessmentContainer/assessmentContainer.html';
                    this.controller = assessmentContainer_controller_1.default;
                    this.$routeConfig = [
                        { path: '/...', name: '', component: timeline_component_1.default.componentName, useAsDefault: true }
                    ];
                }
                default_1.componentName = 'assessmentContainer';
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentContainer.component.js.map