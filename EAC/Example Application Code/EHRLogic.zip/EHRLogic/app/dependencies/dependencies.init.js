System.register(['ng-csv'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    return {
        setters:[
            function (_1) {}],
        execute: function() {
            angular
                .module('compass.navigation', []);
            angular
                .module('compass.uitk', [
                'uitk.component.header',
                'uitk.component.uitkTooltip',
                'uitk.component.uitkLabel',
                'uitk.component.uitkTextField',
                'uitk.component.uitkTextarea',
                'uitk.component.uitkRadioGroup',
                'uitk.component.uitkFooter',
                'uitk.component.uitkGlobalNavigation',
                'uitk.component.uitkPrimaryNavigation',
                'uitk.component.uitkMessage',
                'uitk.component.uitkSelect',
                'uitk.component.uitkPanel',
                'uitk.component.uitkDialog',
                'uitk.component.uitkButton',
                'uitk.component.tabs',
                'uitk.component.uitkDynamicTable',
                'uitk.component.uitkCalendar',
                'uitk.component.uitkCheckboxGroup',
                'uitk.component.uitkAccordion'
            ]);
        }
    }
});
//# sourceMappingURL=dependencies.init.js.map