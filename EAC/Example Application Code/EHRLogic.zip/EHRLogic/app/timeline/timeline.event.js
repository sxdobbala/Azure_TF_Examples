System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var isPageDirty, checkIfAssessmentIncompleteInCaseUserEnteredManually;
    return {
        setters:[],
        execute: function() {
            exports_1("isPageDirty", isPageDirty = 'IS_PAGE_DIRTY');
            exports_1("checkIfAssessmentIncompleteInCaseUserEnteredManually", checkIfAssessmentIncompleteInCaseUserEnteredManually = 'timeline.check.assessment.incomplete');
        }
    }
});
//# sourceMappingURL=timeline.event.js.map