System.register(['./timeline.constant', './timeline.service', '../events/event.service', '../ocg/ocg.service', '../riskfactor/riskfactor.service', '../recommendation/recommendation.service', "../ocg/ocg.event", "../riskfactor/riskfactor.event", "./timeline.event", '../recommendation/recommendation.event', '../completeAssessment/completeAssessment.event', '../events/common.events'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var TimelineConstant, timeline_service_1, event_service_1, ocg_service_1, riskfactor_service_1, recommendation_service_1, ocgEvents, riskFactorEvents, timelineEvents, recommendationEvents, completeAssessment_event_1, common_events_1;
    var default_1;
    return {
        setters:[
            function (TimelineConstant_1) {
                TimelineConstant = TimelineConstant_1;
            },
            function (timeline_service_1_1) {
                timeline_service_1 = timeline_service_1_1;
            },
            function (event_service_1_1) {
                event_service_1 = event_service_1_1;
            },
            function (ocg_service_1_1) {
                ocg_service_1 = ocg_service_1_1;
            },
            function (riskfactor_service_1_1) {
                riskfactor_service_1 = riskfactor_service_1_1;
            },
            function (recommendation_service_1_1) {
                recommendation_service_1 = recommendation_service_1_1;
            },
            function (ocgEvents_1) {
                ocgEvents = ocgEvents_1;
            },
            function (riskFactorEvents_1) {
                riskFactorEvents = riskFactorEvents_1;
            },
            function (timelineEvents_1) {
                timelineEvents = timelineEvents_1;
            },
            function (recommendationEvents_1) {
                recommendationEvents = recommendationEvents_1;
            },
            function (completeAssessment_event_1_1) {
                completeAssessment_event_1 = completeAssessment_event_1_1;
            },
            function (common_events_1_1) {
                common_events_1 = common_events_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, event, ocgService, riskFactorService, recommendationService, $q) {
                    this.service = service;
                    this.event = event;
                    this.ocgService = ocgService;
                    this.riskFactorService = riskFactorService;
                    this.recommendationService = recommendationService;
                    this.$q = $q;
                    this.showDialog = false;
                    this.eventListeners = [];
                    this.status = this.service.status;
                    this.pages = this.service.pages;
                    this.setTimelineStartPage();
                    this.registerEvents();
                }
                default_1.prototype.$onChanges = function () {
                };
                default_1.prototype.$onDestroy = function () {
                    this.unRegisterEvents();
                };
                default_1.prototype.$postLink = function () {
                    this.checkTimelineCompleteness();
                };
                default_1.prototype.checkTimelineCompleteness = function () {
                    this.service.checkForOcgCompleteness();
                    this.service.checkForRecommendationCompleteness();
                    this.service.checkForRiskFactorsCompleteness();
                    this.updateIsAssessmentComplete(null, true);
                };
                default_1.prototype.updateIsAssessmentComplete = function (alreadyIsComplete, shouldCheckServer) {
                    var _this = this;
                    if (shouldCheckServer) {
                        this.service.checkForAssessmentCompleteness().then(function (isComplete) {
                            _this.updateCompleteAssessmentNodeDisabled(isComplete);
                        });
                    }
                    else {
                        this.updateCompleteAssessmentNodeDisabled(alreadyIsComplete);
                    }
                };
                default_1.prototype.updateCompleteAssessmentNodeDisabled = function (isComplete) {
                    if (this.pages[TimelineConstant.ocgPageIndex].status != this.service.status.Filled ||
                        this.pages[TimelineConstant.riskFactorPageIndex].status != this.service.status.Filled ||
                        this.pages[TimelineConstant.recommendationPageIndex].status != this.service.status.Filled) {
                        this.pages[TimelineConstant.completeAssessmentPageIndex].status = this.service.status.Disabled;
                    }
                    else {
                        this.navigationItem.disableNextButton = false;
                        if (isComplete) {
                            this.pages[TimelineConstant.completeAssessmentPageIndex].status = this.service.status.Filled;
                        }
                        else {
                            this.pages[TimelineConstant.completeAssessmentPageIndex].status = this.service.status.Empty;
                        }
                    }
                };
                default_1.prototype.isLinkClickable = function (page) {
                    return this.currentPageName !== page.name && page.status !== this.status.Disabled;
                };
                default_1.prototype.onNavigate = function (page) {
                    if (page && page.url) {
                        if (page.status === this.status.Disabled) {
                            return;
                        }
                        var isPageDirty = this.isPageDirty();
                        this.showDialog = isPageDirty;
                        if (isPageDirty) {
                            this.destinationPage = page;
                        }
                        else {
                            this.navigate(page);
                        }
                    }
                    else {
                        console.error('timeline controller: link does not exist in links array', page);
                    }
                };
                default_1.prototype.navigate = function (page) {
                    this.setCurrentPageName(page);
                    this.setPrevNextButtons(page);
                    this.service.setDirtyFlag(false);
                    this.service.navigate(page.url, this.service.assessmentId);
                };
                default_1.prototype.setCurrentPageName = function (page) {
                    this.currentPageName = page.name;
                    this.currentPage = page;
                };
                default_1.prototype.isPageDirty = function () {
                    var isPageDirty = false;
                    switch (this.currentPageName) {
                        case this.service.ocgPage.name:
                            this.event.raise(ocgEvents.ocgFieldsIsdirty);
                            isPageDirty = this.ocgService.isPageDirty();
                            break;
                        case this.service.riskFactorPage.name:
                            this.event.raise(riskFactorEvents.riskFactorPageIsdirty);
                            isPageDirty = this.riskFactorService.isPageDirty();
                            break;
                        case this.service.recommendationPage.name:
                            isPageDirty = this.recommendationService.isPageDirty();
                            break;
                    }
                    return isPageDirty;
                };
                default_1.prototype.saveChange = function (save) {
                    var _this = this;
                    this.showDialog = false;
                    var eventName = '';
                    switch (this.currentPageName) {
                        case this.service.ocgPage.name:
                            eventName = save ? ocgEvents.ocgOnNavigationSave : ocgEvents.ocgOnNavigationDiscard;
                            break;
                        case this.service.riskFactorPage.name:
                            eventName = save ? riskFactorEvents.riskFactorOnNavigationSave : riskFactorEvents.riskFactorOnNavigationDiscard;
                            break;
                        case this.service.recommendationPage.name:
                            eventName = save ? recommendationEvents.recommendationOnNavigationSave : recommendationEvents.recommendationOnNavigationDiscard;
                            break;
                    }
                    if (eventName !== '') {
                        this.event.raise(eventName).then(function (response) {
                            if (response && response[0])
                                _this.navigate(_this.destinationPage);
                        });
                    }
                };
                default_1.prototype.registerEvents = function () {
                    var _this = this;
                    this.eventListeners = [
                        this.event.subscribe(ocgEvents.ocgOnPageError, function (data) {
                            _this.pages[TimelineConstant.ocgPageIndex].status = _this.service.status.Error;
                            _this.updateCompleteAssessmentNodeDisabled(false);
                        }),
                        this.event.subscribe(ocgEvents.ocgOnPageCheckOcgCompleteness, function (data) {
                            _this.service.checkForOcgCompleteness();
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(ocgEvents.ocgOnPageComplete, function (data) {
                            _this.pages[TimelineConstant.ocgPageIndex].status = _this.service.status.Filled;
                            _this.updateIsAssessmentComplete(null, true);
                            return _this.$q.resolve(_this.service.status.Filled);
                        }),
                        this.event.subscribe(ocgEvents.ocgOnPageIncomplete, function (data) {
                            _this.pages[TimelineConstant.ocgPageIndex].status = _this.service.status.Empty;
                            _this.updateIsAssessmentComplete(false, false);
                            return _this.$q.resolve(_this.service.status.Empty);
                        }),
                        this.event.subscribe(ocgEvents.ocgOnPageResetOcgCompleteness, function (data) {
                            _this.pages[TimelineConstant.ocgPageIndex].status = _this.service.savedOcgCompletenessStatus;
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(riskFactorEvents.riskFactorOnPageCheckRiskFactorCompleteness, function (data) {
                            _this.service.checkForRiskFactorsCompleteness();
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(riskFactorEvents.riskFactorOnPageError, function (data) {
                            _this.pages[TimelineConstant.riskFactorPageIndex].status = _this.service.status.Error;
                            _this.updateIsAssessmentComplete(false, false);
                        }),
                        this.event.subscribe(riskFactorEvents.riskFactorOnPageComplete, function (data) {
                            _this.pages[TimelineConstant.riskFactorPageIndex].status = _this.service.status.Filled;
                            _this.updateIsAssessmentComplete(null, true);
                            return _this.$q.resolve(_this.service.status.Filled);
                        }),
                        this.event.subscribe(riskFactorEvents.riskFactorOnPageIncomplete, function (data) {
                            _this.pages[TimelineConstant.riskFactorPageIndex].status = _this.service.status.Empty;
                            _this.updateIsAssessmentComplete(false, false);
                            return _this.$q.resolve(_this.service.status.Empty);
                        }),
                        this.event.subscribe(riskFactorEvents.riskFactorOnPageResetRiskFactorCompleteness, function (data) {
                            _this.pages[TimelineConstant.riskFactorPageIndex].status = _this.service.savedRiskFactorCompletenessStatus;
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(recommendationEvents.recommendationOnPageError, function (data) {
                            _this.pages[TimelineConstant.recommendationPageIndex].status = _this.service.status.Error;
                            _this.updateIsAssessmentComplete(false, false);
                        }),
                        this.event.subscribe(recommendationEvents.recommendationOnPageCheckCompleteness, function (data) {
                            _this.service.checkForRecommendationCompleteness();
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(recommendationEvents.recommendationOnPageResetRecommendationCompleteness, function (data) {
                            var self = _this;
                            self.pages[TimelineConstant.recommendationPageIndex].status = self.service.savedRecommendationCompletenessStatus;
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(recommendationEvents.recommendationOnPageComplete, function (data) {
                            var self = _this;
                            self.pages[TimelineConstant.recommendationPageIndex].status = _this.service.status.Filled;
                            var res = self.$q.resolve(_this.service.status.Filled);
                            _this.updateIsAssessmentComplete(null, true);
                            return res;
                        }),
                        this.event.subscribe(recommendationEvents.recommendationOnPageIncomplete, function (data) {
                            var self = _this;
                            self.pages[TimelineConstant.recommendationPageIndex].status = _this.service.status.Empty;
                            var res = self.$q.resolve(_this.service.status.Empty);
                            _this.updateIsAssessmentComplete(false, false);
                            return res;
                        }),
                        this.event.subscribe(completeAssessment_event_1.completeAssessmentOnPageError, function (data) {
                            _this.pages[TimelineConstant.completeAssessmentPageIndex].status = _this.service.status.Error;
                            _this.updateIsAssessmentComplete(false, false);
                        }),
                        this.event.subscribe(completeAssessment_event_1.completeAssessmentOnPageComplete, function (data) {
                            _this.pages[TimelineConstant.completeAssessmentPageIndex].status = _this.service.status.Filled;
                            _this.updateIsAssessmentComplete(true, false);
                        }),
                        this.event.subscribe(common_events_1.navigate, function (data) {
                            if (_this.destinationPage && _this.currentPageName !== _this.destinationPage.name)
                                _this.navigate(_this.destinationPage);
                            _this.updateIsAssessmentComplete(null, true);
                        }),
                        this.event.subscribe(timelineEvents.isPageDirty, function () {
                            _this.service.setDirtyFlag(_this.isPageDirty());
                            _this.updateIsAssessmentComplete(null, true);
                            return _this.$q.resolve(_this.currentPage);
                        }),
                        this.event.subscribe(timelineEvents.checkIfAssessmentIncompleteInCaseUserEnteredManually, function (data) {
                            _this.checkIfAssessmentIncompleteInCaseUserEnteredManually();
                        })
                    ];
                };
                default_1.prototype.checkIfAssessmentIncompleteInCaseUserEnteredManually = function () {
                    if (this.pages[TimelineConstant.completeAssessmentPageIndex].status === this.service.status.Disabled) {
                        this.navigate(this.pages[TimelineConstant.ocgPageIndex]);
                    }
                };
                default_1.prototype.unRegisterEvents = function () {
                    for (var _i = 0, _a = this.eventListeners; _i < _a.length; _i++) {
                        var listener = _a[_i];
                        this.event.unsubscribe(listener.actionName, listener.id);
                    }
                    this.event.empty(common_events_1.RefreshLetterList);
                };
                default_1.prototype.setPrevNextButtons = function (page) {
                    this.navigationItem.showPrevButton = true;
                    this.navigationItem.showNextButton = true;
                    this.navigationItem.disableNextButton = false;
                    switch (page.url) {
                        case this.service.urls.Ocg:
                            this.navigationItem.showPrevButton = false;
                            this.navigationItem.prevButtonLinkUrl = this.service.ocgPage;
                            this.navigationItem.nextButtonLinkUrl = this.service.riskFactorPage;
                            break;
                        case this.service.urls.RiskFactor:
                            this.navigationItem.prevButtonLinkUrl = this.service.ocgPage;
                            this.navigationItem.nextButtonLinkUrl = this.service.recommendationPage;
                            break;
                        case this.service.urls.Recommendation:
                            this.navigationItem.prevButtonLinkUrl = this.service.riskFactorPage;
                            this.navigationItem.nextButtonLinkUrl = this.service.completeAssessmentPage;
                            this.navigationItem.disableNextButton = this.service.completeAssessmentPage.status === this.service.status.Disabled;
                            break;
                        case this.service.urls.CompleteAssessment:
                            this.navigationItem.showNextButton = false;
                            this.navigationItem.prevButtonLinkUrl = this.service.recommendationPage;
                            this.navigationItem.nextButtonLinkUrl = this.service.completeAssessmentPage;
                            break;
                    }
                };
                default_1.prototype.setTimelineStartPage = function () {
                    var prevPage = this.service.ocgPage;
                    var nextPage = this.service.riskFactorPage;
                    var currentPage = this.service.ocgPage;
                    if (location.hash.indexOf(this.service.riskFactorPage.url) !== -1) {
                        prevPage = this.service.ocgPage;
                        nextPage = this.service.recommendationPage;
                        currentPage = this.service.riskFactorPage;
                    }
                    else if (location.hash.indexOf(this.service.recommendationPage.url) !== -1) {
                        prevPage = this.service.riskFactorPage;
                        nextPage = this.service.completeAssessmentPage;
                        currentPage = this.service.recommendationPage;
                    }
                    else if (location.hash.indexOf(this.service.completeAssessmentPage.url) !== -1) {
                        prevPage = this.service.recommendationPage;
                        nextPage = this.service.completeAssessmentPage;
                        currentPage = this.service.completeAssessmentPage;
                    }
                    this.setCurrentPageName(currentPage);
                    this.navigationItem = {
                        showPrevButton: false,
                        showNextButton: true,
                        disableNextButton: false,
                        prevButtonLinkUrl: prevPage,
                        nextButtonLinkUrl: nextPage
                    };
                };
                default_1.$inject = [timeline_service_1.TimelineService.serviceName, event_service_1.default.serviceName,
                    ocg_service_1.default.serviceName, riskfactor_service_1.default.serviceName, recommendation_service_1.default.serviceName, '$q'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=timeline.controller.js.map