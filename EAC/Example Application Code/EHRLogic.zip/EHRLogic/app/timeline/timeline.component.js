System.register(['./timeline.controller', "../ocg/ocg.component", "../riskfactor/riskfactor.component", "../recommendation/recommendation.component", "../completeAssessment/completeAssessment.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var timeline_controller_1, ocg_component_1, riskfactor_component_1, recommendation_component_1, completeAssessment_component_1;
    var TimelineComponent;
    return {
        setters:[
            function (timeline_controller_1_1) {
                timeline_controller_1 = timeline_controller_1_1;
            },
            function (ocg_component_1_1) {
                ocg_component_1 = ocg_component_1_1;
            },
            function (riskfactor_component_1_1) {
                riskfactor_component_1 = riskfactor_component_1_1;
            },
            function (recommendation_component_1_1) {
                recommendation_component_1 = recommendation_component_1_1;
            },
            function (completeAssessment_component_1_1) {
                completeAssessment_component_1 = completeAssessment_component_1_1;
            }],
        execute: function() {
            TimelineComponent = (function () {
                function TimelineComponent() {
                    this.templateUrl = 'app/timeline/timeline.html';
                    this.controller = timeline_controller_1.default;
                    this.$routeConfig = [
                        { path: '/ocg', name: 'Ocg', component: ocg_component_1.default.componentName, useAsDefault: true },
                        { path: '/risk', name: 'RiskFactor', component: riskfactor_component_1.default.componentName },
                        { path: '/recommendation', name: 'Recommendation', component: recommendation_component_1.default.componentName },
                        { path: '/complete', name: 'CompleteAssessment', component: completeAssessment_component_1.default.componentName },
                    ];
                }
                TimelineComponent.componentName = 'timeline';
                return TimelineComponent;
            }());
            exports_1("default", TimelineComponent);
        }
    }
});
//# sourceMappingURL=timeline.component.js.map