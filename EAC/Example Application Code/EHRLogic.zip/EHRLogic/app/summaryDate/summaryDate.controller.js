System.register(['./summaryDate.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var summaryDate_service_1;
    var default_1;
    return {
        setters:[
            function (summaryDate_service_1_1) {
                summaryDate_service_1 = summaryDate_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(summaryService) {
                    this.summaryService = summaryService;
                }
                default_1.prototype.$onChanges = function () {
                    if (this.dateModel) {
                        this.dateModel.dateDetail.dayOfServiceDate = new Date(this.dateModel.dateDetail.dayOfServiceDate.toString());
                    }
                };
                default_1.$inject = [summaryDate_service_1.default.serviceName];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=summaryDate.controller.js.map