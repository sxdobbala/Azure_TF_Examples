System.register(['./userBanner.component', './userBanner.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var userBanner_component_1, userBanner_service_1;
    return {
        setters:[
            function (userBanner_component_1_1) {
                userBanner_component_1 = userBanner_component_1_1;
            },
            function (userBanner_service_1_1) {
                userBanner_service_1 = userBanner_service_1_1;
            }],
        execute: function() {
            angular
                .module('compass.userBanner', [])
                .component(userBanner_component_1.default.componentName, new userBanner_component_1.default())
                .service(userBanner_service_1.default.serviceName, userBanner_service_1.default);
        }
    }
});
//# sourceMappingURL=userBanner.init.js.map