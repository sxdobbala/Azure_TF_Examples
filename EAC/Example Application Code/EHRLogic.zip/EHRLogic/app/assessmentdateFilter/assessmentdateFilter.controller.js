System.register(['./assessmentdateFilter.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var assessmentdateFilter_service_1;
    var default_1;
    return {
        setters:[
            function (assessmentdateFilter_service_1_1) {
                assessmentdateFilter_service_1 = assessmentdateFilter_service_1_1;
            }],
        execute: function() {
            default_1 = (function () {
                function default_1(service, $filter) {
                    this.service = service;
                    this.$filter = $filter;
                    this.initialize();
                }
                ;
                default_1.prototype.initialize = function () {
                };
                default_1.prototype.filterTypeChange = function () {
                    var self = this;
                    self.dateFilterDialog.beginDateError = false;
                    self.dateFilterDialog.endDateError = false;
                };
                default_1.$inject = [assessmentdateFilter_service_1.default.serviceName, '$filter'];
                return default_1;
            }());
            exports_1("default", default_1);
        }
    }
});
//# sourceMappingURL=assessmentdateFilter.controller.js.map