import json
import urllib.parse
import boto3
import gzip
import string
import os
from io import BytesIO
from datetime import datetime
print('Loading function')

s3 = boto3.client('s3')
destination_s3 = boto3.client('s3')
destination_bucket = os.environ['destination_s3_bucket']

def lambda_handler(event, context):

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        response_data = response['Body']
        buffer_data = {}

        # unzipping and reading the records from the file
        with gzip.open(response_data,'r') as f:
            with gzip.open(f, mode='r') as fil:
                json_data = fil.read().decode('utf-8')
                more_data = json_data.find('}{') # separating the concatenated json objects inside records file
                start = 0
                end = 0
                while(more_data != -1):
                    end = more_data+1
                    data = json_data[start:end]
                    data = json.loads(data)
                    if(data["messageType"] == "DATA_MESSAGE"):
                        if(data["owner"] in buffer_data):
                            sub_folder = data["logGroup"] if (data["logGroup"]=="launchpad-cloudtrail-log-group") else data["logGroup"]+"/"+data["logStream"][:len(data["logStream"])-4]
                            if(sub_folder in buffer_data[data["owner"]]):
                                buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
                            else:
                                buffer_data[data["owner"]][sub_folder] = []
                                buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
                        else:
                            sub_folder = data["logGroup"] if (data["logGroup"]=="launchpad-cloudtrail-log-group") else data["logGroup"]+"/"+data["logStream"][:len(data["logStream"])-4]
                            buffer_data[data["owner"]] = {}
                            buffer_data[data["owner"]][sub_folder] = []
                            buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
                    start = end
                    more_data = json_data.find('}{',start+1)
                    
                # last json object or if only json object
                data = json.loads(json_data[start:])
                if(data["messageType"] == "DATA_MESSAGE"):
                    if(data["owner"] in buffer_data):
                        sub_folder = data["logGroup"] if (data["logGroup"]=="launchpad-cloudtrail-log-group") else data["logGroup"]+"/"+data["logStream"][:len(data["logStream"])-4]
                        if(sub_folder in buffer_data[data["owner"]]):
                            buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
                        else:
                            buffer_data[data["owner"]][sub_folder] = []
                            buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
                    else:
                        sub_folder = data["logGroup"] if (data["logGroup"]=="launchpad-cloudtrail-log-group") else data["logGroup"]+"/"+data["logStream"][:len(data["logStream"])-4]
                        buffer_data[data["owner"]] = {}
                        buffer_data[data["owner"]][sub_folder] = []
                        buffer_data[data["owner"]][sub_folder].append(data["logEvents"])
        
        for owner in buffer_data:
            for sub_folder in buffer_data[owner]:
                file_key = owner+"/"+sub_folder+"/"+datetime.now().strftime('%Y-%m-%d')+'/'+datetime.now().strftime('%H:%M:%S') #filename will be stored according to utc date
                current_data = ''.join(str(item) for innerlist in buffer_data[owner][sub_folder] for item in innerlist)
                encoded_data = current_data.encode("utf-8")
                gzip_file = gzip.open('/tmp/data.txt.gz', 'wb')
                gzip_file.write(encoded_data)
                gzip_file.close()
                destination_s3.upload_file('/tmp/data.txt.gz', destination_bucket, file_key + '.gz')
                
        print("Successfully processed file : "+key)        
        return "Successfully processed the logs"
    except Exception as e:
        print("Error in processing")
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
